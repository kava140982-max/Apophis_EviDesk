# Review-Changelog

## 0.3.1-review

`reject` und `escalate` sind Gate-Blocker und werden in der UI angezeigt. Beschädigtes persistiertes JSON löst einen Fehler aus, statt als leerer Fallback behandelt oder überschrieben zu werden. Nicht-Loopback-Bind-Adressen werden ohne Authentifizierung beim Start abgewiesen.

`scripts/governance-selftest.js` prüft vollständige Approvals, Reject, Escalate, beschädigte Approval-Logs und den Remote-Bind-Guard. `npm test` umfasst Syntaxprüfung aller JavaScript-Dateien, Offline-Verifikation, lokalen Interop-Formatcheck, Governance-Regression und Smoke-Check.

Der aktive private Signing-Schlüssel aus dem Upload wurde aus der Review-Kopie entfernt. Das vorhandene Demo-Bundle kann weiterhin offline geprüft werden; `npm run build:bundle` wurde nicht ausgeführt. Der Audit-Pack-Exporter enthält zusätzlich `RED_TEAM_REPORT_REVIEW.md`.

Der News-Refresh-Pfad verlangt jetzt exakte HTTPS-Hosts aus einer Allowlist, folgt Redirects nicht, prüft Content-Type und begrenzt Body (256 KiB), Laufzeit (10 s), Quellen (10) und Items (20/Quelle). `scripts/news-security-selftest.js` prüft URL-Ablehnungen und Bodylimits offline. Die Inbox bleibt deaktiviert; DNS-Pinning und institutionelle Egress-Kontrollen fehlen.

## 0.4.0-interop-foundation

Die Review-Kopie enthält jetzt ein versioniertes Interoperability Profile für OSF, Zenodo, Dataverse, InvenioRDM, C2PA/VC sowie optionale Matrix-/ActivityPub-Discovery. `/api/capabilities`, `/.well-known/apophis-community.json`, WebFinger und ein HTTPS-gebundenes `did:web`-Dokument machen eine Instanz auffindbar, ohne aus Gemeinschaftszugehörigkeit automatisch Vertrauen abzuleiten.

Ein privates Projektmodell (`/api/projects`) unterstützt synthetische Projektarbeit mit Retention, Mitgliedsrollen, Bundle-Referenzen und opt-in External Sync. Fremde Statuswerte bleiben Record-/Review-Information und dürfen keine Apophis-Freigabe erzeugen. `/api/privacy/export` und `/api/privacy/erase` sind lokale, actor-scoped Readiness-Bausteine; sie sind keine DSGVO-Zertifizierung.

Der neue `scripts/interop-core.js` validiert HTTPS-Allowlists, löst A/AAAA-Adressen auf, blockiert lokale/private/link-local/multicast/Metadatenbereiche und bindet die HTTP-Verbindung an die validierte Adresse; Redirects werden abgewiesen. `scripts/interop-security-selftest.js` und `npm test` prüfen diese Regeln offline.

## 0.4.1-group-exchange

Das Gruppenprinzip aus dem SocialHub-Vorschlag wurde fachlich angepasst: Zwei Systeme können nun per kurzlebiger Challenge, Ed25519-Signatur und Replay-Schutz ihren Peer identifizieren. Der Zustand lautet absichtlich `identified-not-trusted`; Gemeinschaftsmitgliedschaft und Projektpolicy bleiben separate Entscheidungen.

Ein privater Gruppenkanal akzeptiert strukturierte `review_request`, `project_update` oder `evidence_bundle_ref`-Nachrichten. Sie werden als `received-needs-review` gespeichert, mit Idempotency-Key entdoppelt und dürfen weder Claim-Status noch Approval-Gate ändern. Freie Social-Feed-Elemente, Tracking und automatische öffentliche Verteilung wurden nicht übernommen.

## 0.4.2-europe-foundation

Die Europa-Lücken aus `EUROPA_VERGLEICH_UND_NAECHSTE_SCHRITTE.md` wurden so weit umgesetzt, wie es ohne externe Betreiber- oder Identitätskonfiguration sicher möglich ist: maschinenlesbare Self-Description, PID-/Metadata-Profil mit DataCite/DCAT/Schema.org/OpenAIRE-Mappings, Trust-States mit Ablauf/Widerrufsfeld, strukturierte Access-Requests mit Zweckbindung und `export_allowed: false` als Default sowie Conformance-Selbsttest.

Neue Endpunkte sind `/.well-known/apophis-self-description.json`, `/api/trust/registry`, `/api/access-requests`, `/api/access-requests/:id/decision` und `/api/metadata/record/:id`. Die produktive AAI-Anbindung (OIDC/SAML/eduGAIN/EGI/ELIXIR), KMS/HSM, Mehrmandantenrechte, formale Trust Anchors, sichere Verarbeitungsumgebungen und Betreiber-/Datenschutzfreigaben bleiben bewusst als externe Betriebsbausteine offen.

---

**KaVa-14.10.26**

# 0.4.1-resilience-preview — 20.10.2026

- Added a versioned German KRITIS resilience control catalogue with primary-law references, applicability and evidence intent.
- Added a synthetic operator register and a local report command that checks ownership, dates and safe in-project evidence references and hashes referenced files.
- Added a tabletop/recovery exercise template with RTO/RPO fields and explicit sensitive-data boundaries.
- The report always labels itself `WORKING_REGISTER_ONLY`; the initial template has all 12 controls marked not assessed.


# 0.4.2-research-radar-preview — 20.10.2026

- Added an optional, disabled-by-default Europe PMC metadata collector with a separate inbox, fixed provider endpoint, no redirects, request limits and human-review status.
- The collector stores bibliographic metadata, retrieval time and SHA-256 metadata snapshots only; it does not fetch abstracts/full text, invoke an LLM or write to the Core.
- Added a coder-facing roadmap for local-only AI suggestions behind a future human-review boundary. The AI stage is not implemented.

# 0.4.3-ai-backup-preview — 20.10.2026

- Added a manually operated AES-256-GCM encrypted application-data backup, verification, restore-to-empty-directory, and retention-prune CLI.
- Private signing keys are excluded from the application backup and require a separate institutional key-management process.
- Added AI/API governance and local quantization design guidance, including per-message identity/classification and explicit non-implementation boundaries.
- Two-person authorization, real identity, remote scheduling/transfer, and host-level system images remain deployment requirements and are not implemented by this prototype.

# 0.4.4-alert-isolation-preview — 20.10.2026

- Added a standalone warning inbox service with its own process, UI, data directory and API; no Core imports, routes, writes or synchronization.
- Added preliminary vs source-confirmed staging based on two distinct configured source families, with immutable hash-chained warning events, expiry, withdrawal and all-clear handling.
- Source registry remains disabled and empty; no undocumented public alert endpoint is polled.
- Preserved the v0.4.3 encrypted application-data backup prototype and fail-closed dual-authorization adapter requirement.

# 0.4.5-anomaly-demo-preview — 20.10.2026

- Added a passive, local-only time-series anomaly demo with CSV import, configurable robust rolling median/MAD detection, source file hash metadata, and local deletion.
- Added a separate process and storage directory; no Core imports, network polling, control actions, or automatic attack verdicts.
- Added SMARD public data import guidance and explicit per-operator baseline/tolerance customization requirements; synthetic demo data is labeled synthetic.

# 0.4.6-emergency-control-preview — 20.10.2026

- Added an application-only emergency lock that causes Core HTTP routes to fail closed until a separately authorized release.
- Added an encrypted application-data evidence snapshot, recipient-specific RSA public-key wrapping, pinned authority-key fingerprint, and two-person authorization hooks for trigger and release.
- Added an authority recipient registry template; no authority key, identity adapter, remote transfer client, scheduler, or automatic deletion policy is supplied.
- Explicitly excludes host/OS shutdown and physical OT, power, SCADA, safety, and warning systems; no universal government master key is embedded.
- The detector is a statistical baseline prototype, not a trained cyberattack AI; no real site telemetry or verified incident labels are bundled.
# 0.4.7-public-patterns-preview — 20.10.2026

- Resilienzregister um PDCA-Arbeitsphase und verantwortliche, terminierte Maßnahmen erweitert.
- Berichtsmodell um Maßnahmendetails sowie offene/überfällige Kennzahlen erweitert.
- Regressionstest für gültige, überfällige, abgeschlossene und fehlerhafte Registermaßnahmen ergänzt und in `npm test` integriert.
- Isolierte Ende-zu-Ende-Tests für Backup- und Notfallpfade ergänzt: ausschließlich temporäre synthetische Kopien, generierte Testschlüssel und externe Testverzeichnisse.
- Öffentliche Muster aus GRC/BCM, KI-Agenten-Kontrollen, Anomalieerkennung und Backup-Unveränderbarkeit abstrahiert dokumentiert.
- Keine Anbieterimplementierungen oder geschützten Inhalte kopiert; keine produktive KI-, SIEM-, Identity- oder externe Backup-Integration ergänzt.
- Vollständiger lokaler `npm test`-Prüflauf nach Aktualisierung der SBOM-Identität erfolgreich; zusätzlich gezielte Maßnahmen-Regressionstests bestanden. Keine Tests gegen fremde SaaS-Produktivumgebungen oder unabhängigen Penetrationstests ausgeführt.


## 0.4.8-public-patterns-preview — 2026-10-20

- Offline verifier now fails closed when an explicitly supplied approval-log path is missing, unreadable, malformed, or structurally invalid.
- Added `scripts/verify-selftest.js` covering optional bundle-only mode, a valid approval log, missing path, malformed JSON, and invalid log structure; included it in `npm test`.
- Updated package identity and SBOM version to 0.4.8.
- Retested the full local suite on a clean copy; all pipeline stages passed. This remains a local synthetic prototype, not a production or certification result.
