// KaVa-14.10.26 — review watermark
const sourceList = document.querySelector('#source-list');
const bundleStatus = document.querySelector('#bundle-status');
const bundleDetail = document.querySelector('#bundle-detail');
const approvalStatus = document.querySelector('#approval-status');
const approvalDetail = document.querySelector('#approval-detail');
const auditStatus = document.querySelector('#audit-status');
const approvalMessage = document.querySelector('#approval-message');

function escapeHtml(value) { return String(value).replace(/[&<>'"]/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char])); }
function renderSources(sources) { sourceList.innerHTML = sources.map((source) => `<article class="source"><div class="source-publisher">${escapeHtml(source.publisher)}<br><span>${escapeHtml(source.type)}</span></div><div><h4>${escapeHtml(source.title)}</h4><p>${escapeHtml(source.supports)}</p><p class="source-boundary">Grenze: ${escapeHtml(source.boundary)}</p></div><a href="${escapeHtml(source.url)}" target="_blank" rel="noreferrer">Quelle ↗</a></article>`).join(''); }
async function refreshAudit() {
  const result = await fetch('/api/audit/verify').then((response) => response.json());
  const approvalGate = await fetch('/api/approvals/status').then((response) => response.json());
  const bundle = result.bundle || {};
  const approvals = result.approvals;
  const blocking = Array.isArray(approvalGate.blocking_decisions) ? approvalGate.blocking_decisions : [];
  const gateLabel = blocking.length ? `Gate blockiert: ${blocking.join(', ')}` : (approvalGate.ready ? '2-Augen-Gate bereit' : '2-Augen-Gate offen');
  const valid = bundle.valid;
  bundleStatus.textContent = valid ? 'VERIFIED' : 'CHECK FAILED';
  bundleStatus.className = valid ? 'verified' : 'failed';
  bundleDetail.textContent = `SHA-256 ${bundle.receipt_ok ? 'ok' : 'fehlt'} · Ed25519 ${bundle.signature_ok ? 'ok' : 'fehlt'} · ${bundle.bundle_hash ? bundle.bundle_hash.slice(0, 18) + '…' : 'kein Hash'}`;
  approvalStatus.textContent = approvals ? `${approvalGate.approval_count} APPROVALS` : 'CHAIN FAILED';
  approvalDetail.textContent = approvals ? `${approvalGate.distinct_actors} Actors · Rollen ${approvalGate.roles.join(', ') || 'keine'} · ${gateLabel}` : 'Approval-Log muss geprüft werden.';
  auditStatus.textContent = valid && approvals && approvalGate.ready ? 'verified locally · gate ready' : 'review required';
}
fetch('/api/references').then((response) => response.ok ? response.json() : Promise.reject(new Error('source_load_failed'))).then(renderSources).catch(() => { sourceList.innerHTML = '<div class="loading">Quellen konnten lokal nicht geladen werden. Die README enthält die Referenzen.</div>'; });
refreshAudit().catch(() => { auditStatus.textContent = 'verification unavailable'; });
Promise.all([fetch('/api/capabilities').then((response) => response.json()), fetch('/api/projects').then((response) => response.json())]).then(([capabilities, projects]) => {
  document.querySelector('#community-name').textContent = 'Apophis Evidence Community';
  document.querySelector('#community-detail').textContent = `${capabilities.protocols.discovery.join(' · ')} · ${capabilities.policy.external_sync} · ${capabilities.policy.import}`;
  document.querySelector('#project-count').textContent = `${(projects.projects || []).length} PRIVATE PROJECT${(projects.projects || []).length === 1 ? '' : 'S'}`;
}).catch(() => { document.querySelector('#community-detail').textContent = 'Discovery lokal nicht verfügbar.'; });
document.querySelector('#approval-form').addEventListener('submit', async (event) => { event.preventDefault(); approvalMessage.textContent = 'Record wird lokal verkettet …'; const data = Object.fromEntries(new FormData(event.currentTarget)); const response = await fetch('/api/approvals', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(data) }); const result = await response.json(); if (!response.ok) { approvalMessage.textContent = `Nicht gespeichert: ${result.error || 'unknown error'}`; return; } approvalMessage.textContent = `Gespeichert: ${result.record.record_id} · Chain verified`; event.currentTarget.reset(); refreshAudit(); });
document.querySelectorAll('[data-scroll]').forEach((button) => button.addEventListener('click', () => document.querySelector(button.dataset.scroll)?.scrollIntoView({ behavior: 'smooth' })));
