#!/usr/bin/env node
'use strict';
const assert = require('node:assert/strict');
const { isBlockedIp, validateExternalUrl } = require('./interop-core');
assert.equal(isBlockedIp('127.0.0.1'), true);
assert.equal(isBlockedIp('10.0.0.1'), true);
assert.equal(isBlockedIp('169.254.169.254'), true);
assert.equal(isBlockedIp('::1'), true);
assert.equal(isBlockedIp('8.8.8.8'), false);
assert.throws(() => validateExternalUrl('http://example.org'), /source_not_allowlisted/);
assert.throws(() => validateExternalUrl('https://127.0.0.1'), /source_not_allowlisted/);
assert.throws(() => validateExternalUrl('https://allowed.example.org/path', new Set(['other.example.org'])), /source_not_allowlisted/);
assert.doesNotThrow(() => validateExternalUrl('https://allowed.example.org/path', new Set(['allowed.example.org'])));
console.log(JSON.stringify({ verdict: 'PASS', dns_rebinding_policy: 'validate-resolve-pin-connect', private_ranges_blocked: true, redirects: 'rejected', external_sync_default: 'off' }, null, 2));
