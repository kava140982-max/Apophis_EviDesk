// KaVa-14.10.26 — review watermark
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const root = path.join(__dirname, '..');
const config = JSON.parse(fs.readFileSync(path.join(root, 'data', 'news-sources.json'), 'utf8'));
const output = path.join(root, 'data', 'news-inbox.json');
const hash = (text) => crypto.createHash('sha256').update(String(text)).digest('hex');
const strip = (text) => String(text || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
const net = require('net');
const MAX_BYTES = 256 * 1024;
const MAX_SOURCES = 10;
const MAX_ITEMS_PER_SOURCE = 20;
const MAX_TIMEOUT_MS = 10000;
const FEED_TYPES = new Set(['application/rss+xml', 'application/atom+xml', 'application/xml', 'text/xml']);

function validateFeedUrl(raw, allowedHosts) {
  let url;
  try { url = new URL(raw); } catch { throw new Error('source_not_allowlisted'); }
  const host = url.hostname.toLowerCase();
  const localHost = host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local') || host.endsWith('.internal') || host.endsWith('.test') || host.endsWith('.invalid') || host.endsWith('.example');
  if (url.protocol !== 'https:' || url.username || url.password || url.port || url.hash || net.isIP(host) || !host.includes('.') || localHost || !allowedHosts.has(host)) {
    throw new Error('source_not_allowlisted');
  }
  return url;
}

function parseAllowedHosts(value) {
  if (!Array.isArray(value)) throw new Error('host_allowlist_required');
  const hosts = new Set();
  for (const raw of value) {
    if (typeof raw !== 'string' || raw !== raw.trim() || raw.includes('*')) throw new Error('host_allowlist_invalid');
    const host = raw.toLowerCase();
    if (!host.includes('.') || net.isIP(host) || /[^a-z0-9.-]/.test(host) || host.startsWith('.') || host.endsWith('.') || host.includes('..')) throw new Error('host_allowlist_invalid');
    hosts.add(host);
  }
  return hosts;
}

async function readLimitedBody(response, limit = MAX_BYTES) {
  const declared = Number(response.headers.get('content-length'));
  if (Number.isFinite(declared) && declared > limit) throw new Error('feed_too_large');
  if (!response.body) return '';
  const reader = response.body.getReader();
  const chunks = [];
  let size = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > limit) {
        await reader.cancel();
        throw new Error('feed_too_large');
      }
      chunks.push(Buffer.from(value));
    }
  } finally {
    reader.releaseLock();
  }
  return new TextDecoder('utf-8', { fatal: true }).decode(Buffer.concat(chunks, size));
}

function writeJsonAtomic(file, value) {
  const temp = `${file}.${process.pid}.tmp`;
  try {
    fs.writeFileSync(temp, JSON.stringify(value, null, 2) + '\n', { mode: 0o600 });
    fs.renameSync(temp, file);
  } finally {
    fs.rmSync(temp, { force: true });
  }
}

async function main() {
  if (!config.enabled) { const result = { schema: 'apophis/news-inbox/v1', refreshed_at: new Date().toISOString(), status: 'disabled', items: [] }; writeJsonAtomic(output, result); console.log(JSON.stringify(result)); return; }
  if (!Array.isArray(config.sources) || config.sources.length > MAX_SOURCES) throw new Error('source_count_invalid');
  const allowedHosts = parseAllowedHosts(config.allowed_hosts);
  const items = [];
  for (const source of config.sources) {
    if (!source || typeof source.id !== 'string' || !source.id || typeof source.url !== 'string') throw new Error('source_invalid');
    const url = validateFeedUrl(source.url, allowedHosts);
    const response = await fetch(url, { redirect: 'manual', signal: AbortSignal.timeout(MAX_TIMEOUT_MS), headers: { 'User-Agent': 'Apophis-News-Inbox/0.3' } });
    if (response.status >= 300 && response.status < 400) throw new Error('feed_redirect_not_allowed');
    if (!response.ok) throw new Error(`feed_http_${response.status}`);
    const contentType = (response.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
    if (!FEED_TYPES.has(contentType)) throw new Error('feed_content_type_invalid');
    const body = await readLimitedBody(response);
    const blocks = body.match(/<item[\s\S]*?<\/item>|<entry[\s\S]*?<\/entry>/gi) || [];
    for (const block of blocks.slice(0, MAX_ITEMS_PER_SOURCE)) {
      const title = strip((block.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [,''])[1]).slice(0, 512);
      const link = (block.match(/<link[^>]+href=["']([^"']+)["']/i) || block.match(/<link[^>]*>([\s\S]*?)<\/link>/i) || [,''])[1].trim().slice(0, 2048);
      const summary = strip((block.match(/<description[^>]*>([\s\S]*?)<\/description>/i) || block.match(/<summary[^>]*>([\s\S]*?)<\/summary>/i) || [,''])[1]).slice(0, 2000);
      items.push({ source_id: source.id, title, url: link, summary, raw_hash: hash(block), triage: 'human-review-required' });
    }
  }
  const result = { schema: 'apophis/news-inbox/v1', refreshed_at: new Date().toISOString(), status: 'refreshed', items };
  writeJsonAtomic(output, result); console.log(JSON.stringify({ status: result.status, count: items.length }));
}

if (require.main === module) main().catch((error) => { console.error(JSON.stringify({ status: 'failed-closed', error: error.message })); process.exitCode = 1; });
module.exports = { validateFeedUrl, parseAllowedHosts, readLimitedBody, MAX_BYTES };
