// Apophis interoperability and egress safety core.
'use strict';
const dns = require('node:dns').promises;
const https = require('node:https');
const net = require('node:net');

const BLOCKED_HOST_SUFFIXES = ['.localhost', '.local', '.internal', '.test', '.invalid', '.example'];
const MAX_RESPONSE_BYTES = 256 * 1024;

function isBlockedIp(address) {
  const family = net.isIP(address);
  if (family === 4) {
    const octets = address.split('.').map(Number);
    const [a, b] = octets;
    return a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || (a === 198 && (b === 18 || b === 19));
  }
  if (family === 6) {
    const normalized = address.toLowerCase();
    return normalized === '::1' || normalized === '::' || normalized.startsWith('fc') || normalized.startsWith('fd') || normalized.startsWith('fe8') || normalized.startsWith('fe9') || normalized.startsWith('fea') || normalized.startsWith('feb') || normalized.startsWith('ff') || normalized.startsWith('2001:db8:') || normalized.startsWith('::ffff:127.') || normalized.startsWith('::ffff:10.') || normalized.startsWith('::ffff:192.168.');
  }
  return true;
}

function validateExternalUrl(raw, allowedHosts = new Set()) {
  let url;
  try { url = new URL(raw); } catch (_) { throw new Error('source_url_invalid'); }
  const hostname = url.hostname.toLowerCase();
  const allow = allowedHosts.size === 0 || allowedHosts.has(hostname);
  if (url.protocol !== 'https:' || url.username || url.password || url.hash || url.port && url.port !== '443' || net.isIP(hostname) || !hostname.includes('.') || BLOCKED_HOST_SUFFIXES.some((suffix) => hostname === suffix.slice(1) || hostname.endsWith(suffix)) || !allow) throw new Error('source_not_allowlisted');
  return url;
}

async function resolvePinnedAddress(url, allowedHosts = new Set()) {
  const parsed = validateExternalUrl(url, allowedHosts);
  const answers = await dns.lookup(parsed.hostname, { all: true, verbatim: true });
  const addresses = [...new Set(answers.map((answer) => answer.address))];
  if (!addresses.length || addresses.some(isBlockedIp)) throw new Error('dns_destination_blocked');
  return { url: parsed, address: addresses[0], family: net.isIP(addresses[0]), addresses };
}

function fetchPinned(raw, options = {}) {
  const allowedHosts = options.allowedHosts || new Set();
  const maxBytes = options.maxBytes || MAX_RESPONSE_BYTES;
  return resolvePinnedAddress(raw, allowedHosts).then(({ url, address, family }) => new Promise((resolve, reject) => {
    const request = https.request(url, {
      method: options.method || 'GET',
      headers: { 'User-Agent': 'Apophis-Evidence-Desk/0.4', ...(options.headers || {}) },
      timeout: options.timeoutMs || 8000,
      servername: url.hostname,
      lookup: (_hostname, _options, callback) => callback(null, address, family),
      rejectUnauthorized: true
    }, (response) => {
      if (response.statusCode >= 300 && response.statusCode < 400) { response.resume(); return reject(new Error('source_redirect_not_allowed')); }
      const chunks = []; let size = 0;
      response.on('data', (chunk) => { size += chunk.length; if (size > maxBytes) { request.destroy(new Error('source_too_large')); } else chunks.push(chunk); });
      response.on('end', () => resolve({ status: response.statusCode, headers: response.headers, body: Buffer.concat(chunks).toString('utf8'), pinned_address: address }));
    });
    request.on('timeout', () => request.destroy(new Error('source_timeout')));
    request.on('error', reject);
    request.end();
  }));
}

module.exports = { isBlockedIp, validateExternalUrl, resolvePinnedAddress, fetchPinned, MAX_RESPONSE_BYTES };
