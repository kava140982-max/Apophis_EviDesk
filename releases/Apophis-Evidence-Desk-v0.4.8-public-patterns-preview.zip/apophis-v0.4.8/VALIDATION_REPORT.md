# Apophis Evidence Desk 0.4.7 — lokaler Prüflauf

**Stand:** 20. Oktober 2026  
**Laufzeit:** Node.js v24.22.0 auf Linux Mint 22.3  
**Umfang:** lokale synthetische Demo und Repository-Selbsttests; kein Produktionsbetrieb.

## Ergebnis

`npm test` wurde nach Synchronisierung der SBOM mit der Paketversion erfolgreich mit Exitcode 0 abgeschlossen. Enthalten waren Syntaxprüfung, SBOM-/Abhängigkeitsprüfung, Signatur-/Bundle-Verifikation, Interoperabilität, Tenant- und HTTP-Isolation, Governance, sichere Quellenabrufe, CI-Workflow-Prüfung, Manifest-/Release-Evidenz, WORM-ähnlicher lokaler Store, Register- und Recovery-Ende-zu-Ende-Tests sowie Smoke-Test.

Zusätzlich wurde `test:kritis-resilience` in die Testsuite integriert. Er prüft den gültigen synthetischen Registerstart, PDCA-Phase, Zählung offener und überfälliger Aufgaben, Ausschluss abgeschlossener Aufgaben aus Überfälligkeitszahlen sowie Ablehnung ungültiger Phasen, Aufgabenstatus, Verantwortlicher, Fälligkeiten und doppelter IDs. Alle Fälle bestanden.

`test:recovery` führt die Backup- und Notfall-CLI in einer temporären Kopie mit synthetischen Dateien und einem zur Laufzeit generierten Test-RSA-Schlüsselpaar aus. 38 Assertions bestanden, darunter erfolgreiche Verifikation/Wiederherstellung, Ablehnung einzelner Freigaben, falscher Schlüssel, Symlink und manipuliertes Backup sowie Zwei-Personen-Auslösung und -Freigabe. Es wird kein echter Empfänger oder Identitätsdienst angesprochen.

Die EU-Control-Selbstbewertung meldete **3 bestanden, 3 bedingt, 0 fehlgeschlagen** im Umfang `local-loopback-synthetic-prototype`; sie kennzeichnet sich selbst als `not_a_certification: true`. Bedingte Ergebnisse sind keine Freigaben.

## Fehler gefunden und behoben

Der erste Paketlauf stoppte bei `sbom_identity_mismatch`: Die SBOM verwies noch auf `0.4.5-anomaly-demo-preview`, während `package.json` bereits `0.4.7-public-patterns-preview` auswies. Component-Version, Package URL und dependency reference in `SANDBOX-SBOM.json` wurden auf 0.4.7 aktualisiert. Der anschließende komplette Lauf bestand.

## Grenzen

- Nur Node.js v24.22.0 wurde lokal verwendet; die GitHub-Actions-Konfiguration fordert Node.js 20.x, aber diese Laufzeit wurde nicht separat ausgeführt.
- Die Selbsttests nutzen lokale/synthetische Daten. Sie beweisen keine Produktionssicherheit, regulatorische Konformität, physische WORM-Eigenschaft, Core-Isolation, Echtzeit-Angriffserkennung oder Wiederherstellbarkeit in echter Infrastruktur.
- HiScout, verinice, ServiceNow, Microsoft Sentinel und Veeam wurden anhand ihrer öffentlich verfügbaren Produktunterlagen verglichen, nicht in deren Test-/SaaS-Umgebungen ausgeführt. Dafür wären freigegebene Testmandanten/Lizenzen, gleichwertige Testdaten und vorab definierte Messverfahren nötig.
- Ein reproduzierbares Vergleichsprotokoll mit sechs synthetischen Szenarien liegt in `COMPARATIVE_TEST_PROTOCOL.md`; das Apophis-Ergebnis steht in `comparative-eval/results/apophis-local-0.4.7.json`. Die fünf externen Produkte bleiben im Maschinenstatus explizit `NOT_RUN`.
- Kein unabhängiger Penetrationstest, Red-Team-Test, externer Restore-Test oder produktiver OT-/SIEM-Test wurde ausgeführt.
