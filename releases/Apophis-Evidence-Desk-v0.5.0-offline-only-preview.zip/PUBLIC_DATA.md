# Eingebaute öffentliche Referenzen

Diese Quellen sind im Dashboard als Kontextkarten sichtbar. Sie werden nicht als automatische Wahrheit behandelt. Jede Karte enthält deshalb zusätzlich ihre Aussagegrenze.

## CDC — CMV und kongenitale CMV-Infektion

Die CDC beschreibt CMV als häufiges Virus, das lebenslang im Körper verbleiben kann. Die Seite nennt Schwangerschaft, kongenitale Infektion und Menschen mit geschwächtem Immunsystem als wichtige Kontexte. Sie nennt außerdem, dass kongenitale CMV-Infektion mit gesundheitlichen Folgen verbunden sein kann.

Quelle: [CDC — Cytomegalovirus (CMV) and Congenital CMV Infection](https://www.cdc.gov/cytomegalovirus/about/index.html)

**Grenze:** Das ist öffentliche Gesundheitsinformation. Sie bewertet keinen konkreten Impfstoffkandidaten und ersetzt keine individuelle medizinische Beratung.

## EMA — Impfstoff-Leitlinien

Die EMA führt wissenschaftliche Leitlinien für Impfstoffe. Die Übersicht umfasst unter anderem klinische, nichtklinische, Qualitäts- und Adjuvans-Themen. Das ist für Apophis wichtig, weil ein Forschungsplan nicht nur Immunologie, sondern auch Qualität, Sicherheit und regulatorischen Kontext getrennt betrachten muss.

Quelle: [EMA — Multidisciplinary guidelines: vaccines](https://www.ema.europa.eu/en/human-regulatory-overview/research-development/scientific-guidelines/multidisciplinary-guidelines/multidisciplinary-guidelines-vaccines)

**Grenze:** Eine Leitlinie ist keine automatische Zulassungsentscheidung. Anwendbarkeit und Abweichungen müssen fachlich begründet werden.

## EMA — Nichtklinische Leitlinien

Die EMA ordnet nichtklinische Leitlinien unter anderem Pharmakologie, Sicherheitspharmakologie, Pharmakokinetik, Toxikologie, nichtklinische Entwicklung und Umwelt-Risikobewertung zu.

Quelle: [EMA — Non-clinical guidelines](https://www.ema.europa.eu/en/human-regulatory-overview/research-development/scientific-guidelines/non-clinical-guidelines)

**Grenze:** Die Übersicht ersetzt keine wissenschaftliche Beratung und keine konkrete regulatorische Strategie.

## FDA — Vaccine Development 101

Die FDA beschreibt die Impfstoffentwicklung als Folge miteinander verbundener Informationsbereiche: Forschung und Entdeckung, Präklinik, Herstellung und Qualität sowie klinische Entwicklung. Sie betont, dass präklinische Informationen vor Studien am Menschen eine Rolle für die Sicherheitsbewertung spielen.

Quelle: [FDA — Vaccine Development 101](https://www.fda.gov/vaccines-blood-biologics/development-approval-process-cber/vaccine-development-101)

**Grenze:** Das ist eine allgemeine US-Orientierung. Daraus folgt nicht, dass ein bestimmter Kandidat sicher, wirksam, herstellbar oder zulassungsfähig ist.

## Abrufstand

Die Quellen wurden am **19.10.2026** öffentlich abgerufen und im Projekt mit URL, Herausgeber, Titel, Abrufdatum, unterstützter Aussage und Aussagegrenze versioniert. Das Dashboard speichert keine externen Rohseiten und führt keine laufenden externen Abrufe aus.

---

**KaVa-14.10.26**
