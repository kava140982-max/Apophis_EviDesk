# Adapter-Architektur für den Apophis Allrounder

## Zielbild

```text
OIDC/SSO oder lokale Identität
             ↓
Repository / Community Layer
(InvenioRDM, Dataverse, OSF oder Zenodo)
             ↓
Apophis Governance Adapter
Claims · Gegenclaims · Unsicherheit · Biosecurity Gate
             ↓
Signiertes Bundle + Offline-Verifier + Audit-Pack
             ↓
Labor · Ethik · Regulatory · Biosecurity
```

Apophis bleibt dabei eine Governance-Schicht. Das Repository bleibt zuständig für Dateien, Metadaten, Mitglieder, Zugriffsrechte und langfristige Archivierung.

## Adaptervertrag

Jeder Adapter muss vier Operationen anbieten: `exportEvidence`, `importEvidence`, `readBack` und `revokeOrSupersede`. Der Adapter muss die Quell-ID, die Ziel-ID, die Bundle-ID, den Bundle-Hash, den Status und die externe Version protokollieren. Ein Import darf nur Daten ablegen oder einen Review-Fall eröffnen. Er darf niemals automatisch `geprüft`, `freigegeben` oder `sicher` setzen.

Das kanonische Austauschformat ist `data/interoperability-package.json`. Felder mit wissenschaftlicher Bedeutung werden als Datenobjekte übernommen; externe Repository-IDs werden als zusätzliche Referenzen gespeichert. Kein externer Status überschreibt den Apophis-Status ohne explizite Mapping-Regel.

## Mapping-Regeln

- `hypothese`, `kontext-gestützt`, `geprüft`, `blockiert` bleiben Apophis-interne Statuswerte.
- `published`, `released` oder `registered` aus einem Repository bedeuten nur Publikations- oder Archivstatus.
- `approve` wird nur im Kontext der definierten Rollen und des passenden Bundle-Hashes interpretiert.
- `reject`, `escalate` und `block` werden nicht in einen generischen „unpublished“-Status umgebogen.
- unbekannte Werte werden als `unknown` markiert und blockieren den automatischen Abschluss.

## Sicherheit

Produktive Adapter benötigen serverseitige Authentifizierung, Objekt- und Aktionsberechtigungen, getrennte Schlüsselverwaltung, Idempotency-Keys, Rate-Limits, Audit-Ereignisse und explizite Timeouts. Ein lokaler JSON-Adapter ist kein Nachweis für diese Eigenschaften. Der erste produktive Integrationskandidat sollte eine isolierte InvenioRDM- oder Dataverse-Testinstanz mit synthetischen Daten sein.

## White-Label

Eine Stiftung oder ein Verein sollte Spezifikation, Status-Taxonomie, Biosecurity-Grenzen, öffentliche Verifier und Beschwerdeweg verwalten. Eine Genossenschaft kann Hosting, Integrationen, Schulung und Support betreiben. Die Betreiberin darf nicht gleichzeitig die einzige Prüferin sein. Logos und Domain ändern nur die Darstellung, nicht den technischen Scope oder die Haftungsgrenze.

---

**KaVa-14.10.26**
