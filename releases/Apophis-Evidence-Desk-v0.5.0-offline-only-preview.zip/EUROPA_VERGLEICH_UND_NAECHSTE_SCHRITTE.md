# Europa-Vergleich und nächste Schritte für Apophis

**Stand:** 20. Oktober 2026  
**Gegenstand:** Vergleichbare europäische Forschungs-, Datenraum-, Identitäts- und Governance-Infrastrukturen sowie konkrete Anschluss- und Ausbaumöglichkeiten für den Apophis Evidence Desk.

## Einordnung

Apophis sollte nicht versuchen, EOSC, EUDAT, OpenAIRE, ELIXIR, NFDI oder Gaia-X nachzubauen. Diese Umgebungen lösen vor allem Föderation, Forschungsdatenmanagement, Katalogisierung, Identitäts- und Zugangsmanagement oder fachliche Community-Governance. Die sinnvolle Rolle von Apophis ist eine kleinere, klar abgegrenzte Governance-Schicht: Sie bindet Claims, Gegenclaims, Unsicherheit, Biosecurity- und menschliche Review-Entscheidungen an nachvollziehbare Projekt- und Provenienzobjekte.

Das aktuelle Projekt hat dafür bereits einen guten lokalen Kern: signierte Evidence-Bundles, Approval-Chain, Community-Manifest, Capability-Discovery, Projektmodell, Privacy-Readiness, DNS-Pinning sowie Challenge-Response und record-only Gruppenkanal. Was noch fehlt, ist der Übergang vom lokalen Prototyp zu einem anschlussfähigen europäischen Dienst: institutionelle AAI, maschinenlesbare Metadaten- und PID-Profile, formale Policy-/Trust-Statements, Zugangs- und Datenverwendungsprozesse, Konformitätstests und ein belastbares Betriebs- und Governance-Modell.

## Was die europäischen Vergleichssysteme zeigen

| Umgebung | Was sie stark macht | Was Apophis davon übernehmen sollte | Nicht nachbauen |
|---|---|---|---|
| **EOSC** | Föderiertes Netz aus Nodes, Daten, Tools und Services; FAIR-Zielbild, maschinen- und menschenlesbare Zugänge, gemeinsame Governance und Onboarding. [1] | EOSC-kompatibles Service-Self-Description, Katalogeintrag, Onboarding- und Konformitätsprofil sowie AAI-Anschluss. | Kein eigener europäischer Forschungsdatenkatalog und keine neue Generalplattform. |
| **EUDAT** | Praktischer Datenaustausch und Synchronisation über B2DROP; Communities können eigene Instanzen und höhere Zugriffskontrollen erhalten. [2] | Projektübergaben, Connectoren und Export-Referenzen auf EUDAT/B2DROP/B2SHARE mit klarer Datenhoheit. | Kein Dateispeicher und keine Synchronisationsplattform im Apophis-Kern. |
| **OpenAIRE** | Großer Graph aus Publikationen, Daten, Software, Quellen, Organisationen, Förderungen und persistenten Identifikatoren; APIs und Community-Kuration. [3] | PID-Felder für Projekte, Bundles, Quellen, Organisationen und Grants; Rückverlinkung und maschinenlesbare Exporte. | Kein eigener Discovery-Graph und keine bibliometrische Bewertung. |
| **ELIXIR** | Fachliche Interoperabilität über Formate, Metadaten, Vokabulare, Identifier, FAIRification und kuratierte Ressourcen; dazu eine eigene AAI. [4] | Domänenspezifische Profile, kontrollierte Vokabulare, FAIR-Prüfungen und ein erster Life-Science-Pilot. | Kein allgemeines Bioinformatik-Portal und keine fachliche Datenbank. |
| **NFDI** | Dezentrale, konsortienbasierte Forschungsdateninfrastruktur mit fachlich getriebenen Diensten und nationaler/internationaler Vernetzung. [5] | Konsortiums-/Community-Rollen, fachliche Policy-Pakete, gemeinsame Referenzprofile und ein Beirat aus realen Datenverantwortlichen. | Keine zentrale Ersatzstruktur für Konsortien oder Forschungsdatenarchive. |
| **Gaia-X** | Maschinell lesbare, signierte Self-Descriptions, versionierte Compliance-Regeln, Trust Anchors, Verifiable Credentials und überprüfbare Attribute. [6] | Signiertes System-/Organisationsprofil, Trust-Anchor-Konzept, Status `identified`, `verified`, `member` und `trusted` getrennt modellieren. | Kein Gaia-X-Label versprechen und keine formale Gaia-X-Konformität behaupten, bevor Tests und Registrierung vorhanden sind. |
| **BBMRI-ERIC** | Verbindliche Access Policy mit Ethik, Governance, praktischen Zugangsverfahren, Access Committee, Projektbeschreibung, Veto der Datengeber und Data-Transfer-Agreement. [7] | Access-Request-Workflow, formale Projektprüfung, Datengeber-Veto, Zweckbindung, DUA/DTA-Referenz und nachvollziehbare Entscheidung. | Keine biobank-spezifische Zugangsinstanz ohne fachliche und institutionelle Partner. |
| **EHDS / europäische Datenräume** | Gemeinsame Regeln für grenzüberschreitenden Zugang, Kontrolle der Betroffenen, sekundäre Datennutzung über Genehmigungen, sichere Verarbeitungsumgebungen und Interoperabilität. [8] [9] | `purpose`, `legal_basis`, `access_decision`, `data_use_permit`, `expiry`, `revocation`, `secure_processing_required` und „kein Download“ als explizite Policy-Felder. | Keine Gesundheitsdaten in den Demo-Betrieb und keine EHDS-Konformität behaupten. |

## Die größten noch offenen Lücken

### 1. Produktionsfähige Organisationsidentität und AAI

Der aktuelle Challenge-Response-Handshake beweist, dass ein System einen privaten Schlüssel besitzt. Er beweist aber noch nicht, welche Organisation dahintersteht, ob sie Mitglied einer Community ist oder welche Person handeln darf. Europäische Forschungsinfrastrukturen lösen diese Stufe typischerweise über föderierte AAI: EGI Check-in bindet institutionelle Logins über eduGAIN ein, EUDAT B2ACCESS verbindet Identitätsquellen mit community-definierten Zugriffsregeln, und ELIXIR AAI bietet einen ähnlichen Dienst für Life-Science-Ressourcen. [10] [11] [12]

**Fehlender Baustein:** OIDC-/SAML-Anschluss mit institutioneller Organisation, Gruppenmitgliedschaften, Rollen und belastbarer Attributfreigabe. Für Apophis sollte die Identitätsschicht austauschbar bleiben. Ein guter erster Adapter ist OIDC mit einer lokalen Entwicklungs- und einer EGI-/ELIXIR-kompatiblen Produktionskonfiguration. Der vorhandene Actor-Name darf nicht der dauerhafte Identitätsanker bleiben.

### 2. Trust Framework statt nur „identified-not-trusted“

Der aktuelle Zwischenstatus ist richtig, aber noch zu grob. Gaia-X trennt maschinenlesbare Self-Descriptions, Signaturen, Schlüsselbezug, Attributkonsistenz und Verifikation. [6] Apophis braucht deshalb eine explizite Zustandsmaschine:

```text
discovered
  -> cryptographically-identified
  -> organisation-verified
  -> community-member
  -> project-authorised
  -> trusted-for-specific-purpose
  -> revoked / suspended
```

Jeder Übergang muss eine Evidenz, einen Aussteller, eine Gültigkeitsdauer, einen Zweck und eine Widerrufsmöglichkeit besitzen. Ein System darf beispielsweise für einen synthetischen Review-Pilot zugelassen sein, aber nicht für personenbezogene Gesundheitsdaten.

### 3. Gemeinsame Metadaten und persistente Identifikatoren

Apophis besitzt interne IDs und Bundle-Hashes, aber noch kein europäisches Metadatenprofil. EOSC und die europäischen Datenraum-Bausteine betonen maschinenlesbare Datenmodelle, Kataloge, Metadaten, APIs und Konformitätsprüfungen. [1] [9] OpenAIRE zeigt zusätzlich, wie wichtig die Verknüpfung von Publikationen, Daten, Software, Organisationen, Förderungen und PIDs ist. [3]

**Fehlender Baustein:** ein `apophis-record/v1` auf Basis eines dokumentierten Kernprofils, zunächst mit:

- `record_id`, `version`, `created_at`, `supersedes`, `status`;
- ORCID-, ROR-, DOI-, Handle- oder anderer PID-Referenz, wenn vorhanden;
- Projekt-, Organisation-, Bundle-, Claim- und Quellenbeziehungen;
- Lizenz, Zugriffsklasse, Zweck, Aufbewahrung und geografischem Speicherort;
- kontrollierten Vokabularen für Review-Status, Unsicherheit, Risiko und Entscheidungsgrund;
- maschinenlesbarem JSON sowie optionalem DCAT-/Schema.org-/DataCite-Mapping.

### 4. Echter Projekt- und Zugangsworkflow

Das aktuelle Projektmodell kann private Projekte anlegen und Mitglieder abbilden. Es fehlt jedoch der formale Zugangsprozess, der bei BBMRI-ERIC zentral ist: Identität und institutionelle Zugehörigkeit, Projektbeschreibung, fachliche Passung, Ethikprüfung, Datengeber-Veto, Entscheidung und gegebenenfalls DTA/DUA. [7]

**Fehlender Baustein:** eine `access_request`-Entität mit Antragsteller, Institution, Zweck, Datensatz-/Bundle-Referenzen, Datenkategorien, Rechtsgrundlage, gewünschter Dauer, Exportbedarf, Review-Rollen, Entscheidung, Begründung, Bedingungen und Widerruf. Ein Austausch in einer Gruppe sollte dann nicht nur eine Nachricht sein, sondern ein referenzierbarer Antrag oder Review-Fall.

### 5. Datenschutz als operativer Prozess

Apophis hat Privacy-by-Default und lokale Export-/Löschpfade. Für den Mehrparteienbetrieb fehlen jedoch Verantwortlichkeiten und der Nachweis des Datenflusses. Die EDPB-Leitlinien zu Datenschutz durch Technikgestaltung und datenschutzfreundlichen Voreinstellungen verlangen nicht nur eine Checkbox, sondern angemessene technische und organisatorische Maßnahmen, Transparenz, Minimierung, Kontrolle und Nachweisbarkeit. [13] Die DSGVO selbst verlangt unter anderem Zweckbindung, Datenminimierung, Speicherbegrenzung, Integrität/Vertraulichkeit und Rechenschaftspflicht. [14]

**Fehlende Bausteine:** Verarbeitungstätigkeiten-Register, Rollenmodell für Verantwortliche/gemeinsam Verantwortliche/Auftragsverarbeiter, Lösch- und Backup-Lifecycle, Betroffenenrechte über alle Connectoren, Export-/Widerrufsbeziehungen, Incident- und Breach-Prozess, DPIA-Entscheidung und ein Audit der tatsächlichen Logs. Die vorhandenen Hashes sind Integritätsartefakte, aber keine pauschale Begründung für unbegrenzte Aufbewahrung personenbezogener Inhalte.

### 6. Sichere Verarbeitung für sensible Daten

Für Gesundheits- und andere besonders sensible Daten reicht ein Review-API mit Download nicht aus. Der EHDS-Rahmen sieht für bestimmte sekundäre Nutzungen Genehmigungen, Zweckbindung, Pseudonymisierung, sichere Verarbeitungsumgebungen und ein Downloadverbot vor. [8]

**Fehlender Baustein:** Apophis sollte sensible Daten nicht selbst speichern, sondern nur den Antrag, die Policy, die Freigabe, den Verarbeitungsort, die zulässigen Operationen und den Ergebnisnachweis verwalten. Ein zukünftiger Connector müsste `secure_processing_required: true` unterstützen und direkte Bundles/Personendaten aus normalen Exportpfaden blockieren.

### 7. Onboarding, Konformität und Betrieb

Europaweit vergleichbare Infrastrukturen bestehen nicht nur aus APIs. EOSC arbeitet mit Nodes, Governance, Onboarding und Services; die EU-Datenraum-Unterstützung nennt ausdrücklich Datenmodelle, Kataloge, Trustworthy Data Exchange, Software und Konformitätstests. [1] [9]

**Fehlender Baustein:** ein öffentliches Conformance-Kit mit Testfällen für Discovery, Signatur, Handshake, Replay, Rollen, Statusmapping, Löschung, Export, Retention, DNS-Pinning und Adapterverhalten. Dazu gehören eine Versionierung des Profils, ein Change Log, ein Incident-Kontakt, ein Security-Disclosure-Prozess und ein Betreiberhandbuch.

## Was wir im direkten Umfeld konkret aufbauen können

### Priorität 0–90 Tage: anschlussfähiger Pilot

1. **OIDC-/AAI-Schnittstelle vorbereiten.** Zuerst Provider-neutral mit OIDC Discovery, PKCE und einer lokalen Test-IdP-Konfiguration. Danach ein Pilotgespräch mit einer Hochschule, einem ELIXIR-Knoten, einem NFDI-Konsortium oder einem EGI-/eduGAIN-nahen Betreiber.
2. **Self-Description v1 definieren.** Eine maschinenlesbare Beschreibung für System, Organisation, Community, Service, Datenklassen, Policy-Version, Schlüssel, Endpunkte, Speicherregion und Kontakt. Signiert und versioniert, aber mit klarer Kennzeichnung, welche Aussagen nur Selbstauskunft sind.
3. **Trust-Zustände und Widerruf implementieren.** `identified`, `organisation-verified`, `member`, `project-authorised` und `revoked` getrennt speichern. Keine implizite Vertrauensvererbung über Community oder Domain.
4. **Access-Request-Workflow hinzufügen.** Der Gruppenkanal erzeugt nicht nur `review_request`, sondern einen strukturierten Antrag mit Zweck, Institution, Umfang, Dauer und Review-Gremium.
5. **Kernmetadaten und PIDs ergänzen.** ORCID/ROR für Personen und Organisationen, DOI/DataCite-Referenzen für publizierte Bundles, optional OpenAIRE-/EOSC-Kataloglink. Keine neuen PIDs erfinden.
6. **Conformance-Test-Kit veröffentlichen.** Ein zweiter unabhängiger Test-Client soll Challenge, Signatur, Replay, Idempotency, Privacy-Export und Statusgrenzen gegen Apophis prüfen.

### 3–6 Monate: europäischer Anschluss

- Einen synthetischen Pilot mit einem realen Repository durchführen: vorzugsweise InvenioRDM, Dataverse oder EUDAT/B2SHARE.
- Einen fachlichen Pilotpartner aus ELIXIR, NFDI oder BBMRI-ERIC gewinnen. Der Pilot sollte nur ungefährliche, synthetische oder bereits öffentlich zugängliche Datensätze verwenden.
- `data_use_permit`, DTA/DUA-Referenz, Zweckbindung, Ablauf, Widerruf und Datengeber-Veto modellieren.
- Ein OpenAIRE-/EOSC-kompatibles Katalogmapping erstellen und gegen einen Testkatalog validieren.
- Ein Governance-Board mit Betreiber, Datenverantwortlichen, Datenschutz, Fachreview und Security einrichten. Betreiber und alleinige Freigabestelle dürfen nicht identisch sein.
- Technische Betriebsanforderungen für Mehrmandantenfähigkeit, KMS/HSM, Backups, Monitoring, Rate Limits, Verschlüsselung und Incident Response festlegen.

### Später, nur mit Partnern und Betreiberentscheidungen

- EUDI-Wallet- oder qualifizierte Organisationsnachweise prüfen. Die EU Digital Identity Wallet ist ein europäischer Identitäts- und Nachweisrahmen, aber keine sofortige Abkürzung für Forschungsrollen oder fachliche Vertrauensentscheidungen. [15]
- Gaia-X Self-Descriptions oder Data-Space-Connectoren nur dann integrieren, wenn ein konkreter Datenraumpartner und ein konkreter Trust Anchor feststehen.
- Secure Processing Environments für sensible Daten anschließen, statt Daten in Apophis zu replizieren.
- ActivityPub oder Matrix nur für Benachrichtigung und Gruppenkoordination verwenden. Die fachliche Quelle der Wahrheit bleiben strukturierte Review-/Access-Records.

## Empfohlene Zielarchitektur

```text
Institutionelle AAI / OIDC-SAML / eduGAIN / EGI / ELIXIR
                         |
        Organisations- und Rollenattribute / PIDs
                         v
  Trust & Policy Layer: Self-Description, VC, Trust Anchors,
  Zweck, Ablauf, Widerruf, Mandant, Datenraumregeln
                         |
  EOSC-/OpenAIRE-/EUDAT-/Dataverse-/InvenioRDM-Connectoren
                         |
  Apophis Governance Core
  Claims · Gegenclaims · Unsicherheit · Biosecurity · Human Review
  Access Requests · DTA/DUA · Group Handshake · Audit Chain
                         |
  Katalog / Repository / Secure Processing Environment
  Kein automatischer Statusimport · kein unkontrollierter Download
```

Die zentrale Entscheidung lautet: Apophis sollte ein **Policy- und Review-Orchestrator zwischen föderierten Identitäten, Datenkatalogen und sicheren Verarbeitungsorten** werden. Es sollte weder ein neues Repository noch ein neues soziales Netzwerk noch ein allgemeines Trust-Siegel sein.

## Klare Nicht-Ziele und Risiken

Apophis sollte keine europäische Sammelplattform für personenbezogene Gesundheits- oder Forschungsdaten werden. Es sollte keine Organisationszugehörigkeit aus einer E-Mail-Domain ableiten, keine externe `published`- oder `registered`-Markierung als fachliche Prüfung interpretieren und keine VC-Signatur als Wahrheitsbeweis darstellen. Es sollte keine Gruppe automatisch als vertrauenswürdig behandeln und keine dezentrale Föderation ohne Widerruf, Rate Limits, Replay-Schutz, Missbrauchsprozess und Betreiberverantwortung öffnen.

Das größte Risiko ist nicht fehlende Technik, sondern **überdehnte Bedeutung**: Ein signiertes System kann authentisch sein, ohne vertrauenswürdig für jeden Zweck zu sein; ein verifizierter Datensatz kann korrekt übertragen sein, ohne wissenschaftlich ausreichend zu sein; ein genehmigter Projektzugang kann zweckgebunden sein, ohne eine allgemeine Freigabe zu bedeuten. Diese Trennungen müssen im Datenmodell und in der UI sichtbar bleiben.

## Schlussfolgerung

Die sinnvollste europäische Strategie ist kein All-in-one-Ausbau, sondern ein kontrollierter Anschluss an bestehende Föderationen. Der nächste substanzielle Schritt ist ein synthetischer Pilot mit institutioneller AAI, Self-Description, PID-/Metadatenprofil, Access-Request und Conformance-Test gegen ein Repository. Damit würde Apophis von einem gut abgesicherten lokalen Demonstrator zu einer realistisch anschlussfähigen Governance-Komponente für EOSC-/ELIXIR-/NFDI-nahe Projekte wachsen.

## References

[1]: https://research-and-innovation.ec.europa.eu/strategy/strategy-research-and-innovation/our-digital-future/open-science/european-open-science-cloud-eosc_en "European Open Science Cloud (EOSC), European Commission"
[2]: https://eudat.eu/service-catalogue/b2drop "B2DROP, EUDAT"
[3]: https://explore.openaire.eu/ "OpenAIRE Explore and Graph"
[4]: https://elixir-europe.org/platforms/interoperability "ELIXIR Interoperability Platform"
[5]: https://www.dfg.de/en/research-funding/funding-initiative/nfdi "National Research Data Infrastructure, DFG"
[6]: https://docs.gaia-x.eu/policy-rules-committee/trust-framework/22.10/ "Gaia-X Trust Framework"
[7]: https://www.bbmri-eric.eu/services/access-policies/ "BBMRI-ERIC Access Policies"
[8]: https://health.ec.europa.eu/ehealth-digital-health-and-care/european-health-data-space-regulation-ehds_en "European Health Data Space Regulation, European Commission"
[9]: https://interoperable-europe.ec.europa.eu/collection/semic-support-centre/data-spaces "Data Spaces, Interoperable Europe / European Commission"
[10]: https://www.egi.eu/service/check-in "EGI Check-in"
[11]: https://eudat.eu/service-catalogue/b2access "B2ACCESS, EUDAT"
[12]: https://elixir-europe.org/platforms/compute/aai "ELIXIR Authentication and Authorisation Infrastructure"
[13]: https://www.edpb.europa.eu/sites/default/files/files/file1/edpb_guidelines_201904_dataprotection_by_design_and_by_default_v2.0_en.pdf "EDPB Guidelines 4/2019 on Data Protection by Design and by Default"
[14]: https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng "Regulation (EU) 2016/679, GDPR"
[15]: https://digital-strategy.ec.europa.eu/en/policies/eudi-regulation "European Digital Identity Regulation"
