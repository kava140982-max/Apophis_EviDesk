'use strict';
const list = document.querySelector('#alerts');
const errorBox = document.querySelector('#error');
const escapeText = (value) => String(value ?? '');
function render(items) {
  list.replaceChildren();
  if (!items.length) {
    const p = document.createElement('p'); p.textContent = 'Keine Warnmeldungen im separaten Radar.'; list.append(p); return;
  }
  for (const item of items) {
    const card = document.createElement('article');
    const title = document.createElement('h2'); title.textContent = escapeText(item.title); card.append(title);
    const stage = document.createElement('p'); stage.className = `stage ${item.stage}`;
    stage.textContent = item.stage === 'source_confirmed' ? 'Quellenbestätigt' : item.stage === 'preliminary' ? 'Vormeldung · noch nicht unabhängig bestätigt' : 'Aufgehoben / abgelaufen'; card.append(stage);
    const summary = document.createElement('p'); summary.textContent = escapeText(item.summary); card.append(summary);
    if (item.instruction) { const instruction = document.createElement('p'); instruction.textContent = `Amtlicher Hinweis: ${escapeText(item.instruction)}`; card.append(instruction); }
    const metadata = document.createElement('p'); metadata.className = 'muted'; metadata.textContent = `Zuordnung: ${escapeText(item.correlation_id)} · zuletzt erfasst: ${escapeText(item.updated_at)}`; card.append(metadata);
    for (const source of item.sources) {
      const row = document.createElement('div'); row.className = 'source';
      const label = document.createElement('strong'); label.textContent = `${escapeText(source.source_name)} · ${escapeText(source.source_family)}`; row.append(label);
      const time = document.createElement('span'); time.textContent = ` · ${escapeText(source.issued_at)} · ${escapeText(source.event_type)}`; row.append(time);
      const link = document.createElement('a'); link.href = source.source_url; link.rel = 'noopener noreferrer'; link.target = '_blank'; link.textContent = ' Quelle öffnen'; row.append(link);
      row.append(document.createTextNode(` · SHA-256 ${escapeText(source.payload_sha256)}`)); card.append(row);
    }
    list.append(card);
  }
}
async function load() {
  errorBox.textContent = '';
  try {
    const response = await fetch('/api/warnings', { cache: 'no-store' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const body = await response.json(); render(body.warnings || []);
  } catch (error) { errorBox.textContent = `Warnmeldungsdienst nicht erreichbar: ${error.message}`; }
}
document.querySelector('#refresh').addEventListener('click', load);
load();
