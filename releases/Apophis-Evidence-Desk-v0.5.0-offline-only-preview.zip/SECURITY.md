# Security, vulnerability disclosure and EU operating boundary

Apophis Evidence Desk is a local, synthetic-data review prototype. It is not an internet-facing service, a trust provider, a qualified eIDAS service, a health-data access body, or a certification of GDPR, NIS2, CRA, AI Act, EHDS, EOSC or Gaia-X compliance.

## Safe operating boundary

Run the review build on loopback only. Do not add real personal, clinical, sensitive research or institutional approval data. Do not expose the server publicly and do not treat a signed bundle, a cryptographic peer identity, a repository publication state or a human approval record as proof of scientific truth, legal permission or safety.

Before a pilot, configure authenticated institutional identities, role and tenant isolation, managed persistence, key custody, backups, retention and deletion, incident response, logging access controls, processor/controller terms, and an independent security and privacy review. Keep external delivery disabled until a specific connector, purpose, recipient, expiry, revocation path and audit evidence have been approved.

The signed release-evidence workflow uses keyless Sigstore/Cosign signing only on trusted `main` runs. It grants `id-token: write` only to the signing job, signs the evidence manifest, SBOM and audit pack, and verifies each bundle against the exact workflow identity. This proves release-integrity and workflow provenance; it does not prove the correctness of evidence, the security of the runtime service, or KRITIS/NIS2 compliance. The detailed readiness boundary is in `KRITIS_READINESS.md`.

The prototype also mirrors mutable domain changes into an append-only, content-addressed local WORM-like store and applies tenant filtering to projects, groups, exchanges, access requests, approvals and privacy operations. The trusted-header HTTP test exercises policy behavior only; it does not provide an identity provider. This is tamper-evident local storage, not physical WORM: production requires object-lock/compliance retention, isolated IAM/KMS, backups, restore tests and database Row-Level Security. Earlier WORM snapshots may retain content after a mutable working record is erased, so real personal data requires a separately approved retention and deletion design. The demo tenant is explicit but unauthenticated; a client-supplied tenant header must never be treated as an identity without a verified OIDC/SAML/AAI adapter.

The local signing identity was not regenerated, read, exported, or used during this review. Keep private key material outside public release archives and do not run `npm run build:bundle` until key custody, rotation, revocation, and backup are explicitly managed.

## Vulnerability disclosure

Report suspected vulnerabilities privately to the project operator through the deployment-specific security contact. Do not publish exploit details, personal data or sensitive biological content in public issues. Include the affected version, endpoint or file, a minimal reproduction, impact, and whether the report uses synthetic data. The operator should acknowledge receipt, preserve evidence, assess severity, coordinate a fix, and publish a redacted advisory after remediation where appropriate.

This document is a project process baseline, not a promise that a future deployment satisfies the Cyber Resilience Act or NIS2. If Apophis is placed on the EU market as a product with digital elements or operated as an in-scope service, perform a separate legal and conformity assessment for the actual economic operator, sector, size, deployment model and Member State obligations.
