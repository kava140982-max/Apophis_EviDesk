# Apophis-Core: Nachweis zum 2.000-Eingaben-Test

## Ergebnis

Am 20. Oktober 2026 wurde der historische Apophis-Core-Grenzwerttest lokal erneut ausgeführt. Ergebnis: **2.000 von 2.000 synthetischen Eingaben wurden vom CBOR-Decoder abgewiesen** (`rejected=2000/2000`, Exitcode 0). Laufzeitumgebung: Python 3.12.3.

Reproduktion im Apophis-Quellverzeichnis:

```sh
python3 scripts/load_test.py
```

Der Test ist deterministisch (`random.Random(82)`). Er erzeugt 2.000 Bytefolgen mit CBOR-Kopf `0x1b` und null bis sieben Folgebytes. Der Kopf kündigt ein acht Byte langes Argument an; die erzeugten Folgen sind deshalb abgeschnitten und müssen vom Decoder abgewiesen werden.

## Was der Test belegt

Der konkret geprüfte Decoder hat in diesem Lauf die getesteten abgeschnittenen CBOR-Eingaben abgewiesen. Das ist ein reproduzierbarer, begrenzter Parser-Grenzwerttest im historischen Apophis-Core-Quellstand.

## Was der Test nicht belegt

Die 2.000 Fälle sind **keine 2.000 realen Angriffe oder 2.000 unterschiedliche Angriffstechniken**. Es handelt sich um synthetische Variationen derselben abgeschnittenen CBOR-Kodierung. Der Lauf ist weder ein Performance-/DoS-Test noch ein unabhängiger Penetrationstest, Fuzzing-Audit, Red-Team-Bericht, Zertifikat oder Sicherheitsnachweis für den Produktivbetrieb. Er weist keine automatische Angriffserkennung nach.

Dieser Nachweis stammt aus dem vorherigen Apophis-Core-Python-Quellstand. Er darf nicht als Testabdeckung des aktuellen Evidence-Desk-Preview-Codes ausgegeben werden. Das aktuelle Preview hat eigene, separat ausgewiesene lokale Regressionstests. Eine direkte Behauptung, der aktuelle Produktcode habe „2.000 Angriffe abgewehrt“, wäre falsch.

## Herkunft und Integritätsreferenzen

Der historische Quellstand liegt im Projektarchiv unter `stiftungsversion/source/Apophis/`.

- Testprogramm: `scripts/load_test.py`
- SHA-256 Testprogramm: `0d239ed72e47eaa295bb380a1a320511af884feb1910618a9e34a1a901f2ce38`
- SHA-256 Decoder `harness/mdoc.py`: `7c6f729c187e4de8e210d0b385f68656e1ae2952b670e7a244e29e8e1718409e`
- SHA-256 historischer Prüfbericht: `710770a7148d09491b456f126e6dba160fb612f282e1a6602f5d90e930b63c91`
- Bericht: `Stiftungsversion_Apophis_18_10_26/02-Testbericht.md`

Der historische Bericht ordnet das Ergebnis als begrenzte synthetische Last-/Grenzwertprüfung ein und schließt Performance-/DoS-Nachweise ausdrücklich aus.
