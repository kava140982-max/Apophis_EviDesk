# WORM-Evidence-Store und Tenant-Isolation

## Implementierter Prototyp

Apophis legt Änderungen an Approvals, Projekten, Access-Requests und Gruppen-Exchanges zusätzlich als content-addressed Snapshots unter `data/worm-evidence/<namespace>/<payload-sha256>.json` ab.

Eigenschaften:

- kein Überschreiben durch `open(..., 'wx')`,
- Dateirechte `0400` für gespeicherte Objekte,
- SHA-256-Adresse aus dem Payload,
- `fsync` vor dem Schließen,
- wiederholtes Speichern desselben Payloads ist idempotent,
- veränderte oder falsch benannte Objekte werden durch `verifyNamespace` erkannt,
- API-Prüfung über `GET /api/audit/worm/verify`.

Die lokale Implementierung ist **append-only und tamper-evident**, aber kein physisches WORM-Medium. Ein Prozess mit Root-/Dateisystemhoheit kann lokale Dateien weiterhin löschen oder Rechte verändern. Für einen produktiven KRITIS-Betrieb muss der WORM-Export in einen getrennten Storage mit Object Lock/Compliance Retention, Versionierung, getrennten IAM-Rollen, KMS, Legal Hold, Restore-Test und unabhängiger Überwachung geschrieben werden.

Privacy-Erasure entfernt den Datensatz aus dem veränderlichen JSON-Arbeitsbestand und lässt Integritätsartefakte bestehen. Frühere append-only Snapshots können deshalb weiterhin den ursprünglichen Inhalt enthalten; dieses Verhalten ist keine bestätigte Löschung und braucht vor echten personenbezogenen Daten ein fachlich und rechtlich freigegebenes Aufbewahrungs-/Löschkonzept.

## Implementierte Tenant-Grenze

Projekte, Gruppen, Gruppen-Exchanges, Access-Requests und neue Approval-Datensätze besitzen `tenant_id`. Approval-Hashketten werden pro Tenant verkettet; alte Datensätze ohne Tenant-ID schlagen die Integritätsprüfung fail-closed fehl. Die API:

- filtert Listen auf den aktiven Tenant,
- gibt fremde Projekte nicht zurück,
- bindet neue Datensätze an den aktiven Tenant,
- filtert Approval-Listen, Status und Privacy-Export auf den aktiven Tenant,
- beschränkt Approval-Erasure auf den aktiven Tenant und verkettet verbleibende Datensätze neu,
- lehnt fehlende Tenant-Kontexte im vertrauenswürdigen Modus ab,
- lehnt fremde oder nicht zulässige Tenant-Header ab,
- versieht Privacy-Export und -Erase mit Tenant-Kontext.

Der lokale Demo-Modus verwendet `synthetic-demo`, ist ausdrücklich nicht authentifiziert und darf nicht als Produktionsmandantentrennung gelten. Für einen echten Betrieb muss ein verifizierter OIDC-/SAML-/AAI-Adapter den Tenant-Kontext setzen. Erst dann darf `APOPHIS_TRUST_TENANT_HEADER=1` hinter dieser Authentifizierung aktiviert werden. Ein frei vom Client gesetzter Header ist keine Identität.

## Produktions-Gate

Vor produktiver Nutzung müssen zusätzlich umgesetzt und geprüft werden:

1. Datenbank mit Row-Level Security und `SET LOCAL app.tenant_id` aus einem verifizierten Auth-Claim,
2. Autorisierung von Objekt-ID, Rolle und Zweck auf jeder Route,
3. Tenant-gebundene KMS-Schlüssel oder dokumentierter Schlüssel-Tenant-Lifecycle,
4. Object-Lock-/WORM-Export mit festgelegter Aufbewahrung und geprüfter Löschung,
5. Backup-/Restore- und Cross-Tenant-Regressionstests,
6. unabhängiger Security-/Privacy-Test und Incident-Response-Übung.

## Verifikation

```bash
npm run test:worm-storage
npm run test:tenant-isolation
npm run test
```

Die Tests prüfen Append-only-Verhalten, Content-Addressing, Überschreibschutz, Hashnamen, Namespace-Validierung, Manipulationserkennung, gültige Tenant-IDs, Default-Kontext, Cross-Tenant-Filterung und Ablehnung untrusted Tenant-Header. `npm run test:tenant-http` startet zusätzlich den Server im Adapter-Modus und prüft HTTP 401 ohne Kontext, Tenant-Filter und den WORM-Statusendpunkt. Dieser Test simuliert nur die Übergabe eines Adapter-Headers; er implementiert keine OIDC-/SAML-Authentifizierung.
