# KRITIS-/High-Assurance-Reifeplan für Apophis

> **Ergänzung 20.10.2026:** Ein maschinenlesbares, quellenverknüpftes Arbeitsregister mit kontrollierter Statusführung, Nachweisverantwortung, Prüffristen und Resilienz-Übungsvorlage liegt in `data/kritis-resilience-catalog.json`, `data/kritis-resilience-register.json` und `data/kritis-exercise-template.json`. Bericht: `npm run kritis:resilience-report`. Der Katalog ist ein nicht vollständiger Arbeitsstartpunkt; der Report kann niemals Konformität ausweisen. Maßgeblich sind die konkrete Betreiber-/Sektoreinstufung und die jeweils geltenden Gesetze, Verordnungen und Standards.

**Status:** technische Readiness-Analyse, keine KRITIS-Zulassung, kein NIS2-Nachweis, kein BSI-Testat und keine rechtliche Beratung.

## Was jetzt realisiert ist

Apophis besitzt eine lokale, fail-closed Evidenzkette: synthetische Daten, signierte Evidence Bundles, tenant-gebundene Approval-Hashketten, SHA-256-Evidenzreports, SBOM-Prüfung, Workflow-Pinning, OpenSSF-Scorecard, keyless Sigstore/Cosign-Signaturen, content-addressed append-only Evidence-Snapshots und serverseitige Filter für Projekt-, Gruppen-, Exchange-, Access- und Approval-Daten.

Der Release-Workflow signiert `manifest.json`, EU-Control-Reports, SBOM und Audit-Pack ohne langlebigen privaten Schlüssel. GitHub OIDC authentifiziert den Workflow gegenüber Sigstore; Cosign erzeugt Sigstore-Bundles und verifiziert sie anschließend gegen die konkrete Workflow-Identität. Das ist Supply-Chain-Evidenz, aber kein Nachweis für die fachliche Wahrheit der Claims oder die Sicherheit eines produktiven KRITIS-Betriebs.

Der lokale WORM-ähnliche Store verhindert Überschreiben auf Anwendungsebene und erkennt Manipulationen. Er ist ausdrücklich kein physisches WORM: Object Lock/Compliance Retention, getrennte IAM-/KMS-Grenzen und unabhängige Restore-Tests stehen noch aus. Der Integrationstest prüft die Header-Policy, simuliert aber keinen Identitätsprovider. Der Demo-Modus ist nicht authentifiziert; der Adapter-Modus beweist selbst keine Identität. Produktionsreife Tenant-Isolation braucht verifizierte Claims und Datenbank-RLS. Frühere WORM-Snapshots können nach einer Privacy-Erasure weiter personenbezogene Inhalte enthalten.

## Dringendste Lücken vor einem echten KRITIS-nahen Pilot

### 1. Identität, Mandantentrennung und Autorisierung

Der aktuelle Actor-Name ist selbst eingegeben. Vor realen Organisationen braucht Apophis institutionelle OIDC-/SAML-/AAI-Anbindung, phishing-resistente MFA, belastbare Rollenattribute, Tenant Boundaries, serverseitige Autorisierung jeder Route und Tests gegen horizontale sowie vertikale Rechteausweitung.

### 2. Zustandsänderungen und Audit-Log unveränderbar machen

Lokale JSON-Dateien und atomisches Schreiben reichen nicht als KRITIS-Audit-Speicher. Benötigt werden append-only Speicherung, verlässliche Zeitquelle, WORM-/immutabler Storage, Schlüssel- und Signaturrotation, getrennte Operatorrechte, manipulationssichere Export-Receipts und ein geprüfter Restore-Pfad.

### 3. Schlüssel- und Vertrauensanker

Sigstore schützt die Release-Evidenz des GitHub-Workflows. Die Apophis-Laufzeitidentität, externe Connectoren und institutionelle Signaturen benötigen zusätzlich KMS/HSM, getrennte Schlüsselrollen, Rotation, Widerruf, Backup/Recovery, Quorum-Freigaben und einen dokumentierten Trust-Anchor-Lifecycle.

### 4. Incident Response und Meldefähigkeit

Es fehlen produktive Alarmierung, 24/7-Verantwortung, Severity-Modell, Forensik-Sicherung, Kommunikationsplan, Wiederanlaufziele und ein Test der Meldewege. Für NIS2-/KRITIS-Szenarien müssen Betreiber, Mitgliedstaat, Sektor, nationale Umsetzung und konkrete Meldefristen geprüft werden; eine grüne Pipeline ersetzt diesen Prozess nicht.

### 5. Wiederherstellbarkeit und Ausfallbetrieb

Vor einem Pilot sind RPO/RTO, getrennte Backups, Restore-Tests, Schlüsselverlust, kompromittierte Artefakte, Connector-Ausfall, Zeitstempel-Ausfall und vollständiger Offline-Betrieb zu testen. Ein „Backup vorhanden“-Dokument ohne ausgeführten Restore ist kein Nachweis.

### 6. Externe Schnittstellen und Supply Chain

Jeder Adapter braucht Authentifizierung, Allowlist, Rate Limits, Timeout, Replay-Schutz, Datenflusskarte, DPA-/Transferbewertung, Revoke/Supersede, Fehler- und Backpressure-Tests. Für Releases sollten SBOM, Provenance, Signatur und Verifikation gemeinsam ausgeliefert werden. CISA beschreibt SBOM als Baustein der Supply-Chain-Risikosteuerung; SLSA unterscheidet nachvollziehbare Provenance, signierte Hosted Builds und gehärtete Builds. [1] [2]

## Reifeziele

### A — Evidence-ready prototype: erreicht

Synthetische Daten, Loopback, reproduzierbare Tests, SHA-256-Reports, SBOM, signierte Bundle- und Release-Evidenz, klare Nicht-Zertifizierungsgrenze.

### B — Controlled synthetic pilot: nächstes Ziel

Institutionelle Testidentitäten, isolierte Testmandanten, managed DB/KMS, immutable Audit-Export, Restore-Test, unabhängiger Connector-Contract-Test, Security Disclosure und tabletop Incident Exercise.

### C — High-assurance service: nur mit Betreiber und Partnern

Threat Model, unabhängige Penetrationstests, formale Rollen-/Rechteprüfung, HSM/KMS, HA/DR, Monitoring/SIEM, 24/7 Incident Response, Lieferantenrisiko, Patch-/Vulnerability-SLA, Datenschutz-Folgenabschätzung und sektorale Zulassungs-/Meldebewertung.

### D — KRITIS-/NIS2-relevanter Betrieb: keine Selbstdeklaration

Die Einstufung hängt vom tatsächlichen Betreiber, Dienst, Sektor, Größe, Mitgliedstaat und nationalen Regeln ab. Sie muss mit zuständigen Stellen und fachlichen Rechts-/Compliance-Verantwortlichen geklärt werden. Apophis darf aus der vorhandenen CI, Sigstore-Signatur oder dem Audit-Pack keine KRITIS-Eigenschaft ableiten.

## Internationale Gesprächsposition

Das glaubwürdige Thema ist nicht „Apophis ist EU-konform“, sondern: **evidence-first, purpose-bound, verifiable release integrity without trust inflation**. Der Beitrag ist eine offene, überprüfbare Referenzkette, die technische Evidenz von fachlicher Wahrheit, Identität von Vertrauen und Prototyp-Readiness von regulatorischer Freigabe trennt.

## References

Aktuelle Primärquellen für das lokale Arbeitsmodell (Abruf/Stand 20.10.2026):

[5]: https://www.gesetze-im-internet.de/bsig_2025/__30.html "BSIG § 30"
[6]: https://www.gesetze-im-internet.de/bsig_2025/__31.html "BSIG § 31"
[7]: https://www.gesetze-im-internet.de/bsig_2025/__32.html "BSIG § 32"
[8]: https://www.gesetze-im-internet.de/bsig_2025/__38.html "BSIG § 38"
[9]: https://www.gesetze-im-internet.de/kritisdachg/__12.html "KRITIS-DachG § 12"
[10]: https://www.gesetze-im-internet.de/kritisdachg/__13.html "KRITIS-DachG § 13"

[1]: https://www.cisa.gov/topics/information-communications-technology-supply-chain-security/sbom "CISA Software Bill of Materials"
[2]: https://slsa.dev/spec/v1.0/levels "SLSA build security levels"
[3]: https://docs.sigstore.dev/quickstart/quickstart-ci/ "Sigstore CI Quickstart"
[4]: https://www.enisa.europa.eu/topics/cybersecurity-policy/nis-directive-new "ENISA NIS Directive 2"
[5]: https://csrc.nist.gov/pubs/sp/800/218/final "NIST Secure Software Development Framework"
