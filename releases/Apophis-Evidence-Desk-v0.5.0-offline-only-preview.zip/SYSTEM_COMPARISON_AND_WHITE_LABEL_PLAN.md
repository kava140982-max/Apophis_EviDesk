# Systemvergleich und White-Label-Plan

## Einordnung

Apophis ist kein vollständiger Ersatz für ein Forschungsdaten-Repository. Sein sinnvollster Platz ist eine Governance-Schicht zwischen Forschungsarbeit, Quellenablage und externer fachlicher Prüfung. Bestehende Systeme lösen Teilprobleme sehr gut; Apophis ergänzt sie dort, wo Claim-Gegenclaim-Logik, sichtbare Unsicherheit, Biosecurity-Blockierung und eine gebundene Approval-Chain gebraucht werden.

## Vergleich mit bestehenden Systemen

### OSF

OSF ist eine breite Forschungsplattform mit Projekten, Dateien, Nutzerverwaltung, Registrierungen, Preprints und Metadaten über eine REST-API. Registrierungen können als dauerhafte, zeitgestempelte Versionen eines Projekts oder von Dateien behandelt werden; die API dokumentiert außerdem OAuth-basierte Authentifizierung und Autorisierung.[1]

OSF ist deshalb stark für Forschungsorganisation, Zusammenarbeit und Vorregistrierung. Es ist aber nicht primär ein defensiver Evidence-Desk mit einer festen Claim-/Gegenclaim-Taxonomie, einem LLM-freien Detailklassen-Blocker und einer auf Bundle-Hashes gebundenen 2-Augen-Regel. Apophis sollte OSF nicht nachbauen, sondern bei Bedarf als Projekt- oder Registrierungsablage ergänzen.

### Zenodo

Zenodo stellt Deposit-, Record- und File-APIs bereit. Der dokumentierte Workflow umfasst Upload und Publikation von Forschungsergebnissen; API-Zugriffe werden authentifiziert und über Scopes wie `deposit:write` und `deposit:actions` begrenzt. Zenodo unterstützt Versionierung sowie DOI-Bezüge und bietet eine Sandbox für Integrationsentwicklung.[2]

Zenodo ist stark für zitierbare, öffentliche Archivierung und DOI-basierte Veröffentlichung. Es ersetzt nicht die lokale Bewertungslogik von Apophis. Ein publiziertes Record sagt nicht automatisch, dass ein Claim fachlich geprüft, biosecurity-seitig unbedenklich oder organisatorisch freigegeben ist.

### Dataverse

Dataverse bietet ein REST-API für wesentliche GUI-Funktionen. Die Dokumentation beschreibt Collections, Datensätze, Metadaten, API-Versionierung sowie Dataset-Versionen und Vergleiche zwischen Versionen.[3]

Dataverse ist daher eine gute Basis für Datenkatalog, Metadaten, Versionen und kontrollierte Veröffentlichung. Apophis kann davor als Evidence- und Gate-Schicht liegen: Der Desk entscheidet nicht über die wissenschaftliche Wahrheit, sondern hält fest, welche Claims, Quellen, Grenzen und Rollen vor einer Veröffentlichung offen sind.

### InvenioRDM

InvenioRDM ist für ein White-Label-Szenario der interessanteste Baustein unter den verglichenen Systemen. Communities können eine eigene visuelle Identität, Logo, URL-Slug und eigene Informations- oder Kurationsseiten erhalten. Es gibt Rollen wie Reader, Curator, Manager und Owner, Submission-Policies, Review-Policies, eingeschränkte Datensätze und Mitgliedsverwaltung.[4]

InvenioRDM liefert damit Repository-, Community- und Kurationsfunktionen, die Apophis nicht selbst implementieren sollte. Apophis könnte als vorgeschaltete Evidence- und Risk-Gate-Komponente dienen. Die eigentliche Identitätsverwaltung, Einladungen, Rechte und Dokumentablage sollten dann in einer gehärteten InvenioRDM- oder vergleichbaren Instanz liegen.

### C2PA / Content Credentials

C2PA beschreibt signierte Manifeste aus Assertions, Claims und Signaturen. Der Standard konzentriert sich auf nachweisbare Provenienz und Manipulationserkennung und soll gerade keine Werturteile darüber abgeben, ob eine Aussage „gut“ oder „schlecht“ ist.[5]

Das ist eine wichtige Ergänzung für Apophis: C2PA-artige Provenienz kann die Herkunft und Integrität eines Exports stärken. C2PA ersetzt aber keine wissenschaftliche Bewertung, keine Rollenprüfung und keine Biosecurity-Entscheidung. Seine Trust-Aussage hängt an der Identität und Gültigkeit des Signers, nicht an der Wahrheit der enthaltenen Behauptung.

## Konsequenz für die Produktpositionierung

Apophis sollte nicht als neues Repository, als KI-Sicherheitszertifikat oder als regulatorischer Ersatz positioniert werden. Die glaubwürdigste Position lautet: **evidence-first governance overlay für risikosensible Forschungsübergaben**.

Die technische Architektur sollte vorhandene Systeme integrieren, statt sie zu verdrängen:

- InvenioRDM oder Dataverse für Record-, Metadaten-, Community- und Versionierungsfunktionen.
- OSF für Projektorganisation, Registrierungen und offene Forschungskoordination.
- Zenodo für öffentliche, DOI-fähige Archivierung ausgewählter Audit-Packs.
- C2PA-inspirierte oder standardkonforme Signatur-/Provenienzmechanismen für Exporte.
- Apophis für Claim-/Gegenclaim-Struktur, Unsicherheitsstatus, Biosecurity-Gate, Approval-Bindung und Audit-Pack.

## White-Labeling: Stiftung oder Genossenschaft?

### Stiftung als Trägerin

Eine Stiftung passt, wenn der Hauptwert in neutraler, gemeinwohlorientierter Infrastruktur, langfristiger Archivierung und unabhängiger Governance liegt. Sie könnte Spezifikation, Referenzimplementierung, Prüfregeln, Transparenzberichte und eine öffentliche Vertrauensmarke verantworten. Vorteil ist die größere Distanz zu einzelnen Auftraggebern. Nachteil sind langsamere Entscheidungswege und die Notwendigkeit stabiler Finanzierung.

### Genossenschaft als Betreiberin

Eine Genossenschaft passt, wenn mehrere Labore, CROs, Hochschulen, Beratungen oder Förderorganisationen gemeinsam Infrastruktur betreiben und über Prioritäten mitentscheiden sollen. Sie könnte Hosting, Support, Integrationen, Schulungen und kostenpflichtige Betriebsmodelle organisieren. Vorteil ist die Nähe zu den Nutzern. Nachteil ist das Risiko, dass zahlende Mitglieder den Governance- oder Review-Standard zu stark beeinflussen.

### Empfohlenes Modell

Für dieses Projekt ist ein **zweistufiges Modell** sinnvoll: Eine Stiftung oder ein gemeinnütziger Verein verwaltet die offene Spezifikation, die Sicherheitsgrenzen, die Referenztests und die unabhängige Beschwerde-/Review-Struktur. Eine Genossenschaft oder ein kooperativer Dienstleister betreibt darauf basierende Instanzen, Integrationen und Support. Beide dürfen nicht so auftreten, als erteile Apophis ein Sicherheits- oder Zulassungssiegel.

## White-Label-Plan in vier Phasen

### Phase 1 — Identität und Governance, 0–30 Tage

Die Trägerin definiert Name, Zweck, Scope, erlaubte Claims, ausgeschlossene Detailklassen, Rollenmodell, Aufbewahrung, Löschung, Schlüsselverwaltung und ein öffentliches Beschwerdeverfahren. Die lokale Demo-Identität wird durch Organisationsidentität, geschützten Key-Store und dokumentierte Rotation ersetzt. Der Rechtsträger veröffentlicht eine klare Nicht-Zertifizierungs- und Nicht-Zulassungsformulierung.

### Phase 2 — Co-Branded Pilot, 31–60 Tage

Ein einzelner ungefährlicher, synthetischer Use Case wird mit zwei unabhängigen Reviewern und einer Biosecurity-Rolle betrieben. Der Pilot misst nicht „wissenschaftlichen Erfolg“, sondern Nachvollziehbarkeit: Anteil der Claims mit Quellen, Gegenclaim-Abdeckung, Zahl blockierter Detailklassen, Zeit bis zur Übergabe und Zahl der offenen Findings. Der Pilot bleibt getrennt von produktiven Labor- oder klinischen Entscheidungen.

### Phase 3 — Integrations- und Betriebsmodell, 61–120 Tage

Apophis wird an ein Repository angebunden, vorzugsweise InvenioRDM oder Dataverse. Ein Audit-Pack wird als unveränderlicher Export mit Bundle-Hash, Provenienz, Rollen, Snapshots und Verifier abgelegt. Optional wird ein DOI-fähiges Archiv wie Zenodo für ausgewählte öffentliche Exporte verwendet. OSF kann für Projekt- und Registrierungsarbeit angeschlossen werden. Kein Connector darf einen Claim automatisch in `geprüft` oder `freigegeben` umwandeln.

### Phase 4 — White-Label-Rollout ab Tag 120

Die Oberfläche erhält die Identität der Trägerin, aber der Footer zeigt weiterhin den technischen Scope und die harte Grenze. Jede Instanz hat eine klar benannte Betreiberin, eine getrennte Review-Policy, eine Schlüsselrotation, eine Exportaufbewahrung, einen Incident-Prozess und einen jährlichen öffentlichen Transparenzbericht. Neue Instanzen werden erst nach einem kontrollierten Negativtest und einem Offline-Verifier-Test freigeschaltet.

## Marken- und Lizenzregeln

Der Markenname der Trägerin sollte nicht mit „approved“, „certified“, „safe“ oder „regulatory-ready“ verbunden werden. Zulässige Formulierungen sind etwa „Evidence Governance Workspace“, „Due-Diligence-Desk“ oder „Provenance and Review Infrastructure“. Eine offene Kernlizenz kann die Referenzimplementierung zugänglich machen; gehostete Services, Support, Integrationen und optionale Module können separat finanziert werden. Der unabhängige Review- und Beschwerdeprozess muss auch gegen zahlende Betreiber oder Mitglieder funktionieren.

## Entscheidung

White-Labeling ist sinnvoll, wenn es als neutrale Governance-Infrastruktur mit klarer Nicht-Zertifizierungsgrenze erfolgt. Eine Stiftung ist der bessere Träger für Regeln, Marke und Unabhängigkeit. Eine Genossenschaft ist der bessere Betreiber für gemeinschaftliche Services. Ein Hybrid aus beiden ist glaubwürdiger als eine reine kommerzielle Lizenzierung oder eine Produktmarke, die implizit Sicherheitsfreigaben verspricht.

## References

[1]: https://developer.osf.io/ "OSF API v2 Documentation"
[2]: https://developers.zenodo.org/ "Zenodo REST API Documentation"
[3]: https://guides.dataverse.org/en/latest/api/native-api.html "Dataverse Native API"
[4]: https://inveniordm.docs.cern.ch/use/communities/ "InvenioRDM Communities"
[5]: https://spec.c2pa.org/specifications/specifications/2.4/specs/C2PA_Specification.html "C2PA Technical Specification 2.4"

---

**KaVa-14.10.26**
