# Emergency control and authority recipient prototype (v0.4.6)

## What it does

This prototype implements an **Apophis application-level emergency lock**. Once the trigger is authorized, `server.js` returns HTTP 503 for every request while `data/emergency-control/lock.json` exists. The trigger creates a compressed application-data snapshot, encrypts it with AES-256-GCM, wraps the temporary data key for one specifically configured authority recipient's RSA public key (RSA-3072 or stronger), and writes the encrypted package to an external directory. Release requires a new authorization for the exact lock-file hash. The authorization adapter must confirm at least two distinct authenticated people for both operations.

The recipient registry is per installation and per institutional jurisdiction. It names an authority/office and pins the SHA-256 fingerprint of its public key. The private recipient key stays with that authority; Apophis never receives it. A recipient public key is not an authority to operate the system or a universal master key. Changing a minister/office holder does not automatically change the encryption key: the institution must rotate the recipient entry/key through its approved process.

## Scope limits

- The snapshot contains application files under `data/` only. It is **not** a host, operating-system, disk, or full-system image.
- The encrypted file is staged at a pre-approved external path. This prototype has no remote transfer client, external-server identity, scheduling, automatic retention/deletion policy, or delivery receipt. A deployment must configure and independently review those pieces before calling it a remote backup.
- `data/keys/` and emergency-control runtime state are excluded. Signing-key recovery requires a separate institutional KMS/HSM procedure.
- The emergency lock disables Apophis HTTP service routes only. It does not shut down the computer, network, power, SCADA, safety systems, warning systems, or other OT equipment. Physical emergency actions belong to independently engineered site procedures and authorized operators.
- If snapshot creation fails after the application lock is written, the application stays locked. `emergency:status` reports the incomplete snapshot state; release still requires two-person authorization.
- This is a prototype contract. The real identity adapter, deployment file permissions, recipient-key provenance, secure transfer and deletion, key custody, and recovery exercise are not supplied here. Do not use it with operational or classified data.

## Configure one authority recipient

1. Obtain the public key from the named authority using a separately verified institutional channel. The recipient should create and retain its private key in its own controlled KMS/HSM. Do not copy a private key into this project.
2. Copy `config/authority-recipients.example.json` to the ignored local file `config/authority-recipients.json`. Configure one entry with a stable office/authority ID, jurisdiction, absolute public-key path, and `enabled: true` only after verification.
3. Pin `public_key_sha256` to SHA-256 over the key's DER-encoded SubjectPublicKeyInfo, for example `openssl pkey -pubin -in /absolute/path/to/authority-recipient-public.pem -outform DER | sha256sum`. The program recomputes this fingerprint at trigger time and refuses a mismatch. The example entry is disabled and intentionally unusable.
4. Set `APOPHIS_EMERGENCY_EVIDENCE_DIR` to an institutionally approved directory outside this project. It must be mounted on the intended external evidence/backup server if remote storage is desired.
5. Set `APOPHIS_EMERGENCY_AUTHORIZER` to the absolute path of an institutional adapter. The adapter must authenticate distinct people (not trust caller-provided names), bind approval to operation, resource hash and expiry, return the `apophis/dual-control-authorization/v1` JSON contract, and audit the approvals. It must handle `emergency_trigger` and `emergency_release`. This repo does not include or simulate such an adapter.

The authorization response has this shape (values are illustrative):

```json
{
  "schema": "apophis/dual-control-authorization/v1",
  "decision": "allow",
  "operation": "emergency_trigger",
  "resource_sha256": "<requested digest>",
  "authorization_id": "<adapter-issued id>",
  "distinct_actors": ["<verified actor 1>", "<verified actor 2>"],
  "expires_at": "<short-lived future timestamp>"
}
```

## Commands

```bash
npm run emergency:status
APOPHIS_EMERGENCY_AUTHORIZER=/absolute/path/to/adapter \
APOPHIS_EMERGENCY_EVIDENCE_DIR=/mnt/approved-external-evidence/apophis \
npm run emergency:trigger -- example-ministry-office
APOPHIS_EMERGENCY_AUTHORIZER=/absolute/path/to/adapter npm run emergency:release
```

`emergency:trigger` requires the authority ID in the enabled local registry, a matching RSA public key, an external evidence destination and two approvals. It locks the Apophis web service before writing the encrypted package. Do not stop the process or remove the lock file as a routine way to release it. `emergency:release` binds two-person authorization to the current exact lock file, writes a hash-linked release event, then removes the application lock.

No government master key is embedded. Each configured authority recipient has a separate public key and can decrypt only packages encrypted for its corresponding private key. A public key alone cannot decrypt a package. Key rotation and authority succession are institutional responsibilities.
