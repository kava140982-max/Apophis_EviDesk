# Apophis Allrounder — System-Entscheidungsmatrix

## Bewertungslogik

Die Matrix trennt drei Zustände: `vorhanden` bedeutet, dass ein System die Funktion dokumentiert; `integrierbar` bedeutet, dass sie über API, Export oder Adapter angebunden werden kann; `verifiziert` bedeutet, dass sie in diesem Projekt tatsächlich reproduzierbar getestet wurde. Eine Fremdsystem-Funktion wird nicht als Apophis-Funktion gezählt.

Bewertung: 0 = nicht ersichtlich, 1 = teilweise oder extern, 2 = stark dokumentiert. Die Gewichte sind eine Startannahme für einen gemeinwohlorientierten Evidence-Desk und müssen vor einer Beschaffung mit realen Kosten- und Datenschutzdaten bestätigt werden.

| Kriterium | Gewicht | Apophis | OSF | Zenodo | Dataverse | InvenioRDM | C2PA |
|---|---:|---:|---:|---:|---:|---:|---:|
| Claim-/Gegenclaim-Governance | 5 | 2 | 0 | 0 | 0 | 0 | 0 |
| Unsicherheits- und Boundary-Status | 5 | 2 | 1 | 0 | 1 | 1 | 0 |
| Quellen-/Passage-/Hash-Bezug | 5 | 2 | 1 | 2 | 2 | 2 | 2 |
| Rollen und Review-Workflow | 5 | 2 | 2 | 1 | 1 | 2 | 0 |
| Offline-Verifikation | 5 | 2 | 0 | 1 | 1 | 1 | 2 |
| Repository und Versionierung | 4 | 1 | 2 | 2 | 2 | 2 | 0 |
| Community-/White-Label-Fähigkeit | 4 | 1 | 1 | 1 | 2 | 2 | 0 |
| API-/Integrationsfähigkeit | 4 | 1 | 2 | 2 | 2 | 2 | 1 |
| Biosecurity-Detailgate | 5 | 2 | 0 | 0 | 0 | 0 | 0 |
| Offene / portable Exporte | 4 | 2 | 1 | 2 | 2 | 2 | 1 |
| **Gewichtete Lesart** |  | **Governance-Layer** | **Projekt-/Registrierungsplattform** | **Publikationsarchiv** | **Datenrepository** | **White-Label-Repository** | **Provenienzbaustein** |

## Entscheidung

Keines der Systeme ist allein der komplette Allrounder. Die sinnvollste Architektur ist ein Verbund: Apophis für Evidence-Governance und harte Grenzen, InvenioRDM oder Dataverse als Repository-/Community-Schicht, OSF für offene Projekt- und Registrierungsarbeit, Zenodo für ausgewählte DOI-Exporte und C2PA-/Sigstore-/in-toto-artige Mechanismen für öffentliche Provenienz.

Die Zahlen sind keine unabhängige Produktprüfung und kein Beschaffungsurteil. Vor einer realen Auswahl müssen Lizenz, Hosting, Datenresidenz, Support, SSO, Backup, Kosten und Sicherheitskonfiguration separat geprüft werden.

---

**KaVa-14.10.26**
