# Europaweite Vorgaben: Recherche, Anwendbarkeit und Verbesserungsplan

**Stand:** 20. Oktober 2026  
**Projekt:** Apophis Evidence Desk, lokale Review-/Härtungskopie  
**Bewertungsgrenze:** technische Readiness-Analyse, keine Rechtsberatung und keine Konformitätszertifizierung.

## Ergebnis der Projektprüfung

Die vorhandenen Selbsttests waren grün und belegen für die lokale Demo mehrere konkrete Eigenschaften: Bundle-Receipt und Ed25519-Signatur sind prüfbar, die Approval-Chain ist an den Bundle-Hash gebunden, Reject/Escalate blockieren das Gate, externe Synchronisation ist standardmäßig aus, DNS-Pinning-/Redirect-Regeln werden negativ getestet, und Privacy-Endpunkte sind actor-scoped Readiness-Bausteine.

Ein echter Befund war die Daten-/Profildrift in `data/trust-registry.json`: Der Bestand enthielt `identified-local`, obwohl `data/self-description.json` nur die veröffentlichte Zustandsmaschine mit `cryptographically-identified` kennt. Der Zustand wurde korrigiert. Der Conformance-Test prüft nun jeden gespeicherten Eintrag gegen die Zustandsliste, Ablaufdatum, Identifikatoren und Evidenz-Referenzen. Damit wird diese Drift künftig fail-closed sichtbar.

Das Projekt bleibt bewusst außerhalb eines produktiven Mehrbenutzerbetriebs. Es fehlen insbesondere institutionell bestätigte Identität, Authentifizierung und Autorisierung, Mandantentrennung, verwaltete Schlüssel, unabhängige Zeitstempel, belastbare Lösch-/Backup-Prozesse, Incident Response und reale Connector-Contract-Tests.

## Was europaweit wirklich gilt und wann es relevant wird

### DSGVO / GDPR: bereits bei echten Personenbezügen relevant

Die DSGVO gilt für die Verarbeitung personenbezogener Daten durch automatisierte Mittel sowie unter den territorialen Voraussetzungen des Artikels 3. Ihre Grundsätze umfassen unter anderem Zweckbindung, Datenminimierung, Speicherbegrenzung, Integrität/Vertraulichkeit und Rechenschaftspflicht. Artikel 25 verlangt Datenschutz durch Technikgestaltung und durch datenschutzfreundliche Voreinstellungen; die EDPB-Leitlinien erläutern dafür Schutzmaßnahmen, Transparenz, Kontrolle und Nachweisbarkeit. [1] [2]

Für Apophis bedeutet das: Approval-Actors, Rollen, Begründungen, Projektmitgliedschaften, Quell-URLs und Zeitstempel dürfen nicht als harmlose Demo-Felder behandelt werden, sobald sie reale Personen identifizieren. Vor einem Pilot sind Verantwortlicher/Auftragsverarbeiter bzw. gemeinsame Verantwortlichkeit, Zweck und Rechtsgrundlage, Informationspflichten, Verzeichnis der Verarbeitungstätigkeiten, Lösch- und Backup-Lifecycle, Betroffenenrechte, Zugriffsschutz, Drittlandtransfers und eine DPIA-Entscheidung zu dokumentieren. Hashes sichern Integrität; sie ersetzen keine Löschung und keine Rechtsgrundlage.

### AI Act: bedingt, aber früh als Produktgrenze relevant

Der AI Act erfasst Anbieter und Betreiber von AI-Systemen auch grenzüberschreitend, wenn die gesetzlich beschriebenen EU-Bezüge vorliegen. Für Hochrisiko-Systeme nennt der Rechtsakt unter anderem Risikomanagement, technische Dokumentation, Aufzeichnungen, Transparenz, menschliche Aufsicht, Robustheit, Genauigkeit und Cybersicherheit. [3]

Der aktuelle Kern ist ausdrücklich LLM-frei und nutzt einen begrenzten heuristischen Scanner. Das verhindert keine spätere Anwendbarkeit. Sobald Apophis Evidenz automatisch bewertet, Personen oder Projekte priorisiert, Zugangsentscheidungen vorbereitet oder generative Ausgaben in einem regulierten Kontext liefert, braucht das Projekt eine dokumentierte Klassifizierung, Zweck-/Rollenanalyse, Human-Oversight-Gate, Protokollierung, Daten-Governance und gegebenenfalls Anbieter-/Betreiberpflichten. Eine Signatur oder Approval-Chain ist kein Ersatz für AI-Risikomanagement.

### NIS2: abhängig von Betreiber, Größe, Sektor und nationaler Umsetzung

NIS2 richtet Pflichten an bestimmte öffentliche/private Einrichtungen in den Anhängen I/II, typischerweise ab mittlerer Unternehmensgröße, mit zusätzlichen größenunabhängigen Fällen. In-scope Einrichtungen müssen angemessene Cyber-Risikomanagementmaßnahmen vorsehen und Sicherheitsvorfälle melden. [4]

Für den lokalen Einzelprototyp ist daraus kein pauschaler NIS2-Status ableitbar. Die Anwendbarkeit kann sich ändern, wenn ein Betreiber als relevante digitale Infrastruktur, Forschungsorganisation, Anbieter eines erfassten Dienstes oder kritischer Akteur tätig wird. Vor dem Pilot sind Betreiber, Sektor, Unternehmensgröße, Mitgliedstaat, nationale Umsetzung, Lieferkette, Business Continuity, Incident-Kontakte und Meldefristen zu prüfen. Technisch fehlen heute ein produktiver Incident-Prozess, zentrale Zugriffsverwaltung, Monitoring und wiederherstellbare Backups.

### Cyber Resilience Act: relevant, wenn das Projekt als Produkt mit digitalen Elementen bereitgestellt wird

Der CRA legt Anforderungen für Produkte mit digitalen Elementen fest, die auf dem EU-Markt bereitgestellt werden, einschließlich sicherer Entwicklung und Vulnerability Handling über den erwarteten Nutzungszeitraum. Er nennt unter anderem koordinierte Schwachstellenmeldung und SBOM-Transparenz als wichtige Bausteine. [5]

Das ZIP ist zunächst eine lokale Review-Kopie und kein Marktprodukt. Wenn daraus ein vermarktetes oder öffentlich bereitgestelltes Softwareprodukt wird, muss die Rolle des Herstellers bzw. Wirtschaftsakteurs, der Supportzeitraum, die Konformitätsbewertung, die Meldung aktiv ausgenutzter Schwachstellen, sichere Updates und die technische Dokumentation separat geprüft werden. `SANDBOX-SBOM.json` und `SECURITY.md` sind dafür Readiness-Artefakte, kein CRA-Nachweis.

### eIDAS / European Digital Identity: Identität ist nicht dasselbe wie Vertrauen

Die eIDAS-Änderung erweitert den europäischen Identitätsrahmen um Wallets, elektronische Identifizierung, elektronische Attributnachweise und Trust Services. Qualifizierte Dienste und bestimmte Nachweise werden unionsweit anerkannt. [6]

Apophis verwendet derzeit selbst deklarierte Actor-Namen und lokale Ed25519-Schlüssel. Das beweist Schlüsselbesitz, aber keine institutionelle Zugehörigkeit, Rolle oder qualifizierte Identität. Ein Produktionspfad sollte zuerst provider-neutrale OIDC-/SAML-/föderierte AAI-Attribute einführen und nur bei einem konkreten Anwendungsfall eIDAS-Wallets, Organisationsnachweise, Siegel oder qualifizierte Zeitstempel bewerten. Keine eIDAS- oder qualifizierte Vertrauensbehauptung aus dem lokalen Schlüssel ableiten.

### EHDS: nur bei elektronischen Gesundheitsdaten und dem einschlägigen Nutzungsszenario

EHDS ergänzt den Gesundheitsdatenrahmen. Für Sekundärnutzung sieht die Verordnung unter anderem Health Data Access Bodies, Datenbewilligungen, rechtliche Grundlagen, Zweckbindung und sichere Verarbeitungsumgebungen vor. Gesundheitsdaten bleiben zugleich dem DSGVO-Rahmen unterworfen. [7]

Apophis muss Gesundheitsdaten im Standardbetrieb ausschließen. Ein späterer Health-Pilot darf nicht einfach einen Download-Connector aktivieren. Er braucht einen separaten Betreiber, Genehmigungs-/Permit-Modell, Datengeber- und Governance-Prozess, Pseudonymisierung, Secure Processing Environment, erlaubte Operationen, Ergebnisprüfung, Ablauf und Widerruf. Das vorhandene Feld `export_allowed: false` ist nur ein sicherer Default, kein EHDS-Nachweis.

## Priorisierter Umsetzungsplan

### Sofort, vor jedem externen Pilot

1. Den neuen `test:eu-controls` zusammen mit `npm test` ausführen und die gespeicherte Trust-Registry als versionsgebundenes Artefakt behandeln.
2. Alle öffentliche Projekttexte auf „Readiness“, „synthetisch“ und „keine Zertifizierung“ begrenzen; keine Begriffe wie „EU-konform“, „vertrauenswürdig“ oder „zugelassen“ ohne konkreten Scope verwenden.
3. Einen Disclosure-Kontakt, Security-Policy, SBOM-Erzeugung mit reproduzierbarem Build und Release-Hash etablieren.
4. Ein Dateninventar für Actors, Access Requests, Logs, Exporte, Snapshots, Backups und Connectoren anlegen. Für jedes Feld Zweck, Rechtsgrundlage, Aufbewahrung, Empfänger und Löschverhalten festlegen.
5. Für reale Nutzer einen authentifizierten Identitätsadapter und Rollen-/Mandantengrenzen implementieren. Selbst eingegebene Actor-Namen dürfen nur Demo-Modus sein.

### Pilot mit synthetischen oder öffentlichen Daten

1. Einen unabhängigen Contract-Client gegen eine isolierte Dataverse-, InvenioRDM- oder Zenodo-Sandbox testen: Export, Read-back, Versionierung, Supersede, Revoke, Fehler und Rate Limits.
2. Trust-State-Übergänge mit Aussteller, Zweck, Evidenz, Ablauf und Widerruf als append-only Ereignisse modellieren. Keine Community- oder Domain-Zugehörigkeit automatisch vererben.
3. Ein externes Review-Gremium definieren: Betreiber, Datenverantwortliche, Datenschutz und Security dürfen nicht in einer unkontrollierten Rolle zusammenfallen.
4. Für jeden Connector einen Datenfluss- und Transfernachweis erzeugen. Externe Veröffentlichungszustände dürfen weiterhin keine Apophis-Freigabe bedeuten.

### Erst nach konkreter Betreiber- und Partnerentscheidung

1. AI-Act-Klassifizierung durchführen, sobald Ranking, Empfehlung, Generierung oder automatisierte Entscheidung hinzukommt.
2. NIS2-/CRA-Scope anhand der tatsächlichen Organisation, Größe, Leistung und Marktbereitstellung mit den zuständigen Stellen prüfen.
3. eIDAS-Wallet, Organisationsattribute, qualifizierte Siegel oder Zeitstempel nur für einen klar definierten Identitäts-/Beweisbedarf integrieren.
4. Für Gesundheitsdaten einen EHDS-/DSGVO-spezifischen Secure-Processing-Pilot mit Permit- und Downloadverbot aufsetzen.

## Quellen und Grenzen

Die Regelwerksbewertung ist eine Anwendbarkeits- und Designanalyse. Sie ersetzt keine Prüfung durch Datenschutzbeauftragte, Rechtsberatung, nationale Aufsichtsbehörden, Konformitätsbewertungsstellen oder einen unabhängigen Security-Auditor. Rechtsakte können durch nationale Durchführung, Delegierte-/Durchführungsakte und spätere Änderungen ergänzt werden.

## References

[1]: https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng "Regulation (EU) 2016/679 (GDPR)"
[2]: https://www.edpb.europa.eu/documents/guideline/guidelines-42019-on-article-25-data-protection-by-design-and-by-default_en "EDPB Guidelines 4/2019 on data protection by design and by default"
[3]: https://eur-lex.europa.eu/eli/reg/2024/1689/oj/eng "Regulation (EU) 2024/1689 (AI Act)"
[4]: https://eur-lex.europa.eu/eli/dir/2022/2555/oj/eng "Directive (EU) 2022/2555 (NIS2)"
[5]: https://eur-lex.europa.eu/eli/reg/2024/2847/oj/eng "Regulation (EU) 2024/2847 (Cyber Resilience Act)"
[6]: https://eur-lex.europa.eu/eli/reg/2024/1183/oj/eng "Regulation (EU) 2024/1183 amending eIDAS"
[7]: https://eur-lex.europa.eu/eli/reg/2025/327/oj/eng "Regulation (EU) 2025/327 (European Health Data Space)"
