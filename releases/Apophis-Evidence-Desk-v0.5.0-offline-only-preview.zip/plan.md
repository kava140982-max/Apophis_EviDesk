# Apophis Evidence Desk — Plan

## Ziel

Ein verständliches, lokales Dashboard für den Apophis Profile Core. Es zeigt, was das System tut, warum die drei Profile getrennt sind, welche Evidence- und Human-Gates aktiv sind und wie ein synthetischer HCMV-Research-Run aussieht.

## Produktentscheidungen

- Statisches, dependency-freies Node-Dashboard.
- Keine Datenbank, kein Login, keine externen Connectoren.
- Öffentliche Referenzen werden als versionierte, sichtbare Quellenkarten eingebaut.
- Keine Ausführung von Uploads, kein LLM und keine automatische Freigabe.
- Observation, Assessment und Decision bleiben sichtbar getrennt.

## Design

- Bewegung: defensives Evidence-Labor zwischen Leitstand und Whitepaper.
- Prinzipien: Klarheit vor Dekoration, Evidenz vor Behauptung, ruhige Warnungen, sichtbare Grenzen.
- Farben: dunkle Graphitflächen, warmes Papierweiß, Apophis-Türkis als Vertrauenssignal, Amber nur für offene Prüfung.
- Layout: linke Kontext-Rail, breite Evidence-Fläche, rechte Review-Spalte.
- Typografie: systemische Sans-Schrift, monospace für IDs, Hashes und Quellenstatus.
- Markenstimme: direkt, ruhig, nicht alarmistisch. Beispiele: „Beweise statt Bauchgefühl.“ und „Prüfen heißt nicht freigeben.“

## Projektstruktur

- `server.js`: statischer Server und Healthcheck.
- `public/`: Dashboard, Styles und Interaktion.
- `data/public-references.json`: öffentliche Referenzen mit Abrufdatum und Aussagegrenzen.
- `README.md`: verständliche Erklärung für Betrieb und Bedeutung.
- `manus-routes.json`: Seitenroute für Preview und Veröffentlichung.

---

**KaVa-14.10.26**
