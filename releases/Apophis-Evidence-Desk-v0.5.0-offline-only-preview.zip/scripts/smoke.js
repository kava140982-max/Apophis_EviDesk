// KaVa-14.10.26 — review watermark
const http = require('http');
const { spawn } = require('child_process');
const child = spawn(process.execPath, ['server.js'], { stdio: 'ignore', env: { ...process.env, PORT: '3311', HOST: '127.0.0.1' } });
const get = (url) => new Promise((resolve, reject) => { const req = http.get(url, (res) => { let data = ''; res.on('data', c => data += c); res.on('end', () => resolve({ status: res.statusCode, data })); }); req.on('error', reject); });
(async () => { try { for (let i = 0; i < 20; i++) { try { const health = await get('http://127.0.0.1:3311/health'); if (health.status === 200) { const page = await get('http://127.0.0.1:3311/'); if (page.status !== 200) throw new Error('dashboard_not_ready'); console.log('SMOKE_OK'); process.exit(0); } } catch (_) {} await new Promise(r => setTimeout(r, 100)); } throw new Error('server_timeout'); } catch (error) { console.error(error.message); process.exitCode = 1; } finally { child.kill(); } })();
