#!/usr/bin/env node
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const workflowDir = path.join(root, '.github', 'workflows');
const workflowFiles = fs.readdirSync(workflowDir).filter((name) => name.endsWith('.yml') || name.endsWith('.yaml')).sort();
assert.ok(workflowFiles.length >= 2, 'expected CI and Scorecard workflows');
const failures = [];
for (const name of workflowFiles) {
  const content = fs.readFileSync(path.join(workflowDir, name), 'utf8');
  assert.ok(!content.includes('pull_request_target'), `${name}: privileged pull_request_target is forbidden`);
  const usesLines = content.split(/\r?\n/).filter((line) => /\buses:\s*/.test(line));
  for (const line of usesLines) {
    const match = line.match(/uses:\s*([^\s#]+)/);
    if (!match || match[1].startsWith('./')) continue;
    const at = match[1].lastIndexOf('@');
    const ref = at === -1 ? '' : match[1].slice(at + 1);
    if (!/^[0-9a-f]{40}$/.test(ref)) failures.push(`${name}: action is not pinned to a full commit SHA: ${match[1]}`);
  }
}
assert.deepEqual(failures, [], failures.join('\n'));
const release = fs.readFileSync(path.join(workflowDir, 'release-evidence.yml'), 'utf8');
assert.match(release, /push:\s*\n\s*branches:\s*\[main\]/, 'release evidence may run on main pushes');
assert.match(release, /workflow_dispatch:/, 'manual release-evidence run must be available');
assert.doesNotMatch(release, /^\s*(?:pull_request|pull_request_target):/m, 'release workflow must not run on pull requests');
assert.match(release, /if:\s*github\.ref == 'refs\/heads\/main'/, 'signer job must fail closed outside main');
assert.match(release, /persist-credentials:\s*false/);
assert.match(release, /node-version:\s*'20(?:\.x)?'/);
assert.match(release, /npm test/);
assert.match(release, /npm run export:pack/);
assert.match(release, /npm run evidence:manifest/);
assert.match(release, /cosign sign-blob/);
assert.match(release, /cosign verify-blob/);
assert.equal((release.match(/id-token:\s*write/g) || []).length, 1, 'OIDC permission must be limited to one signing job');
assert.match(release, /github\.repository/);
assert.match(release, /\.github\/workflows\/release-evidence\.yml@refs\/heads\/main/);
assert.match(release, /--certificate-oidc-issuer/);
for (const artifact of ['artifacts/release-evidence/manifest.json', 'artifacts/eu-controls-result.json', 'artifacts/eu-controls-evidence.json', 'SANDBOX-SBOM.json', 'public/apophis-audit-pack.zip']) {
  assert.ok(release.includes(artifact), `release workflow must include ${artifact}`);
}
console.log(JSON.stringify({ verdict: 'PASS', workflows: workflowFiles, actions_pinned_to_full_sha: true, trusted_main_only_release_signing: true, privileged_pull_request_target: false }, null, 2));
