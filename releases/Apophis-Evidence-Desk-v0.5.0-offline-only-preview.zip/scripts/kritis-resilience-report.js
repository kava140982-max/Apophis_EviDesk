#!/usr/bin/env node
'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const allowedStatuses = new Set(['not_assessed', 'in_progress', 'evidenced', 'needs_remediation', 'accepted_risk', 'not_applicable']);
const allowedApplicability = new Set(['not_assessed', 'applicable', 'not_applicable']);
const allowedActionStatuses = new Set(['open', 'in_progress', 'complete', 'cancelled']);
const allowedPdcaStages = new Set(['plan', 'do', 'check', 'act']);

function evidenceFile(relativePath) {
  if (typeof relativePath !== 'string' || !relativePath.trim() || path.isAbsolute(relativePath)) throw new Error('evidence_path_must_be_relative');
  const absolute = path.resolve(root, relativePath);
  if (!absolute.startsWith(`${root}${path.sep}`)) throw new Error('evidence_path_escapes_project');
  const realRoot = fs.realpathSync(root);
  const real = fs.realpathSync(absolute);
  if (!real.startsWith(`${realRoot}${path.sep}`)) throw new Error('evidence_symlink_escapes_project');
  const stat = fs.statSync(real);
  if (!stat.isFile()) throw new Error('evidence_path_not_file');
  return { path: path.relative(root, real), bytes: stat.size, sha256: crypto.createHash('sha256').update(fs.readFileSync(real)).digest('hex') };
}

function buildReport({ catalog, register, now = new Date() }) {
  const errors = [];
  if (catalog?.schema !== 'apophis/kritis-resilience-catalog/v1' || catalog.not_a_certification !== true) errors.push('invalid_catalog_or_certification_boundary');
  if (register?.schema !== 'apophis/kritis-resilience-register/v1' || register.not_a_certification !== true) errors.push('invalid_register_or_certification_boundary');
  if (catalog?.catalog_version !== register?.catalog_version) errors.push('catalog_version_mismatch');
  const controls = new Map((catalog?.controls || []).map((control) => [control.id, control]));
  const seen = new Set();
  const entries = [];
  for (const record of register?.records || []) {
    const control = controls.get(record.control_id);
    const rowErrors = [];
    if (!control) rowErrors.push('unknown_control');
    if (seen.has(record.control_id)) rowErrors.push('duplicate_record');
    seen.add(record.control_id);
    if (!allowedStatuses.has(record.status)) rowErrors.push('invalid_status');
    if (!allowedApplicability.has(record.applicability)) rowErrors.push('invalid_applicability');
    if (!allowedPdcaStages.has(record.pdca_stage)) rowErrors.push('invalid_pdca_stage');
    if (record.status === 'evidenced' && (!Array.isArray(record.evidence_refs) || record.evidence_refs.length === 0)) rowErrors.push('evidenced_without_evidence_reference');
    if (record.status === 'not_applicable' && record.applicability !== 'not_applicable') rowErrors.push('not_applicable_status_requires_applicability_decision');
    if (record.owner !== null && (typeof record.owner !== 'string' || !record.owner.trim())) rowErrors.push('invalid_owner');
    if (record.review_due !== null && (!/^\d{4}-\d{2}-\d{2}$/.test(record.review_due) || Number.isNaN(Date.parse(`${record.review_due}T00:00:00Z`)))) rowErrors.push('invalid_review_due');
    const actions = Array.isArray(record.actions) ? record.actions : [];
    if (!Array.isArray(record.actions)) rowErrors.push('actions_must_be_array');
    const actionIds = new Set();
    const reportedActions = actions.map((action) => {
      const actionErrors = [];
      if (!action || typeof action !== 'object' || Array.isArray(action)) {
        rowErrors.push('action:unknown:invalid_action');
        return { id: null, status: null, owner: null, due_date: null, overdue: false, errors: ['invalid_action'] };
      }
      if (typeof action.id !== 'string' || !action.id.trim() || actionIds.has(action.id)) actionErrors.push('invalid_or_duplicate_action_id');
      else actionIds.add(action.id);
      if (!allowedActionStatuses.has(action.status)) actionErrors.push('invalid_action_status');
      if (typeof action.owner !== 'string' || !action.owner.trim()) actionErrors.push('invalid_action_owner');
      if (action.due_date !== null && action.due_date !== undefined && (!/^\d{4}-\d{2}-\d{2}$/.test(action.due_date) || Number.isNaN(Date.parse(`${action.due_date}T00:00:00Z`)))) actionErrors.push('invalid_action_due_date');
      const overdueAction = Boolean(action.due_date && action.due_date < now.toISOString().slice(0, 10) && !['complete', 'cancelled'].includes(action.status));
      if (overdueAction) actionErrors.push('action_overdue');
      rowErrors.push(...actionErrors.map((error) => `action:${action.id || 'unknown'}:${error}`));
      return { id: action.id || null, status: action.status || null, owner: action.owner || null, due_date: action.due_date || null, overdue: overdueAction, errors: actionErrors };
    });
    const hashedEvidence = [];
    for (const ref of record.evidence_refs || []) {
      try { hashedEvidence.push(evidenceFile(ref)); }
      catch (error) { rowErrors.push(`evidence:${ref}:${error.message}`); }
    }
    const overdue = Boolean(record.review_due && record.review_due < now.toISOString().slice(0, 10));
    if (overdue) rowErrors.push('review_overdue');
    entries.push({ control_id: record.control_id, topic: control?.topic || null, source: control?.source || null, intent: control?.intent || null, applicability: record.applicability, status: record.status, pdca_stage: record.pdca_stage, owner: record.owner, review_due: record.review_due, overdue, actions: reportedActions, evidence: hashedEvidence, notes: record.notes || '', errors: rowErrors });
    errors.push(...rowErrors.map((error) => `${record.control_id}:${error}`));
  }
  for (const id of controls.keys()) if (!seen.has(id)) errors.push(`${id}:register_record_missing`);
  return {
    schema: 'apophis/kritis-resilience-report/v1',
    generated_at: now.toISOString(),
    catalog_version: catalog?.catalog_version || null,
    jurisdiction: catalog?.jurisdiction || null,
    assessment_scope: register?.assessment_scope || null,
    organization_ref: register?.organization_ref || null,
    service_ref: register?.service_ref || null,
    verdict: 'WORKING_REGISTER_ONLY',
    not_a_certification: true,
    errors,
    summary: {
      controls: entries.length,
      not_assessed: entries.filter((entry) => entry.status === 'not_assessed').length,
      in_progress: entries.filter((entry) => entry.status === 'in_progress').length,
      evidenced: entries.filter((entry) => entry.status === 'evidenced').length,
      needs_remediation: entries.filter((entry) => entry.status === 'needs_remediation').length,
      accepted_risk: entries.filter((entry) => entry.status === 'accepted_risk').length,
      not_applicable: entries.filter((entry) => entry.status === 'not_applicable').length,
      overdue_reviews: entries.filter((entry) => entry.overdue).length,
      corrective_actions: entries.reduce((sum, entry) => sum + entry.actions.length, 0),
      open_actions: entries.reduce((sum, entry) => sum + entry.actions.filter((action) => ['open', 'in_progress'].includes(action.status)).length, 0),
      overdue_actions: entries.reduce((sum, entry) => sum + entry.actions.filter((action) => action.overdue).length, 0),
      errors: errors.length
    },
    sources: catalog?.sources || [],
    entries
  };
}

if (require.main === module) {
  try {
    const catalog = JSON.parse(fs.readFileSync(path.join(root, 'data/kritis-resilience-catalog.json'), 'utf8'));
    const register = JSON.parse(fs.readFileSync(path.join(root, 'data/kritis-resilience-register.json'), 'utf8'));
    const result = buildReport({ catalog, register });
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
    if (result.errors.length) process.exitCode = 1;
  } catch (error) {
    process.stderr.write(`KRITIS_RESILIENCE_REPORT_FAILED: ${error.message}\n`);
    process.exitCode = 1;
  }
}

module.exports = { buildReport, evidenceFile };
