#!/usr/bin/env node
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const self = JSON.parse(fs.readFileSync(path.join(root, 'data', 'self-description.json')));
const trust = JSON.parse(fs.readFileSync(path.join(root, 'data', 'trust-registry.json')));
const access = JSON.parse(fs.readFileSync(path.join(root, 'data', 'access-requests.json')));
const trustStates = new Set(self.trust.states);
assert.equal(self.schema, 'apophis/self-description/v1');
assert.ok(self.metadata_profile.required.includes('record_id'));
assert.ok(self.metadata_profile.optional_pids.includes('doi'));
assert.ok(self.trust.states.includes('project-authorised'));
assert.equal(self.access.export_default, false);
assert.equal(trust.policy, 'purpose-bound-explicit-membership');
assert.equal(access.schema, 'apophis/access-requests/v1');
assert.equal(self.governance.formal_certification, false);
for (const entry of trust.entries || []) {
  assert.ok(trustStates.has(entry.state), `unknown trust state: ${entry.state}`);
  assert.ok(typeof entry.peer_id === 'string' && entry.peer_id.length > 0);
  assert.ok(typeof entry.community_id === 'string' && entry.community_id.length > 0);
  assert.ok(Number.isFinite(Date.parse(entry.expires_at)), `invalid trust expiry: ${entry.peer_id}`);
  assert.ok(Array.isArray(entry.evidence_refs));
  if (entry.state === 'trusted-for-specific-purpose') assert.ok((entry.purposes || []).length > 0);
}
console.log(JSON.stringify({ verdict: 'PASS', self_description: true, pid_profile: true, purpose_bound_trust: true, trust_entries_validated: (trust.entries || []).length, access_requests: true, export_default: false }, null, 2));
