#!/usr/bin/env node
'use strict';

const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const root = path.join(__dirname, '..');
const verifier = path.join(__dirname, 'verify.js');
const bundle = path.join(root, 'data', 'evidence-bundle.json');
const approvals = path.join(root, 'data', 'approvals.json');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'apophis-verify-selftest-'));

function run(...args) {
  const result = spawnSync(process.execPath, [verifier, ...args], { cwd: root, encoding: 'utf8' });
  let output;
  try { output = JSON.parse(result.stdout); } catch (_) { throw new Error(`verifier_output_invalid:${result.stderr}`); }
  return { code: result.status, output };
}

try {
  const bundleOnly = run(bundle);
  assert.equal(bundleOnly.code, 0);
  assert.equal(bundleOnly.output.valid, true);
  assert.equal(bundleOnly.output.approvals_ok, true);

  const validLog = run(bundle, approvals);
  assert.equal(validLog.code, 0);
  assert.equal(validLog.output.valid, true);
  assert.equal(validLog.output.approvals_ok, true);

  const missingPath = path.join(temp, 'missing-approvals.json');
  const missing = run(bundle, missingPath);
  assert.equal(missing.code, 1);
  assert.equal(missing.output.valid, false);
  assert.equal(missing.output.approvals_ok, false);
  assert.equal(missing.output.approvals_error, 'approvals_file_missing_or_not_regular');

  const malformedPath = path.join(temp, 'malformed-approvals.json');
  fs.writeFileSync(malformedPath, '{');
  const malformed = run(bundle, malformedPath);
  assert.equal(malformed.code, 1);
  assert.equal(malformed.output.valid, false);
  assert.equal(malformed.output.approvals_ok, false);

  const invalidShapePath = path.join(temp, 'invalid-shape-approvals.json');
  fs.writeFileSync(invalidShapePath, JSON.stringify({ records: 'not-an-array' }));
  const invalidShape = run(bundle, invalidShapePath);
  assert.equal(invalidShape.code, 1);
  assert.equal(invalidShape.output.valid, false);
  assert.equal(invalidShape.output.approvals_ok, false);
} finally {
  fs.rmSync(temp, { recursive: true, force: true });
}

console.log(JSON.stringify({ verdict: 'PASS', cases: ['bundle_only_optional_approval_check', 'valid_approval_log', 'missing_explicit_approval_file', 'malformed_approval_json', 'invalid_approval_log_shape'] }, null, 2));
