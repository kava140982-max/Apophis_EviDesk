// KaVa-14.10.26 — review watermark
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { denyExternalNetwork } = require('./network-policy');
const root = path.join(__dirname, '..');
const config = JSON.parse(fs.readFileSync(process.env.APOPHIS_NEWS_CONFIG || path.join(root, 'data', 'news-sources.json'), 'utf8'));
const output = path.join(root, 'data', 'news-inbox.json');
const hash = (text) => crypto.createHash('sha256').update(String(text)).digest('hex');
const strip = (text) => String(text || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
const net = require('net');
const MAX_BYTES = 256 * 1024;
const MAX_SOURCES = 10;
const MAX_ITEMS_PER_SOURCE = 20;
const MAX_TIMEOUT_MS = 10000;
const FEED_TYPES = new Set(['application/rss+xml', 'application/atom+xml', 'application/xml', 'text/xml']);

function validateFeedUrl(raw, allowedHosts) {
  let url;
  try { url = new URL(raw); } catch { throw new Error('source_not_allowlisted'); }
  const host = url.hostname.toLowerCase();
  const localHost = host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local') || host.endsWith('.internal') || host.endsWith('.test') || host.endsWith('.invalid') || host.endsWith('.example');
  if (url.protocol !== 'https:' || url.username || url.password || url.port || url.hash || net.isIP(host) || !host.includes('.') || localHost || !allowedHosts.has(host)) {
    throw new Error('source_not_allowlisted');
  }
  return url;
}

function parseAllowedHosts(value) {
  if (!Array.isArray(value)) throw new Error('host_allowlist_required');
  const hosts = new Set();
  for (const raw of value) {
    if (typeof raw !== 'string' || raw !== raw.trim() || raw.includes('*')) throw new Error('host_allowlist_invalid');
    const host = raw.toLowerCase();
    if (!host.includes('.') || net.isIP(host) || /[^a-z0-9.-]/.test(host) || host.startsWith('.') || host.endsWith('.') || host.includes('..')) throw new Error('host_allowlist_invalid');
    hosts.add(host);
  }
  return hosts;
}

async function readLimitedBody(response, limit = MAX_BYTES) {
  const declared = Number(response.headers.get('content-length'));
  if (Number.isFinite(declared) && declared > limit) throw new Error('feed_too_large');
  if (!response.body) return '';
  const reader = response.body.getReader();
  const chunks = [];
  let size = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > limit) {
        await reader.cancel();
        throw new Error('feed_too_large');
      }
      chunks.push(Buffer.from(value));
    }
  } finally {
    reader.releaseLock();
  }
  return new TextDecoder('utf-8', { fatal: true }).decode(Buffer.concat(chunks, size));
}

function writeJsonAtomic(file, value) {
  const temp = `${file}.${process.pid}.tmp`;
  try {
    fs.writeFileSync(temp, JSON.stringify(value, null, 2) + '\n', { mode: 0o600 });
    fs.renameSync(temp, file);
  } finally {
    fs.rmSync(temp, { force: true });
  }
}

async function main() {
  if (!config.enabled) { const result = { schema: 'apophis/news-inbox/v1', refreshed_at: new Date().toISOString(), status: 'disabled', items: [] }; writeJsonAtomic(output, result); console.log(JSON.stringify(result)); return; }
  if (!Array.isArray(config.sources) || config.sources.length > MAX_SOURCES) throw new Error('source_count_invalid');
  denyExternalNetwork('news_feed_refresh');
}

if (require.main === module) main().catch((error) => { console.error(JSON.stringify({ status: 'failed-closed', error: error.message })); process.exitCode = 1; });
module.exports = { validateFeedUrl, parseAllowedHosts, readLimitedBody, MAX_BYTES };
