'use strict';

function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

function validatePolicy(policy) {
  const result = {
    window_size: Number(policy.window_size), min_history: Number(policy.min_history),
    mad_multiplier: Number(policy.mad_multiplier), absolute_tolerance: Number(policy.absolute_tolerance),
    relative_tolerance_percent: Number(policy.relative_tolerance_percent), min_consecutive: Number(policy.min_consecutive)
  };
  if (!Number.isInteger(result.window_size) || result.window_size < 12 || result.window_size > 10000) throw new Error('window_size_out_of_range');
  if (!Number.isInteger(result.min_history) || result.min_history < 6 || result.min_history >= result.window_size) throw new Error('min_history_out_of_range');
  if (!Number.isFinite(result.mad_multiplier) || result.mad_multiplier < 1 || result.mad_multiplier > 20) throw new Error('mad_multiplier_out_of_range');
  if (!Number.isFinite(result.absolute_tolerance) || result.absolute_tolerance < 0) throw new Error('absolute_tolerance_invalid');
  if (!Number.isFinite(result.relative_tolerance_percent) || result.relative_tolerance_percent < 0 || result.relative_tolerance_percent > 10000) throw new Error('relative_tolerance_invalid');
  if (!Number.isInteger(result.min_consecutive) || result.min_consecutive < 1 || result.min_consecutive > 100) throw new Error('min_consecutive_out_of_range');
  return result;
}

function analyze(series, inputPolicy) {
  const policy = validatePolicy(inputPolicy);
  const ordered = [...series.points].sort((a, b) => Date.parse(a.timestamp) - Date.parse(b.timestamp));
  const evaluated = [];
  let run = [];
  for (let index = 0; index < ordered.length; index += 1) {
    const point = ordered[index];
    const history = ordered.slice(Math.max(0, index - policy.window_size), index).map((item) => item.value);
    if (history.length < policy.min_history) continue;
    const center = median(history);
    const mad = median(history.map((value) => Math.abs(value - center)));
    const robustSpread = 1.4826 * mad * policy.mad_multiplier;
    const tolerance = Math.max(policy.absolute_tolerance, Math.abs(center) * policy.relative_tolerance_percent / 100, robustSpread);
    const deviation = point.value - center;
    const isOutlier = Math.abs(deviation) > tolerance;
    const sample = {
      timestamp: point.timestamp, value: point.value, baseline_median: center,
      tolerance, deviation, direction: deviation > 0 ? 'above' : 'below',
      deviation_ratio: tolerance > 0 ? Math.abs(deviation) / tolerance : null,
      flagged: isOutlier
    };
    evaluated.push(sample);
    if (isOutlier) run.push(sample);
    else {
      if (run.length >= policy.min_consecutive) evaluated.push({ alert: true, started_at: run[0].timestamp, ended_at: run.at(-1).timestamp, samples: run.length, direction: run.at(-1).direction, max_deviation_ratio: Math.max(...run.map((item) => item.deviation_ratio || 0)) });
      run = [];
    }
  }
  if (run.length >= policy.min_consecutive) evaluated.push({ alert: true, started_at: run[0].timestamp, ended_at: run.at(-1).timestamp, samples: run.length, direction: run.at(-1).direction, max_deviation_ratio: Math.max(...run.map((item) => item.deviation_ratio || 0)) });
  return { method: 'rolling_median_mad_v1', policy, points_evaluated: evaluated.filter((item) => !item.alert).length, alerts: evaluated.filter((item) => item.alert), samples: evaluated.filter((item) => !item.alert).slice(-500) };
}

module.exports = { analyze, validatePolicy };
