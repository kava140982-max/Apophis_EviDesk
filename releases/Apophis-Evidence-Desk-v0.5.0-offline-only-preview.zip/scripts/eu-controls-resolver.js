#!/usr/bin/env node
'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const REQUIRED_REGIMES = new Set(['GDPR', 'AI-Act', 'NIS2', 'CRA', 'eIDAS', 'EHDS']);
const ALLOWED_TEST_PREFIXES = ['npm run ', 'node scripts/'];
const VALID_STATUSES = new Set([
  'implemented',
  'prototype-control',
  'readiness-control',
  'conditional-trigger',
  'not-implemented',
  'out-of-scope-by-default',
  'blocked'
]);

function sha256File(file) {
  const hash = crypto.createHash('sha256');
  hash.update(fs.readFileSync(file));
  return hash.digest('hex');
}

function readProfile(root) {
  const profilePath = path.join(root, 'data', 'eu-controls.json');
  return { profilePath, profile: JSON.parse(fs.readFileSync(profilePath, 'utf8')) };
}

function safeEvidencePath(root, relativePath) {
  if (typeof relativePath !== 'string' || !relativePath.trim() || path.isAbsolute(relativePath)) {
    throw new Error('evidence_path_must_be_relative');
  }
  const normalized = path.normalize(relativePath);
  const candidate = path.resolve(root, normalized);
  const rootPrefix = root.endsWith(path.sep) ? root : `${root}${path.sep}`;
  if (candidate !== root && !candidate.startsWith(rootPrefix)) throw new Error('evidence_path_escapes_project');
  return { relativePath: normalized, absolutePath: candidate };
}

function validateProfile(profile) {
  const errors = [];
  if (!profile || profile.schema !== 'apophis/eu-controls/v1') errors.push('invalid_schema');
  if (!profile || profile.not_a_certification !== true) errors.push('not_a_certification_must_be_true');
  if (!profile || profile.assessment_scope !== 'local-loopback-synthetic-prototype') errors.push('unexpected_assessment_scope');
  if (!Array.isArray(profile?.controls) || profile.controls.length === 0) errors.push('controls_must_be_non_empty_array');

  const ids = new Set();
  const regimes = new Set();
  for (const control of profile?.controls || []) {
    if (!control || typeof control !== 'object') { errors.push('control_must_be_object'); continue; }
    if (typeof control.id !== 'string' || !control.id.trim()) errors.push('control_id_missing');
    else if (ids.has(control.id)) errors.push(`duplicate_control_id:${control.id}`);
    else ids.add(control.id);
    if (typeof control.regime !== 'string' || !control.regime.trim()) errors.push(`regime_missing:${control.id || 'unknown'}`);
    else regimes.add(control.regime);
    if (!VALID_STATUSES.has(control.status)) errors.push(`invalid_status:${control.id || 'unknown'}`);
    if (typeof control.implemented !== 'boolean') errors.push(`implemented_must_be_boolean:${control.id || 'unknown'}`);
    if (!Array.isArray(control.evidence) || control.evidence.length === 0) errors.push(`evidence_missing:${control.id || 'unknown'}`);
    if (typeof control.gap !== 'string' || !control.gap.trim()) errors.push(`gap_missing:${control.id || 'unknown'}`);
    if (control.test_command !== undefined && (typeof control.test_command !== 'string' || !control.test_command.trim())) errors.push(`invalid_test_command:${control.id || 'unknown'}`);
    if (control.test_command && !ALLOWED_TEST_PREFIXES.some((prefix) => control.test_command.startsWith(prefix))) errors.push(`test_command_not_allowed:${control.id || 'unknown'}`);
  }
  for (const regime of REQUIRED_REGIMES) if (!regimes.has(regime)) errors.push(`missing_required_regime:${regime}`);
  return errors;
}

function runAllowedTest(root, command) {
  if (!command) return { status: 'not-configured', command: null };
  const parts = command.trim().split(/\s+/);
  const executable = parts.shift();
  const args = parts;
  let result;
  if (executable === 'npm' && args[0] === 'run' && args[1]) result = spawnSync('npm', ['run', args[1], ...args.slice(2)], { cwd: root, encoding: 'utf8' });
  else if (executable === 'node' && args[0]?.startsWith('scripts/')) result = spawnSync(process.execPath, args, { cwd: root, encoding: 'utf8' });
  else return { status: 'rejected', command, error: 'test_command_not_allowlisted' };
  return { status: result.status === 0 ? 'pass' : 'fail', command, exit_code: result.status, stdout: String(result.stdout || '').slice(-4000), stderr: String(result.stderr || '').slice(-4000) };
}

function resolveControls({ root, runTests = false } = {}) {
  const projectRoot = path.resolve(root || path.join(__dirname, '..'));
  const { profilePath, profile } = readProfile(projectRoot);
  const profileErrors = validateProfile(profile);
  const controls = [];
  const evidence = [];
  let evidenceErrors = 0;
  let testErrors = 0;

  for (const control of profile.controls || []) {
    const controlEvidence = [];
    const controlErrors = [];
    for (const relativePath of control.evidence || []) {
      try {
        const resolved = safeEvidencePath(projectRoot, relativePath);
        const stat = fs.statSync(resolved.absolutePath);
        if (!stat.isFile()) throw new Error('evidence_path_not_regular_file');
        const item = { path: resolved.relativePath, sha256: sha256File(resolved.absolutePath), bytes: stat.size };
        controlEvidence.push(item);
        evidence.push({ control_id: control.id, ...item });
      } catch (error) {
        const item = { path: relativePath, error: error.code || error.message };
        controlEvidence.push(item);
        evidence.push({ control_id: control.id, ...item });
        controlErrors.push(`${relativePath}:${item.error}`);
        evidenceErrors += 1;
      }
    }
    const test = runTests ? runAllowedTest(projectRoot, control.test_command) : { status: control.test_command ? 'not-run' : 'not-configured', command: control.test_command || null };
    if (test.status === 'fail' || test.status === 'rejected') testErrors += 1;
    const verdict = controlErrors.length || test.status === 'fail' || test.status === 'rejected'
      ? 'FAIL'
      : control.implemented ? 'PASS'
        : control.status === 'out-of-scope-by-default' ? 'OUT_OF_SCOPE'
          : 'CONDITIONAL';
    controls.push({
      id: control.id,
      regime: control.regime,
      status: control.status,
      implemented: control.implemented,
      verdict,
      evidence: controlEvidence,
      test,
      gap: control.gap,
      errors: controlErrors
    });
  }

  const failedControls = controls.filter((control) => control.verdict === 'FAIL').length;
  const valid = profileErrors.length === 0 && evidenceErrors === 0 && testErrors === 0 && failedControls === 0;
  return {
    schema: 'apophis/eu-controls-result/v1',
    verdict: valid ? 'PASS' : 'FAILED',
    valid,
    assessment_scope: profile.assessment_scope,
    not_a_certification: profile.not_a_certification,
    profile: { path: path.relative(projectRoot, profilePath), errors: profileErrors },
    summary: {
      controls: controls.length,
      passed: controls.filter((control) => control.verdict === 'PASS').length,
      conditional: controls.filter((control) => control.verdict === 'CONDITIONAL').length,
      out_of_scope: controls.filter((control) => control.verdict === 'OUT_OF_SCOPE').length,
      failed: failedControls,
      evidence_files: evidence.length,
      evidence_errors: evidenceErrors,
      test_errors: testErrors
    },
    controls,
    evidence
  };
}

if (require.main === module) {
  const runTests = process.argv.includes('--run-tests');
  try {
    const result = resolveControls({ root: path.join(__dirname, '..'), runTests });
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
    process.exitCode = result.valid ? 0 : 1;
  } catch (error) {
    process.stderr.write(`EU_CONTROL_RESOLVER_FAILED: ${error.message}\n`);
    process.exitCode = 1;
  }
}

module.exports = { resolveControls, validateProfile, safeEvidencePath, sha256File };
