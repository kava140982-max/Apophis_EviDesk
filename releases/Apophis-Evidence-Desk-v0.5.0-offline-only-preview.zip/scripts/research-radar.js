'use strict';
// Optional Research Radar Phase A: bibliographic metadata only, isolated from Apophis Core.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { denyExternalNetwork } = require('./network-policy');

const ROOT = path.join(__dirname, '..');
const CONFIG_FILE = process.env.APOPHIS_RESEARCH_CONFIG || path.join(ROOT, 'data', 'research-radar', 'config.json');
const INBOX_FILE = process.env.APOPHIS_RESEARCH_INBOX || path.join(ROOT, 'data', 'research-radar', 'inbox.json');
const API = 'https://www.ebi.ac.uk/europepmc/webservices/rest/search';
const MAX_QUERIES = 5;
const MAX_RESULTS = 20;
const MAX_RECORDS = 10000;
const MAX_EVENTS = 50000;
const MAX_RESPONSE_BYTES = 1024 * 1024;
const TIMEOUT_MS = 10000;
const USER_AGENT = 'Apophis-Research-Radar/0.4.2 (manual metadata refresh)';

function hash(value) {
  return crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
}

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch (error) {
    if (error.code === 'ENOENT') return fallback;
    throw new Error('stored_json_invalid');
  }
}

function writeJsonAtomic(file, value) {
  const temp = `${file}.${process.pid}.tmp`;
  try {
    fs.writeFileSync(temp, `${JSON.stringify(value, null, 2)}\n`, { mode: 0o600, flag: 'wx' });
    fs.renameSync(temp, file);
  } finally {
    try { fs.unlinkSync(temp); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  }
}

function validateConfig(config) {
  if (!config || config.schema !== 'apophis/research-radar-config/v1' || typeof config.enabled !== 'boolean' || !Array.isArray(config.queries) || config.queries.length > MAX_QUERIES) throw new Error('config_invalid');
  for (const item of config.queries) {
    if (!item || typeof item.id !== 'string' || !/^[a-z0-9][a-z0-9-]{0,63}$/.test(item.id) || typeof item.label !== 'string' || item.label.length > 120 || typeof item.query !== 'string' || item.query.trim().length < 3 || item.query.length > 512 || typeof item.enabled !== 'boolean') throw new Error('query_invalid');
  }
}

async function readLimitedJson(response) {
  const declared = Number(response.headers.get('content-length'));
  if (Number.isFinite(declared) && declared > MAX_RESPONSE_BYTES) throw new Error('response_too_large');
  if (!response.body) throw new Error('response_empty');
  const reader = response.body.getReader();
  const chunks = [];
  let size = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > MAX_RESPONSE_BYTES) { await reader.cancel(); throw new Error('response_too_large'); }
      chunks.push(Buffer.from(value));
    }
  } finally { reader.releaseLock(); }
  try { return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(Buffer.concat(chunks, size))); }
  catch { throw new Error('response_json_invalid'); }
}

function normalizeRecord(item, query, retrievedAt) {
  const pmid = typeof item.pmid === 'string' && /^\d+$/.test(item.pmid) ? item.pmid : null;
  const pmcid = typeof item.pmcid === 'string' && /^PMC\d+$/.test(item.pmcid) ? item.pmcid : null;
  const doi = typeof item.doi === 'string' && /^10\.\d{4,9}\/[^\s?#]+$/i.test(item.doi) && item.doi.length <= 200 ? item.doi : null;
  const stableId = pmid ? `pmid:${pmid}` : (pmcid ? `pmcid:${pmcid}` : (doi ? `doi:${doi.toLowerCase()}` : null));
  if (!stableId) return null;
  const metadata = {
    source_system: 'Europe PMC', stable_id: stableId, pmid, pmcid, doi,
    title: String(item.title || '').slice(0, 1200),
    authors: String(item.authorString || '').slice(0, 1200),
    journal: String(item.journalTitle || '').slice(0, 500),
    publication_date: String(item.firstPublicationDate || item.dateOfPublication || item.pubYear || '').slice(0, 40),
    publication_types: Array.isArray(item.pubTypeList?.pubType) ? item.pubTypeList.pubType.map(v => String(v).slice(0, 120)).slice(0, 30) : [],
    is_open_access: item.isOpenAccess === 'Y',
    is_retracted: item.is_retracted === 'Y' || item.isRetracted === 'Y',
    correction_signals: Array.isArray(item.commentCorrectionList?.commentCorrection) ? item.commentCorrectionList.commentCorrection.slice(0, 20).map(v => ({ type: String(v.type || '').slice(0, 120), ref_id: String(v.refId || '').slice(0, 120) })) : [],
    source_url: pmid ? `https://europepmc.org/article/MED/${pmid}` : (pmcid ? `https://europepmc.org/article/PMC/${pmcid}` : `https://doi.org/${encodeURI(doi)}`),
    retrieved_at: retrievedAt,
    query_id: query.id,
    snapshot_sha256: null,
    review_status: 'pending-human-review'
  };
  const snapshot = { ...metadata };
  delete snapshot.retrieved_at;
  delete snapshot.snapshot_sha256;
  metadata.snapshot_sha256 = hash(snapshot);
  return metadata;
}

async function main() {
  const config = readJson(CONFIG_FILE, null);
  validateConfig(config);
  if (!config.enabled) {
    console.log(JSON.stringify({ status: 'disabled', detail: 'Enable the module and at least one query in data/research-radar/config.json.' }));
    return;
  }
  const queries = config.queries.filter(q => q.enabled);
  if (!queries.length) throw new Error('no_enabled_queries');
  denyExternalNetwork('research_radar_refresh');

}

if (require.main === module) main().catch(error => {
  console.error(JSON.stringify({ status: 'failed-closed', error: error.message }));
  process.exitCode = 1;
});

module.exports = { validateConfig, normalizeRecord, readLimitedJson, MAX_RESPONSE_BYTES, MAX_RESULTS };
