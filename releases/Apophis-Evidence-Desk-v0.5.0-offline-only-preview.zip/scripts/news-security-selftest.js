// KaVa-14.10.26 — review watermark
const assert = require('assert/strict');
const { validateFeedUrl, parseAllowedHosts, readLimitedBody } = require('./news-watch');

async function main() {
  const hosts = parseAllowedHosts(['feeds.example.com']);
  assert.equal(validateFeedUrl('https://feeds.example.com/rss.xml', hosts).hostname, 'feeds.example.com');
  for (const url of [
    'http://feeds.example.com/rss.xml',
    'https://not-allowlisted.example.com/rss.xml',
    'https://127.0.0.1/rss.xml',
    'https://localhost/rss.xml',
    'https://user:pass@feeds.example.com/rss.xml',
    'https://feeds.example.com:8443/rss.xml',
    'https://feeds.example.com/rss.xml#fragment'
  ]) assert.throws(() => validateFeedUrl(url, hosts), /source_not_allowlisted/);
  assert.throws(() => parseAllowedHosts(['*.example.com']), /host_allowlist_invalid/);
  assert.throws(() => parseAllowedHosts(['127.0.0.1']), /host_allowlist_invalid/);
  assert.equal(await readLimitedBody(new Response('abc'), 3), 'abc');
  await assert.rejects(readLimitedBody(new Response('abcd'), 3), /feed_too_large/);
  await assert.rejects(readLimitedBody(new Response('x', { headers: { 'content-length': '999' } }), 3), /feed_too_large/);
  console.log(JSON.stringify({ verdict: 'PASS', exact_host_allowlist: true, forbidden_url_classes_rejected: true, oversized_body_rejected: true }));
}

main().catch((error) => { console.error(error); process.exitCode = 1; });
