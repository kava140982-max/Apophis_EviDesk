#!/usr/bin/env node
// KaVa-14.10.26 — review watermark
'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const net = require('node:net');
const { spawn } = require('node:child_process');

const sourceRoot = path.join(__dirname, '..');
const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'apophis-governance-test-'));

function freePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const port = server.address().port;
      server.close((error) => error ? reject(error) : resolve(port));
    });
  });
}

async function assertRemoteBindRefused(projectRoot) {
  const port = await freePort();
  const child = spawn(process.execPath, ['server.js'], {
    cwd: projectRoot,
    env: { ...process.env, PORT: String(port), HOST: '0.0.0.0' },
    stdio: 'ignore'
  });
  const exitCode = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => { child.kill('SIGKILL'); resolve(null); }, 2000);
    child.once('error', (error) => { clearTimeout(timer); reject(error); });
    child.once('exit', (code) => { clearTimeout(timer); resolve(code); });
  });
  assert.equal(exitCode, 1, 'unauthenticated non-loopback bind must be refused');
}

async function request(base, route, method = 'GET', payload = null) {
  const response = await fetch(`${base}${route}`, {
    method,
    headers: payload ? { 'Content-Type': 'application/json' } : {},
    body: payload ? JSON.stringify(payload) : undefined,
    signal: AbortSignal.timeout(3000)
  });
  const body = await response.json();
  return { status: response.status, body };
}

async function waitForHealth(base, child) {
  for (let attempt = 0; attempt < 60; attempt += 1) {
    if (child.exitCode !== null) throw new Error('test_server_exited_early');
    try {
      const result = await request(base, '/health');
      if (result.status === 200) return;
    } catch (_) {}
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error('test_server_start_timeout');
}

async function main() {
  const projectRoot = path.join(tempRoot, 'project');
  fs.cpSync(sourceRoot, projectRoot, {
    recursive: true,
    filter: (source) => {
      const normalized = source.replaceAll(path.sep, '/');
      return !normalized.includes('/node_modules/') && !normalized.includes('/data/keys/') && !normalized.includes('/.audit-pack/');
    }
  });
  assert.equal(fs.existsSync(path.join(projectRoot, 'data', 'keys', 'ed25519-private.pem')), false, 'self-test copy must not contain a private key');
  await assertRemoteBindRefused(projectRoot);

  const port = await freePort();
  const base = `http://127.0.0.1:${port}`;
  const child = spawn(process.execPath, ['server.js'], {
    cwd: projectRoot,
    env: { ...process.env, PORT: String(port), HOST: '127.0.0.1' },
    stdio: 'ignore'
  });

  try {
    await waitForHealth(base, child);
    const approvals = [
      { actor: 'synthetic-author', role: 'author', decision: 'approve' },
      { actor: 'synthetic-reviewer', role: 'reviewer', decision: 'approve' },
      { actor: 'synthetic-biosecurity', role: 'biosecurity', decision: 'approve' }
    ];
    for (const approval of approvals) {
      const result = await request(base, '/api/approvals', 'POST', { ...approval, rationale: 'synthetic regression fixture' });
      assert.equal(result.status, 201, `expected approval record for ${approval.role}`);
    }
    let gate = await request(base, '/api/approvals/status');
    assert.equal(gate.status, 200);
    assert.equal(gate.body.ready, true, 'complete approvals should open the local demo gate');

    for (const decision of ['reject', 'escalate']) {
      const result = await request(base, '/api/approvals', 'POST', {
        actor: `synthetic-${decision}`,
        role: 'reviewer',
        decision,
        rationale: 'synthetic veto regression fixture'
      });
      assert.equal(result.status, 201, `expected ${decision} record to be retained`);
      gate = await request(base, '/api/approvals/status');
      assert.equal(gate.body.ready, false, `${decision} must fail closed`);
      assert.ok(gate.body.blocking_decisions.includes(decision), `${decision} must be visible as a blocker`);
    }

    const approvalsFile = path.join(projectRoot, 'data', 'approvals.json');
    const corruptContent = '{ intentionally malformed approval log';
    fs.writeFileSync(approvalsFile, corruptContent, { mode: 0o600 });
    const appendResult = await request(base, '/api/approvals', 'POST', {
      actor: 'synthetic-after-corruption',
      role: 'reviewer',
      decision: 'approve',
      rationale: 'must not overwrite corrupted history'
    });
    assert.notEqual(appendResult.status, 201, 'append must reject a malformed persisted log');
    assert.equal(fs.readFileSync(approvalsFile, 'utf8'), corruptContent, 'malformed history must remain untouched');
    const statusResult = await request(base, '/api/approvals/status');
    assert.equal(statusResult.status, 500, 'malformed approval history must surface as an error, not an empty valid chain');

    console.log(JSON.stringify({
      verdict: 'PASS',
      complete_approval_gate: 'ready',
      reject_veto: 'blocked',
      escalate_veto: 'blocked',
      malformed_log: 'rejected_without_overwrite',
      unauthenticated_remote_bind: 'refused',
      copied_private_key: false
    }, null, 2));
  } finally {
    child.kill('SIGTERM');
    await new Promise((resolve) => {
      if (child.exitCode !== null) return resolve();
      const timer = setTimeout(() => { child.kill('SIGKILL'); resolve(); }, 2000);
      child.once('exit', () => { clearTimeout(timer); resolve(); });
    });
    fs.rmSync(tempRoot, { recursive: true, force: true });
  }
}

main().catch((error) => {
  console.error(JSON.stringify({ verdict: 'FAIL', error: error.message }));
  process.exitCode = 1;
});
