// KaVa-14.10.26 — review watermark
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const root = path.join(__dirname, '..');
const file = path.join(root, 'SANDBOX-SBOM.json');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const sbom = JSON.parse(fs.readFileSync(file, 'utf8'));
const ref = `pkg:npm/${pkg.name}@${pkg.version}`;
if (sbom.bomFormat !== 'CycloneDX' || sbom.specVersion !== '1.5' || sbom.metadata?.component?.purl !== ref) throw new Error('sbom_identity_mismatch');
if (!Array.isArray(sbom.components) || sbom.components.length !== 0) throw new Error('sbom_component_mismatch');
const declared = ['dependencies', 'devDependencies', 'optionalDependencies', 'peerDependencies'].some((key) => Object.keys(pkg[key] || {}).length > 0);
if (declared) throw new Error('package_dependencies_present');
const tree = JSON.parse(execFileSync('npm', ['ls', '--depth=0', '--json'], { cwd: root, encoding: 'utf8' }));
if (Object.keys(tree.dependencies || {}).length > 0) throw new Error('npm_dependency_tree_not_empty');
const digest = crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
console.log(JSON.stringify({ valid: true, external_components: 0, sbom_sha256: digest }));
