// KaVa-14.10.26 — review watermark
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const outputPath = path.join(root, 'data', 'evidence-bundle.json');
const keyDir = path.join(root, 'data', 'keys');
const privatePath = path.join(keyDir, 'ed25519-private.pem');
const identityPath = path.join(root, 'data', 'identity-rotations.json');
const canonicalDeep = (value) => {
  if (Array.isArray(value)) return `[${value.map(canonicalDeep).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalDeep(value[key])}`).join(',')}}`;
  return JSON.stringify(value);
};
const hash = (value) => crypto.createHash('sha256').update(canonicalDeep(value)).digest('hex');
const normalizeText = (value) => String(value || '').normalize('NFKC').replace(/\\s+/g, ' ').trim();
const referenceHash = (ref) => hash({ text: normalizeText([ref.title, ref.supports, ref.boundary].join('\\n')), retrieved: ref.retrieved });
fs.mkdirSync(keyDir, { recursive: true });
let privateKey;
if (fs.existsSync(privatePath)) privateKey = crypto.createPrivateKey(fs.readFileSync(privatePath));
else { privateKey = crypto.generateKeyPairSync('ed25519').privateKey; fs.writeFileSync(privatePath, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 }); }
const publicKey = crypto.createPublicKey(privateKey);
const publicKeyDer = publicKey.export({ type: 'spki', format: 'der' }).toString('base64');
const fingerprint = crypto.createHash('sha256').update(publicKeyDer, 'base64').digest('hex');
let rotations = fs.existsSync(identityPath) ? JSON.parse(fs.readFileSync(identityPath, 'utf8')) : { schema: 'apophis/identity-rotations/v1', rotations: [] };
if (!rotations.rotations.some((r) => r.fingerprint === fingerprint)) rotations.rotations.push({ fingerprint, algorithm: 'Ed25519', created_at: new Date().toISOString(), status: 'active', note: 'Initial local signing identity; protect the private key.' });
rotations.active_fingerprint = fingerprint;
fs.writeFileSync(identityPath, JSON.stringify(rotations, null, 2) + '\n');
const refs = JSON.parse(fs.readFileSync(path.join(root, 'data', 'public-references.json'), 'utf8'));
const previousBundle = fs.existsSync(outputPath) ? JSON.parse(fs.readFileSync(outputPath, 'utf8')) : null;
const sources = refs.map((ref, index) => ({ id: `source-${String(index + 1).padStart(3, '0')}`, reference_id: ref.id, title: ref.title, url: ref.url, retrieved: ref.retrieved, content_hash: referenceHash(ref), hash_basis: 'normalized title + supports + boundary + retrieved date', link_status: 'not_checked' }));
const unsigned = {
  schema: 'apophis/evidence-bundle/v5', bundle_id: 'bundle-hcmv-demo-001', run_id: 'run-7f31a9c2', created_at: previousBundle?.created_at || new Date().toISOString(), profile: 'research', profile_version: '0.3.0',
  identity: { algorithm: 'Ed25519', active_fingerprint: fingerprint, rotation_log: 'data/identity-rotations.json' },
  run_manifest: { core: '0.3.0', network_enabled: false, code_execution: false, model: null }, sources,
  passages: refs.map((ref, index) => ({ id: `passage-${String(index + 1).padStart(3, '0')}`, source_id: sources[index].id, locator: 'reference-card', text_hash: referenceHash(ref), extraction: 'normalized-public-reference-card', verified: false })),
  claims: [
    { id: 'claim-001', question: 'Welche Dimensionen müssen getrennt betrachtet werden?', statement: 'Ein HCMV-Plan muss Immunogenität, Sicherheit, Herstellbarkeit und regulatorische Unsicherheit getrennt betrachten.', counterclaim: 'Die Quellenkarten sind Kontext und keine Evidenz dafür, dass ein konkreter Kandidat diese Dimensionen erfüllt.', status: 'kontext-gestützt', uncertainty: ['keine Literatur-Synthese', 'keine Laborvalidierung'], evidence: [{ passage_id: 'passage-001', relation: 'contextualizes' }, { passage_id: 'passage-002', relation: 'supports' }], human_review: 'required' },
    { id: 'claim-002', question: 'Was belegen öffentliche Gesundheitsquellen?', statement: 'Öffentliche Gesundheitsquellen beschreiben CMV-Kontext und betroffene Gruppen.', counterclaim: 'Sie bewerten keinen konkreten Impfstoffkandidaten.', status: 'kontext-gestützt', uncertainty: ['keine Kandidaten-Daten'], evidence: [{ passage_id: 'passage-001', relation: 'supports' }], human_review: 'required' },
    { id: 'claim-003', question: 'Welche Rolle haben Leitlinien?', statement: 'Leitlinien strukturieren mögliche Qualitäts-, nichtklinische und klinische Fragestellungen.', counterclaim: 'Eine Leitlinie ist keine Zulassungsentscheidung.', status: 'kontext-gestützt', uncertainty: ['Jurisdiktion und Anwendbarkeit offen'], evidence: [{ passage_id: 'passage-002', relation: 'supports' }, { passage_id: 'passage-003', relation: 'supports' }], human_review: 'required' },
    { id: 'claim-004', question: 'Ist Wirksamkeit ableitbar?', statement: 'Aus diesem Bundle ist keine Wirksamkeits- oder Sicherheits­aussage ableitbar.', counterclaim: 'Selbst mehrere Kontextquellen ersetzen keine präklinischen oder klinischen Daten.', status: 'geprüft', uncertainty: ['Scope-Grenze, keine Wirksamkeitsprüfung'], evidence: [], human_review: 'required' },
    { id: 'claim-005', question: 'Ist Herstellbarkeit nachgewiesen?', statement: 'Herstellbarkeit ist im Bundle nicht nachgewiesen.', counterclaim: 'Regulatorische Themenkarten nennen Qualität, liefern aber keinen Herstellungsnachweis.', status: 'blockiert', uncertainty: ['keine CMC-Daten', 'keine Labor- oder Prozessdaten'], evidence: [{ passage_id: 'passage-002', relation: 'boundary-only' }], human_review: 'required' },
    { id: 'claim-006', question: 'Welche nächste Entscheidung ist zulässig?', statement: 'Zulässig ist nur weitere fachliche Prüfung und Übergabe an zuständige Rollen.', counterclaim: 'Ein Approval-Record ist keine wissenschaftliche, regulatorische oder DURC-Freigabe.', status: 'hypothese', uncertainty: ['Rollen und Organisationskontext müssen extern bestätigt werden'], evidence: [], human_review: 'required' }
  ],
  coverage_matrix: [
    { platform: 'Plattformvergleich', question: 'Evidenzlage', status: 'kontext-gestützt', claim_ids: ['claim-001', 'claim-003'] },
    { platform: 'Plattformvergleich', question: 'Gegenargumente', status: 'review', claim_ids: ['claim-001', 'claim-002', 'claim-003'] },
    { platform: 'Immunologisches Rationale', question: 'Sicherheit/Wirksamkeit', status: 'blockiert', claim_ids: ['claim-004'] },
    { platform: 'Herstellung/Qualität', question: 'Machbarkeit', status: 'blockiert', claim_ids: ['claim-005'] },
    { platform: 'Regulatory', question: 'Anwendbarkeit', status: 'review', claim_ids: ['claim-003', 'claim-006'] }
  ],
  findings: [{ id: 'boundary-001', category: 'scope', severity: 'high', statement: 'Keine Sicherheits-, Wirksamkeits-, Herstellbarkeits-, Zulassungs- oder DURC-Aussage.', limitation: 'Übergabe an Labor, Ethik, Regulatory und Biosecurity erforderlich.' }],
  gates: [
    { id: 'research.question.complete', status: 'pass', reason: 'Begrenzte Forschungsfrage vorhanden', human_required: true },
    { id: 'research.counterclaims', status: 'review', reason: 'Gegenclaims vorhanden, fachliche Prüfung offen', human_required: true },
    { id: 'biosecurity.detail-class', status: 'pass', reason: 'Scanner blockiert Sequenzen, Protokolle und Dosierungen', human_required: true },
    { id: 'approval.two-person', status: 'blocked', reason: 'Zwei unterschiedliche Actors und Rollen erforderlich', human_required: true },
    { id: 'regulatory.human_review', status: 'review', reason: 'Regulatory-/Rechtsprüfung erforderlich', human_required: true }
  ],
  limitations: ['KI-Ausgaben sind Hypothesen, keine Laborvalidierung', 'Keine Laborprotokolle, Sequenzen oder Dosierungen', 'Öffentliche Referenzkarten sind keine Primärdaten-Snapshots', 'Kein Sicherheits-/Wirksamkeits-/Herstellbarkeits-/Zulassungs- oder DURC-Nachweis']
};
const signature = crypto.sign(null, Buffer.from(canonicalDeep(unsigned)), privateKey).toString('base64');
const bundle = { ...unsigned, receipt: { algorithm: 'SHA-256', bundle_hash: hash(unsigned) }, signature: { algorithm: 'Ed25519', public_key_spki_der_base64: publicKeyDer, value_base64: signature } };
fs.writeFileSync(outputPath, JSON.stringify(bundle, null, 2) + '\n');
console.log(`Wrote ${outputPath}\nIdentity ${fingerprint}`);
