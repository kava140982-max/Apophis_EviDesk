#!/usr/bin/env node
'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { buildReport } = require('./kritis-resilience-report');

const root = path.resolve(__dirname, '..');
const catalog = JSON.parse(fs.readFileSync(path.join(root, 'data/kritis-resilience-catalog.json'), 'utf8'));
const template = JSON.parse(fs.readFileSync(path.join(root, 'data/kritis-resilience-register.json'), 'utf8'));
const now = new Date('2026-10-20T12:00:00.000Z');
const reportFor = (mutate) => {
  const register = structuredClone(template);
  if (mutate) mutate(register.records[0]);
  return buildReport({ catalog, register, now });
};

const baseline = reportFor();
assert.equal(baseline.errors.length, 0, 'synthetic register starts valid');
assert.equal(baseline.summary.corrective_actions, 0);
assert.equal(baseline.summary.open_actions, 0);
assert.equal(baseline.summary.overdue_actions, 0);

const active = reportFor((record) => {
  record.pdca_stage = 'check';
  record.actions.push({ id: 'act-1', status: 'in_progress', owner: 'security-owner', due_date: '2026-10-19' });
});
assert.equal(active.errors.some((error) => error.endsWith(':action:act-1:action_overdue')), true);
assert.equal(active.entries[0].pdca_stage, 'check');
assert.equal(active.summary.corrective_actions, 1);
assert.equal(active.summary.open_actions, 1);
assert.equal(active.summary.overdue_actions, 1);

const completed = reportFor((record) => {
  record.actions.push({ id: 'act-2', status: 'complete', owner: 'continuity-owner', due_date: '2026-10-01' });
});
assert.equal(completed.summary.overdue_actions, 0, 'completed action is not overdue');
assert.equal(completed.summary.open_actions, 0);

const invalid = reportFor((record) => {
  record.pdca_stage = 'skip';
  record.actions.push(
    { id: 'duplicate', status: 'unknown', owner: '', due_date: 'not-a-date' },
    { id: 'duplicate', status: 'open', owner: 'owner', due_date: null }
  );
});
assert.equal(invalid.errors.some((error) => error.endsWith(':invalid_pdca_stage')), true);
assert.equal(invalid.errors.some((error) => error.includes('invalid_action_status')), true);
assert.equal(invalid.errors.some((error) => error.includes('invalid_action_owner')), true);
assert.equal(invalid.errors.some((error) => error.includes('invalid_action_due_date')), true);
assert.equal(invalid.errors.some((error) => error.includes('invalid_or_duplicate_action_id')), true);

process.stdout.write(`${JSON.stringify({ verdict: 'PASS', baseline_register: true, pdca_stage: true, overdue_open_actions: true, completed_actions_exempt_from_overdue: true, invalid_actions_rejected: true }, null, 2)}\n`);
