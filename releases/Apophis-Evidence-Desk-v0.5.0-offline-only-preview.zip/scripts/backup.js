#!/usr/bin/env node
'use strict';

// Encrypted application-data backup prototype. This is not a host disk image,
// remote transfer client, identity provider, or two-person authorization system.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const zlib = require('node:zlib');
const { execFileSync } = require('node:child_process');
const { promisify } = require('node:util');
const gzip = promisify(zlib.gzip);
const gunzip = promisify(zlib.gunzip);

const ROOT = path.resolve(__dirname, '..');
const DATA = path.join(ROOT, 'data');
const MAGIC = Buffer.from('APOPHIS-BACKUP-V1\n', 'ascii');
const MAX_PLAIN_BYTES = 512 * 1024 * 1024;

function destinationFromEnv() {
  const dest = process.env.APOPHIS_BACKUP_DIR;
  if (!dest) throw new Error('backup_destination_required');
  const destination = path.resolve(dest);
  if (destination === ROOT || destination.startsWith(`${ROOT}${path.sep}`)) throw new Error('backup_destination_must_be_outside_project');
  return destination;
}

function requireTwoPersonAuthorization(operation, resource, resourceHash, requireKey = false) {
  const adapter = process.env.APOPHIS_BACKUP_AUTHORIZER;
  if (!adapter || !path.isAbsolute(adapter)) throw new Error('two_person_authorization_adapter_required');
  const stat = fs.statSync(adapter);
  if (!stat.isFile()) throw new Error('backup_authorizer_invalid');
  let result;
  try {
    result = execFileSync(adapter, [operation, path.resolve(resource), resourceHash], {
      encoding: 'utf8', timeout: 15000, stdio: ['ignore', 'pipe', 'ignore'],
      env: { PATH: process.env.PATH || '', LANG: process.env.LANG || 'C', APOPHIS_AUTHZ_PROTOCOL: 'apophis/dual-control-authorization/v1' }
    });
  } catch (_) { throw new Error('two_person_authorization_denied'); }
  let approval;
  try { approval = JSON.parse(result); } catch (_) { throw new Error('backup_authorizer_response_invalid'); }
  const actors = Array.isArray(approval?.distinct_actors) ? approval.distinct_actors.filter((actor) => typeof actor === 'string' && actor.trim()) : [];
  const expires = Date.parse(approval?.expires_at || '');
  if (approval.schema !== 'apophis/dual-control-authorization/v1' || approval.decision !== 'allow' || approval.operation !== operation || approval.resource_sha256 !== resourceHash || !approval.authorization_id || new Set(actors).size < 2 || !Number.isFinite(expires) || expires <= Date.now() || (requireKey && !/^[a-fA-F0-9]{64}$/.test(approval.key_hex || ''))) {
    throw new Error('two_person_authorization_invalid');
  }
  return { authorization_id: approval.authorization_id, actor_count: new Set(actors).size, key: requireKey ? Buffer.from(approval.key_hex, 'hex') : null };
}

function walkFiles(dir, rel = '') {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
    const childRel = path.posix.join(rel, entry.name);
    if (childRel === 'keys' || childRel.startsWith('keys/')) continue;
    if (entry.isSymbolicLink()) throw new Error(`backup_symlink_rejected:${childRel}`);
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walkFiles(full, childRel));
    else if (entry.isFile()) {
      const stat = fs.statSync(full);
      if (stat.size > MAX_PLAIN_BYTES) throw new Error(`backup_file_too_large:${childRel}`);
      out.push({ path: childRel, bytes: fs.readFileSync(full) });
    }
  }
  return out;
}

function safeTarget(base, rel) {
  if (typeof rel !== 'string' || rel.startsWith('/') || rel.split('/').some((part) => !part || part === '.' || part === '..')) throw new Error('backup_path_invalid');
  const target = path.resolve(base, ...rel.split('/'));
  if (!target.startsWith(`${base}${path.sep}`)) throw new Error('backup_path_invalid');
  return target;
}

async function create() {
  const destination = destinationFromEnv();
  const files = walkFiles(DATA).map(({ path: rel, bytes }) => ({ path: rel, data: bytes.toString('base64'), sha256: crypto.createHash('sha256').update(bytes).digest('hex') }));
  const sourceDigest = crypto.createHash('sha256').update(files.map((item) => `${item.path}:${item.sha256}`).join('\n')).digest('hex');
  const authorization = requireTwoPersonAuthorization('create', DATA, sourceDigest, true);
  const key = authorization.key;
  fs.mkdirSync(destination, { recursive: true, mode: 0o700 });
  const plain = Buffer.from(JSON.stringify({ schema: 'apophis/encrypted-data-backup/v1', created_at: new Date().toISOString(), source_version: require(path.join(ROOT, 'package.json')).version, files }));
  if (plain.length > MAX_PLAIN_BYTES) throw new Error('backup_payload_too_large');
  const compressed = await gzip(plain, { level: 9 });
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  cipher.setAAD(MAGIC);
  const encrypted = Buffer.concat([cipher.update(compressed), cipher.final()]);
  const envelope = Buffer.concat([MAGIC, iv, cipher.getAuthTag(), encrypted]);
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const target = path.join(destination, `apophis-data-${stamp}.backup.enc`);
  const temp = `${target}.tmp-${process.pid}`;
  fs.writeFileSync(temp, envelope, { flag: 'wx', mode: 0o600 });
  fs.renameSync(temp, target);
  console.log(JSON.stringify({ created: true, authorization_id: authorization.authorization_id, backup: target, encrypted_bytes: envelope.length, file_count: files.length, private_keys_included: false, image_type: 'application-data-only' }));
}

async function inspect(file, restoreTo = null) {
  const backupPath = path.resolve(file);
  const envelope = fs.readFileSync(backupPath);
  const backupHash = crypto.createHash('sha256').update(envelope).digest('hex');
  const operation = restoreTo ? 'restore' : 'verify';
  const authorization = requireTwoPersonAuthorization(operation, backupPath, backupHash, true);
  const key = authorization.key;
  if (envelope.length < MAGIC.length + 28 || !envelope.subarray(0, MAGIC.length).equals(MAGIC)) throw new Error('backup_envelope_invalid');
  const ivStart = MAGIC.length;
  const iv = envelope.subarray(ivStart, ivStart + 12);
  const tag = envelope.subarray(ivStart + 12, ivStart + 28);
  const ciphertext = envelope.subarray(ivStart + 28);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAAD(MAGIC);
  decipher.setAuthTag(tag);
  const compressed = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
  const payload = JSON.parse((await gunzip(compressed, { maxOutputLength: MAX_PLAIN_BYTES })).toString('utf8'));
  if (payload.schema !== 'apophis/encrypted-data-backup/v1' || !Array.isArray(payload.files)) throw new Error('backup_payload_invalid');
  for (const entry of payload.files) {
    const bytes = Buffer.from(entry.data, 'base64');
    if (crypto.createHash('sha256').update(bytes).digest('hex') !== entry.sha256) throw new Error('backup_file_hash_invalid');
    if (restoreTo) {
      const target = safeTarget(restoreTo, entry.path);
      fs.mkdirSync(path.dirname(target), { recursive: true, mode: 0o700 });
      fs.writeFileSync(target, bytes, { flag: 'wx', mode: 0o600 });
    }
  }
  console.log(JSON.stringify({ valid: true, authorization_id: authorization.authorization_id, created_at: payload.created_at, source_version: payload.source_version, file_count: payload.files.length, restored_to: restoreTo || null }));
}

function prune() {
  const destination = destinationFromEnv();
  const keep = Number(process.env.APOPHIS_BACKUP_KEEP || 14);
  if (!Number.isInteger(keep) || keep < 1 || keep > 3650) throw new Error('backup_keep_must_be_1_to_3650');
  const files = fs.readdirSync(destination).filter((name) => /^apophis-data-[0-9TZ-]+\.backup\.enc$/.test(name)).map((name) => ({ name, full: path.join(destination, name), mtime: fs.statSync(path.join(destination, name)).mtimeMs })).sort((a, b) => b.mtime - a.mtime);
  const deleted = files.slice(keep);
  const deletionDigest = crypto.createHash('sha256').update(deleted.map((item) => `${item.name}:${crypto.createHash('sha256').update(fs.readFileSync(item.full)).digest('hex')}`).join('\n')).digest('hex');
  let authorization = null;
  if (deleted.length) authorization = requireTwoPersonAuthorization('prune', destination, deletionDigest);
  for (const file of deleted) fs.unlinkSync(file.full);
  console.log(JSON.stringify({ retained: Math.min(files.length, keep), deleted: deleted.map((item) => item.name), retention_count: keep, authorization_id: authorization?.authorization_id || null }));
}

(async () => {
  const [command, ...args] = process.argv.slice(2);
  if (command === 'create') await create();
  else if (command === 'verify') await inspect(args[0]);
  else if (command === 'restore') {
    if (!args[0] || !args[1]) throw new Error('usage: node scripts/backup.js restore <backup-file> <empty-target-directory>');
    const target = path.resolve(args[1]);
    if (fs.existsSync(target) && fs.readdirSync(target).length) throw new Error('restore_target_must_be_empty');
    await inspect(args[0], target);
  } else if (command === 'prune') prune();
  else throw new Error('usage: node scripts/backup.js <create|verify <file>|restore <file> <empty-dir>|prune>');
})().catch((error) => { console.error(error.message); process.exitCode = 1; });
