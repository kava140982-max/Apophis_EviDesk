#!/usr/bin/env node
'use strict';
const assert = require('node:assert/strict');
const { tenantContext, tenantMatches, validTenantId } = require('./tenant-policy');

assert.equal(validTenantId('tenant-a'), true);
assert.equal(validTenantId('Tenant-A'), false);
const defaultContext = tenantContext({ headers: {} });
assert.equal(defaultContext.tenant_id, 'synthetic-demo');
assert.equal(defaultContext.authenticated, false);
assert.equal(tenantMatches({ tenant_id: 'synthetic-demo' }, defaultContext), true);
assert.equal(tenantMatches({ tenant_id: 'tenant-other' }, defaultContext), false);
assert.throws(() => tenantContext({ headers: { 'x-apophis-tenant': 'tenant-other' } }), /tenant_context_untrusted/);
console.log(JSON.stringify({ verdict: 'PASS', tenant_ids_validated: true, default_context_explicit: true, cross_tenant_record_blocked: true, untrusted_header_rejected: true }, null, 2));
