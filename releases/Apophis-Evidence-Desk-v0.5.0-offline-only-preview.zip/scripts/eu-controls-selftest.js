#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { resolveControls } = require('./eu-controls-resolver');

const root = path.join(__dirname, '..');
const artifactDir = path.join(root, 'artifacts');
fs.mkdirSync(artifactDir, { recursive: true });
const result = resolveControls({ root, runTests: process.env.APOPHIS_EU_RUN_CONTROL_TESTS === '1' });
const evidenceReport = {
  schema: 'apophis/eu-controls-evidence/v1',
  assessment_scope: result.assessment_scope,
  not_a_certification: result.not_a_certification,
  evidence: result.evidence
};
fs.writeFileSync(path.join(artifactDir, 'eu-controls-result.json'), `${JSON.stringify(result, null, 2)}\n`, { mode: 0o600 });
fs.writeFileSync(path.join(artifactDir, 'eu-controls-evidence.json'), `${JSON.stringify(evidenceReport, null, 2)}\n`, { mode: 0o600 });
process.stdout.write(`${JSON.stringify({ ...result.summary, verdict: result.verdict, scope: result.assessment_scope, not_a_certification: result.not_a_certification, artifacts: ['artifacts/eu-controls-result.json', 'artifacts/eu-controls-evidence.json'] }, null, 2)}\n`);
if (!result.valid) process.exitCode = 1;
