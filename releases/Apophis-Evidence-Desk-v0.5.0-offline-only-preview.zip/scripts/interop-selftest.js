// KaVa-14.10.26 — review watermark
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const bundle = JSON.parse(fs.readFileSync(path.join(root, 'data', 'evidence-bundle.json'), 'utf8'));
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'data', 'interoperability-package.json'), 'utf8'));
const allowed = new Set(['hypothese', 'kontext-gestützt', 'geprüft', 'blockiert']);
const failures = [];
if (pkg.schema !== 'apophis/interoperability-package/v1') failures.push('schema');
if (pkg.import_policy !== 'record-only-no-auto-approval') failures.push('unsafe_import_policy');
if (!pkg.records.length) failures.push('empty_mapping');
for (const claim of bundle.claims || []) {
  if (!claim.id || !claim.statement || !claim.counterclaim || !allowed.has(claim.status) || !Array.isArray(claim.uncertainty)) failures.push(`claim:${claim.id || 'unknown'}`);
}
const result = { valid: failures.length === 0, bundle_claims: bundle.claims?.length || 0, mapping_records: pkg.records.length, failures };
console.log(JSON.stringify(result, null, 2));
process.exit(result.valid ? 0 : 1);
