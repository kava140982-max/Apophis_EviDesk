#!/usr/bin/env node
'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { buildManifest, files } = require('./build-evidence-manifest');

const root = path.join(__dirname, '..');
const manifestPath = path.join(root, 'artifacts', 'release-evidence', 'manifest.json');

function verifyManifest(projectRoot, manifest) {
  if (!manifest || typeof manifest !== 'object' || Array.isArray(manifest)) throw new Error('manifest_invalid');
  if (manifest.schema !== 'apophis/audit-evidence-manifest/v1' || manifest.project !== 'apophis-evidence-desk') throw new Error('manifest_identity_invalid');
  if (manifest.assessment_scope !== 'local-loopback-synthetic-prototype') throw new Error('manifest_scope_missing_or_invalid');
  if (manifest.not_a_certification !== true) throw new Error('manifest_certification_flag_invalid');
  if (!Array.isArray(manifest.files) || manifest.files.length !== files.length) throw new Error('manifest_files_invalid');
  const seen = new Set();
  const realRoot = fs.realpathSync(projectRoot);
  for (const entry of manifest.files) {
    if (!entry || typeof entry.path !== 'string' || seen.has(entry.path) || !files.includes(entry.path)) throw new Error('manifest_path_invalid');
    seen.add(entry.path);
    const absolute = path.resolve(projectRoot, entry.path);
    if (!absolute.startsWith(`${path.resolve(projectRoot)}${path.sep}`) || !fs.realpathSync(absolute).startsWith(`${realRoot}${path.sep}`)) throw new Error('manifest_path_outside_project');
    const stat = fs.statSync(absolute);
    if (!stat.isFile()) throw new Error(`evidence_not_regular_file:${entry.path}`);
    if (!Number.isSafeInteger(entry.bytes) || stat.size !== entry.bytes) throw new Error(`evidence_size_mismatch:${entry.path}`);
    const actual = crypto.createHash('sha256').update(fs.readFileSync(absolute)).digest('hex');
    if (!/^[a-f0-9]{64}$/.test(entry.sha256) || actual !== entry.sha256) throw new Error(`evidence_hash_mismatch:${entry.path}`);
  }
}

function parseManifest(text) {
  try { return JSON.parse(text); } catch (_) { throw new Error('manifest_invalid_json'); }
}

const original = parseManifest(fs.readFileSync(manifestPath, 'utf8'));
verifyManifest(root, original);

const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'apophis-release-evidence-'));
try {
  for (const relative of files) {
    const target = path.join(temp, relative);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.copyFileSync(path.join(root, relative), target);
  }
  const valid = buildManifest(temp, {});
  verifyManifest(temp, valid);

  const missing = files[0];
  fs.unlinkSync(path.join(temp, missing));
  assert.throws(() => verifyManifest(temp, valid), /ENOENT/);
  fs.copyFileSync(path.join(root, missing), path.join(temp, missing));

  const wrongSize = structuredClone(valid);
  wrongSize.files[0].bytes += 1;
  assert.throws(() => verifyManifest(temp, wrongSize), /evidence_size_mismatch/);

  const wrongHash = structuredClone(valid);
  wrongHash.files[0].sha256 = '0'.repeat(64);
  assert.throws(() => verifyManifest(temp, wrongHash), /evidence_hash_mismatch/);

  assert.throws(() => parseManifest('{'), /manifest_invalid_json/);
  const noScope = { ...valid, assessment_scope: '' };
  assert.throws(() => verifyManifest(temp, noScope), /manifest_scope_missing_or_invalid/);
  const certified = { ...valid, not_a_certification: false };
  assert.throws(() => verifyManifest(temp, certified), /manifest_certification_flag_invalid/);
  const traversal = structuredClone(valid);
  traversal.files[0].path = '../outside.json';
  assert.throws(() => verifyManifest(temp, traversal), /manifest_path_invalid/);
} finally {
  fs.rmSync(temp, { recursive: true, force: true });
}

console.log(JSON.stringify({ verdict: 'PASS', manifest: 'artifacts/release-evidence/manifest.json', files: original.files.length, negative_cases: ['missing_file', 'wrong_size', 'wrong_hash', 'invalid_json', 'missing_scope', 'certification_flag', 'path_traversal'] }, null, 2));
