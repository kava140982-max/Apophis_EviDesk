// KaVa-14.10.26 — review watermark
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const root = path.join(__dirname, '..');
const staging = path.join(root, '.audit-pack');
const out = path.join(root, 'public', 'apophis-audit-pack.zip');
fs.rmSync(staging, { recursive: true, force: true });
fs.mkdirSync(path.join(staging, 'data'), { recursive: true });
for (const file of ['evidence-bundle.json', 'approvals.json', 'public-references.json', 'source-snapshots.json', 'passages.json', 'identity-rotations.json', 'interoperability-package.json', 'news-sources.json', 'news-inbox.json']) {
  const source = path.join(root, 'data', file); if (fs.existsSync(source)) fs.copyFileSync(source, path.join(staging, 'data', file));
}
fs.copyFileSync(path.join(root, 'scripts', 'verify.js'), path.join(staging, 'verify.js'));
fs.copyFileSync(path.join(root, 'SANDBOX-SBOM.json'), path.join(staging, 'SANDBOX-SBOM.json'));
for (const file of ['RED_TEAM_REPORT.md', 'RED_TEAM_REPORT_REVIEW.md']) {
  if (fs.existsSync(path.join(root, file))) fs.copyFileSync(path.join(root, file), path.join(staging, file));
}
if (fs.existsSync(path.join(root, 'public', 'apophis-audit-report.pdf'))) fs.copyFileSync(path.join(root, 'public', 'apophis-audit-report.pdf'), path.join(staging, 'apophis-audit-report.pdf'));
fs.writeFileSync(path.join(staging, 'VERIFICATION.md'), '# Apophis Audit-Pack\n\nOffline-Prüfung: `node verify.js data/evidence-bundle.json data/approvals.json`\n\nDas Pack ist kein Sicherheits-, Wirksamkeits-, Herstellbarkeits-, Zulassungs- oder DURC-Nachweis.\n\nKaVa-14.10.26\n');
fs.rmSync(out, { force: true });
execFileSync('zip', ['-qr', out, '.'], { cwd: staging });
fs.rmSync(staging, { recursive: true, force: true });
console.log(`Wrote ${out}`);
