#!/usr/bin/env node
'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const net = require('node:net');
const { spawn } = require('node:child_process');
const root = path.join(__dirname, '..');
const canonical = (value) => Array.isArray(value) ? `[${value.map(canonical).join(',')}]` : value && typeof value === 'object' ? `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(',')}}` : JSON.stringify(value);
function freePort() { return new Promise((resolve, reject) => { const server = net.createServer(); server.once('error', reject); server.listen(0, '127.0.0.1', () => { const port = server.address().port; server.close((error) => error ? reject(error) : resolve(port)); }); }); }
async function request(base, route, method = 'GET', payload) { const response = await fetch(`${base}${route}`, { method, headers: payload ? {'Content-Type': 'application/json'} : {}, body: payload ? JSON.stringify(payload) : undefined }); return { status: response.status, body: await response.json() }; }
(async () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'apophis-group-test-')); const project = path.join(temp, 'project'); fs.cpSync(root, project, { recursive: true });
  const port = await freePort(); const child = spawn(process.execPath, ['server.js'], { cwd: project, env: { ...process.env, PORT: String(port), HOST: '127.0.0.1' }, stdio: 'ignore' }); const base = `http://127.0.0.1:${port}`;
  try {
    for (let i = 0; i < 40; i += 1) { try { if ((await request(base, '/health')).status === 200) break; } catch (_) {} await new Promise((resolve) => setTimeout(resolve, 50)); }
    const challenge = (await request(base, '/api/federation/challenge', 'POST', {})).body;
    const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
    const hello = { challenge_id: challenge.challenge_id, challenge: challenge.challenge, audience: challenge.audience, community_id: 'remote-community-demo', system_id: 'remote-system-demo', origin: 'https://remote.example.org', issued_at: challenge.issued_at, expires_at: challenge.expires_at, public_key_spki_der_base64: publicKey.export({ type: 'spki', format: 'der' }).toString('base64') };
    hello.signature_base64 = crypto.sign(null, Buffer.from(canonical(hello)), privateKey).toString('base64');
    const identified = await request(base, '/api/federation/hello', 'POST', hello); assert.equal(identified.status, 200); assert.equal(identified.body.trust_state, 'identified-not-trusted');
    const exchange = await request(base, '/api/groups/group-evidence-community-demo/exchanges', 'POST', { peer_id: 'remote-system-demo', handshake_id: identified.body.handshake_id, idempotency_key: 'test-1', kind: 'review_request', payload: { bundle_id: 'bundle-hcmv-demo-001', note: 'synthetic review request' } });
    assert.equal(exchange.status, 201); assert.equal(exchange.body.record.status, 'received-needs-review');
    assert.equal((await request(base, '/api/groups/group-evidence-community-demo/exchanges', 'POST', { peer_id: 'remote-system-demo', handshake_id: identified.body.handshake_id, idempotency_key: 'test-1', kind: 'review_request', payload: { bundle_id: 'bundle-hcmv-demo-001' } })).body.duplicate, true);
    console.log(JSON.stringify({ verdict: 'PASS', peer_identity: 'identified-not-trusted', replay_protection: 'single-use-challenge', group_exchange: 'received-needs-review', idempotency: 'deduplicated' }, null, 2));
  } finally { child.kill('SIGTERM'); fs.rmSync(temp, { recursive: true, force: true }); }
})().catch((error) => { console.error(JSON.stringify({ verdict: 'FAIL', error: error.message })); process.exitCode = 1; });
