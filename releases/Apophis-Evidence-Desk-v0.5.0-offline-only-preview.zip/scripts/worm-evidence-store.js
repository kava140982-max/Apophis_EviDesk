#!/usr/bin/env node
'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

function canonical(value) {
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(',')}}`;
  return JSON.stringify(value);
}

function snapshotHash(value) {
  return crypto.createHash('sha256').update(canonical(value)).digest('hex');
}

function appendSnapshot(root, namespace, payload, metadata = {}) {
  if (!/^[a-z0-9][a-z0-9._-]{1,63}$/.test(namespace)) throw new Error('invalid_worm_namespace');
  if (metadata.tenant_id && (!/^[a-z0-9][a-z0-9._-]{1,63}$/.test(metadata.tenant_id) || payload?.tenant_id !== metadata.tenant_id)) throw new Error('worm_payload_tenant_mismatch');
  const directory = path.join(root, namespace);
  fs.mkdirSync(directory, { recursive: true, mode: 0o700 });
  const payloadHash = snapshotHash(payload);
  const envelope = {
    schema: 'apophis/worm-evidence-snapshot/v1',
    namespace,
    captured_at: new Date().toISOString(),
    payload_sha256: payloadHash,
    metadata,
    payload
  };
  const body = `${JSON.stringify(envelope, null, 2)}\n`;
  const objectPath = path.join(directory, `${payloadHash}.json`);
  try {
    const fd = fs.openSync(objectPath, 'wx', 0o400);
    try { fs.writeFileSync(fd, body); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
    fs.chmodSync(objectPath, 0o400);
    const directoryFd = fs.openSync(directory, 'r');
    try { fs.fsyncSync(directoryFd); } finally { fs.closeSync(directoryFd); }
    return { created: true, path: path.relative(root, objectPath), sha256: crypto.createHash('sha256').update(body).digest('hex'), payload_sha256: payloadHash };
  } catch (error) {
    if (error.code !== 'EEXIST') throw error;
    const existing = fs.readFileSync(objectPath, 'utf8');
    let existingEnvelope;
    try { existingEnvelope = JSON.parse(existing); } catch (_) { throw new Error('worm_existing_object_invalid'); }
    if (existingEnvelope.payload_sha256 !== payloadHash || existingEnvelope.schema !== 'apophis/worm-evidence-snapshot/v1' || existingEnvelope.namespace !== namespace || snapshotHash(existingEnvelope.payload) !== payloadHash || path.basename(objectPath) !== `${payloadHash}.json`) throw new Error('worm_hash_collision_or_overwrite_attempt');
    return { created: false, path: path.relative(root, objectPath), sha256: crypto.createHash('sha256').update(existing).digest('hex'), payload_sha256: payloadHash };
  }
}

function verifyNamespace(root, namespace, tenantId = null) {
  if (typeof namespace !== 'string' || !/^[a-z0-9][a-z0-9._-]{1,63}$/.test(namespace)) throw new Error('invalid_worm_namespace');
  if (tenantId !== null && (typeof tenantId !== 'string' || !/^[a-z0-9][a-z0-9._-]{1,63}$/.test(tenantId))) throw new Error('invalid_tenant_id');
  const directory = path.join(root, namespace);
  if (!fs.existsSync(directory)) return { namespace, files: 0, valid: true, failures: [] };
  const failures = [];
  const files = fs.readdirSync(directory).filter((name) => name.endsWith('.json')).sort();
  let checked = 0;
  for (const name of files) {
    try {
      const full = path.join(directory, name);
      const envelope = JSON.parse(fs.readFileSync(full, 'utf8'));
      const owners = [envelope.metadata?.tenant_id, envelope.payload?.tenant_id].filter(Boolean);
      if (tenantId && !owners.includes(tenantId)) continue;
      checked += 1;
      const mode = fs.statSync(full).mode;
      if (envelope.schema !== 'apophis/worm-evidence-snapshot/v1' || envelope.namespace !== namespace || envelope.metadata?.tenant_id && envelope.payload?.tenant_id !== envelope.metadata.tenant_id || envelope.payload_sha256 !== snapshotHash(envelope.payload) || name !== `${envelope.payload_sha256}.json` || (mode & 0o222) !== 0) failures.push(name);
    } catch (_) {
      if (tenantId) failures.push('unattributed_corruption');
      else failures.push(name);
    }
  }
  return { namespace, files: tenantId ? checked : files.length, valid: failures.length === 0, failures };
}

module.exports = { appendSnapshot, verifyNamespace, snapshotHash };
