#!/usr/bin/env node
'use strict';

const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const zlib = require('node:zlib');
const { spawnSync } = require('node:child_process');

const sourceRoot = path.resolve(__dirname, '..');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'apophis-recovery-eval-'));
const keyHex = 'a'.repeat(64);
function writeAdapter(file, actors, adapterKey = keyHex) {
  fs.writeFileSync(file, `#!/usr/bin/env node\nconst [operation, , resource_sha256] = process.argv.slice(2);\nprocess.stdout.write(JSON.stringify({schema:'apophis/dual-control-authorization/v1',decision:'allow',operation,resource_sha256,authorization_id:'eval-'+operation,distinct_actors:${JSON.stringify(actors)},expires_at:new Date(Date.now()+60000).toISOString(),key_hex:${JSON.stringify(adapterKey)}}));\n`);
  fs.chmodSync(file, 0o700);
}
function run(script, args, env) {
  const result = spawnSync(process.execPath, [script, ...args], { encoding: 'utf8', env: { ...process.env, ...env } });
  return { ...result, json: (() => { try { return JSON.parse(result.stdout.trim().split('\n').at(-1)); } catch (_) { return null; } })() };
}
function setupProject(name, scriptName) {
  const root = path.join(temp, name);
  fs.mkdirSync(path.join(root, 'scripts'), { recursive: true });
  fs.mkdirSync(path.join(root, 'data', 'keys'), { recursive: true });
  fs.copyFileSync(path.join(sourceRoot, 'scripts', scriptName), path.join(root, 'scripts', scriptName));
  fs.writeFileSync(path.join(root, 'data', 'fixture.txt'), 'synthetic-recovery-fixture\n');
  fs.writeFileSync(path.join(root, 'data', 'keys', 'private-marker.txt'), 'must-not-be-included\n');
  return root;
}

try {
  const backupRoot = setupProject('backup-project', 'backup.js');
  fs.writeFileSync(path.join(backupRoot, 'package.json'), JSON.stringify({ version: 'eval' }));
  const backupScript = path.join(backupRoot, 'scripts', 'backup.js');
  const backupDir = path.join(temp, 'backup-target');
  const adapterGood = path.join(temp, 'adapter-good');
  const adapterOne = path.join(temp, 'adapter-one-person');
  const adapterWrongKey = path.join(temp, 'adapter-wrong-key');
  writeAdapter(adapterGood, ['reviewer-a', 'reviewer-b']);
  writeAdapter(adapterOne, ['reviewer-a']);
  writeAdapter(adapterWrongKey, ['reviewer-a', 'reviewer-b'], 'b'.repeat(64));

  let result = run(backupScript, ['create'], { APOPHIS_BACKUP_AUTHORIZER: adapterOne, APOPHIS_BACKUP_DIR: backupDir });
  assert.notEqual(result.status, 0, 'one-person backup approval must be denied');
  assert.equal(result.stderr.includes('two_person_authorization_invalid'), true);
  assert.equal(fs.existsSync(backupDir), false, 'denied create must not create backup destination');

  result = run(backupScript, ['create'], { APOPHIS_BACKUP_AUTHORIZER: adapterGood, APOPHIS_BACKUP_DIR: path.join(backupRoot, 'data', 'inside') });
  assert.notEqual(result.status, 0, 'backup destination inside project must be denied');
  assert.equal(result.stderr.includes('backup_destination_must_be_outside_project'), true);

  const symlink = path.join(backupRoot, 'data', 'escape-link');
  fs.symlinkSync(path.join(temp, 'not-readable-target'), symlink);
  result = run(backupScript, ['create'], { APOPHIS_BACKUP_AUTHORIZER: adapterGood, APOPHIS_BACKUP_DIR: backupDir });
  assert.notEqual(result.status, 0, 'backup containing a symlink must be denied');
  assert.equal(result.stderr.includes('backup_symlink_rejected'), true);
  fs.unlinkSync(symlink);

  result = run(backupScript, ['create'], { APOPHIS_BACKUP_AUTHORIZER: adapterGood, APOPHIS_BACKUP_DIR: backupDir });
  assert.equal(result.status, 0, result.stderr);
  const backupPath = result.json.backup;
  assert.equal(result.json.private_keys_included, false);
  assert.equal(result.json.image_type, 'application-data-only');

  result = run(backupScript, ['verify', backupPath], { APOPHIS_BACKUP_AUTHORIZER: adapterGood });
  assert.equal(result.status, 0, result.stderr);
  assert.equal(result.json.valid, true);
  assert.equal(result.json.file_count, 1, 'key directory must be excluded');

  result = run(backupScript, ['verify', backupPath], { APOPHIS_BACKUP_AUTHORIZER: adapterWrongKey });
  assert.notEqual(result.status, 0, 'wrong decryption key must fail verification');

  const restoreDir = path.join(temp, 'restore-target');
  fs.mkdirSync(restoreDir);
  result = run(backupScript, ['restore', backupPath, restoreDir], { APOPHIS_BACKUP_AUTHORIZER: adapterGood });
  assert.equal(result.status, 0, result.stderr);
  assert.equal(fs.readFileSync(path.join(restoreDir, 'fixture.txt'), 'utf8'), 'synthetic-recovery-fixture\n');
  assert.equal(fs.existsSync(path.join(restoreDir, 'keys', 'private-marker.txt')), false);

  const damaged = path.join(backupDir, 'apophis-data-2026-10-20T00-00-00-000Z.backup.enc');
  const bytes = fs.readFileSync(backupPath); bytes[bytes.length - 1] ^= 1; fs.writeFileSync(damaged, bytes);
  result = run(backupScript, ['verify', damaged], { APOPHIS_BACKUP_AUTHORIZER: adapterGood });
  assert.notEqual(result.status, 0, 'modified encrypted backup must fail authentication');

  for (const stamp of ['2026-10-20T00-00-01-000Z', '2026-10-20T00-00-02-000Z']) {
    fs.copyFileSync(backupPath, path.join(backupDir, `apophis-data-${stamp}.backup.enc`));
  }
  result = run(backupScript, ['prune'], { APOPHIS_BACKUP_AUTHORIZER: adapterOne, APOPHIS_BACKUP_DIR: backupDir, APOPHIS_BACKUP_KEEP: '1' });
  assert.notEqual(result.status, 0, 'one-person deletion authorization must be denied');
  assert.equal(fs.readdirSync(backupDir).filter((name) => name.endsWith('.backup.enc')).length, 4, 'denied pruning must delete nothing');
  result = run(backupScript, ['prune'], { APOPHIS_BACKUP_AUTHORIZER: adapterGood, APOPHIS_BACKUP_DIR: backupDir, APOPHIS_BACKUP_KEEP: '1' });
  assert.equal(result.status, 0, result.stderr);
  assert.equal(result.json.deleted.length, 3);

  const emergencyRoot = setupProject('emergency-project', 'emergency-control.js');
  const emergencyScript = path.join(emergencyRoot, 'scripts', 'emergency-control.js');
  const keyPair = crypto.generateKeyPairSync('rsa', { modulusLength: 3072, publicKeyEncoding: { type: 'spki', format: 'pem' }, privateKeyEncoding: { type: 'pkcs8', format: 'pem' } });
  const publicKeyPath = path.join(temp, 'recipient-public.pem');
  fs.writeFileSync(publicKeyPath, keyPair.publicKey);
  const publicDer = crypto.createPublicKey(keyPair.publicKey).export({ type: 'spki', format: 'der' });
  const fingerprint = crypto.createHash('sha256').update(publicDer).digest('hex');
  fs.mkdirSync(path.join(emergencyRoot, 'config'), { recursive: true });
  fs.writeFileSync(path.join(emergencyRoot, 'config', 'authority-recipients.json'), JSON.stringify({ schema: 'apophis/authority-recipients/v1', recipients: [{ id: 'synthetic-authority', label: 'Synthetic test only', jurisdiction: 'test', enabled: true, public_key_path: publicKeyPath, public_key_sha256: fingerprint }] }));
  const evidenceDir = path.join(temp, 'evidence-target');
  const emergencyEnv = { APOPHIS_EMERGENCY_AUTHORIZER: adapterOne, APOPHIS_EMERGENCY_EVIDENCE_DIR: evidenceDir };
  result = run(emergencyScript, ['trigger', 'synthetic-authority'], emergencyEnv);
  assert.notEqual(result.status, 0, 'one-person emergency trigger must be denied');
  result = run(emergencyScript, ['status'], {});
  assert.equal(result.json.locked, false, 'denied trigger leaves application unlocked');

  result = run(emergencyScript, ['trigger', 'synthetic-authority'], { ...emergencyEnv, APOPHIS_EMERGENCY_AUTHORIZER: adapterGood });
  assert.equal(result.status, 0, result.stderr);
  assert.equal(result.json.locked, true);
  assert.equal(result.json.physical_systems_stopped, false);
  const evidence = fs.readFileSync(result.json.evidence_file);
  const magic = Buffer.from('APOPHIS-EVIDENCE-V1\n');
  assert.equal(evidence.subarray(0, magic.length).equals(magic), true);
  let offset = magic.length;
  assert.equal(evidence[offset++], 1);
  const keyLength = evidence.readUInt16BE(offset); offset += 2;
  const wrappedKey = evidence.subarray(offset, offset + keyLength); offset += keyLength;
  const iv = evidence.subarray(offset, offset + 12); offset += 12;
  const authTag = evidence.subarray(offset, offset + 16); offset += 16;
  const decipher = crypto.createDecipheriv('aes-256-gcm', crypto.privateDecrypt({ key: keyPair.privateKey, oaepHash: 'sha256', padding: crypto.constants.RSA_PKCS1_OAEP_PADDING }, wrappedKey), iv);
  decipher.setAAD(magic); decipher.setAuthTag(authTag);
  const plaintext = zlib.gunzipSync(Buffer.concat([decipher.update(evidence.subarray(offset)), decipher.final()]));
  const payload = JSON.parse(plaintext.toString('utf8'));
  assert.equal(payload.scope, 'application-data-only');
  assert.deepEqual(payload.files.map((file) => file.path), ['fixture.txt']);
  assert.equal(payload.files.some((file) => file.path.includes('private-marker')), false);

  result = run(emergencyScript, ['release'], { APOPHIS_EMERGENCY_AUTHORIZER: adapterOne });
  assert.notEqual(result.status, 0, 'one-person release must be denied');
  result = run(emergencyScript, ['status'], {});
  assert.equal(result.json.locked, true, 'denied release leaves application locked');
  result = run(emergencyScript, ['release'], { APOPHIS_EMERGENCY_AUTHORIZER: adapterGood });
  assert.equal(result.status, 0, result.stderr);
  assert.equal(result.json.locked, false);
  result = run(emergencyScript, ['status'], {});
  assert.equal(result.json.locked, false);

  process.stdout.write(`${JSON.stringify({ verdict: 'PASS', backup: ['one_person_denied', 'external_destination_required', 'symlinks_rejected', 'encrypted_create_verify_restore', 'wrong_key_rejected', 'tampering_rejected', 'two_person_pruning'], emergency: ['two_person_trigger_release', 'rsa_recipient_envelope_decryptable', 'application_scope_only', 'key_directory_excluded', 'denied_actions_fail_closed'] }, null, 2)}\n`);
} finally {
  fs.rmSync(temp, { recursive: true, force: true });
}
