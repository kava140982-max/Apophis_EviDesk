#!/usr/bin/env node
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { appendSnapshot, verifyNamespace } = require('./worm-evidence-store');

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'apophis-worm-'));
try {
  const payload = { tenant_id: 'synthetic-demo', event: 'release', value: 1 };
  const first = appendSnapshot(root, 'audit', payload, { tenant_id: 'synthetic-demo' });
  const duplicate = appendSnapshot(root, 'audit', payload, { tenant_id: 'synthetic-demo' });
  assert.equal(first.created, true);
  assert.equal(duplicate.created, false);
  assert.equal(verifyNamespace(root, 'audit').valid, true);
  const objectPath = path.join(root, first.path);
  assert.equal((fs.statSync(objectPath).mode & 0o222), 0, 'WORM object must not be writable');
  appendSnapshot(root, 'audit', { tenant_id: 'tenant-other', event: 'other-tenant' }, { tenant_id: 'tenant-other' });
  assert.equal(verifyNamespace(root, 'audit', 'synthetic-demo').files, 1, 'tenant verification must exclude other tenant snapshots');
  assert.equal(verifyNamespace(root, 'audit', 'tenant-empty').files, 0);
  assert.throws(() => appendSnapshot(root, '../escape', { value: 1 }), /invalid_worm_namespace/);
  assert.throws(() => verifyNamespace(root, '../escape'), /invalid_worm_namespace/);
  assert.throws(() => appendSnapshot(root, 'audit', payload, { tenant_id: 'tenant-other' }), /worm_payload_tenant_mismatch/);

  const badName = path.join(root, 'audit', `${'f'.repeat(64)}.json`);
  fs.copyFileSync(objectPath, badName);
  assert.equal(verifyNamespace(root, 'audit').valid, false, 'incorrect content address must fail verification');
  fs.unlinkSync(badName);

  fs.writeFileSync(path.join(root, 'audit', 'tampered.json'), '{"tampered":true}\n');
  assert.equal(verifyNamespace(root, 'audit').valid, false);
  fs.writeFileSync(path.join(root, 'audit', 'invalid.json'), '{');
  assert.equal(verifyNamespace(root, 'audit').valid, false, 'invalid JSON must be detected');

  const existing = fs.readFileSync(objectPath, 'utf8');
  fs.chmodSync(objectPath, 0o600);
  fs.writeFileSync(objectPath, existing.replace('"value": 1', '"value": 2'));
  assert.throws(() => appendSnapshot(root, 'audit', payload, { tenant_id: 'synthetic-demo' }), /worm_hash_collision_or_overwrite_attempt/);
  assert.equal(verifyNamespace(root, 'audit').valid, false, 'tampered object must fail verification');
  console.log(JSON.stringify({ verdict: 'PASS', append_only: true, content_addressed: true, overwrite_rejected: true, tamper_detected: true, invalid_json_detected: true, namespace_traversal_rejected: true, hash_name_verified: true, tenant_scoped_verification: true }, null, 2));
} finally {
  fs.rmSync(root, { recursive: true, force: true });
}
