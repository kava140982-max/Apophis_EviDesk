#!/usr/bin/env node
'use strict';

const TENANT_PATTERN = /^[a-z0-9][a-z0-9._-]{1,63}$/;
const DEFAULT_TENANT = process.env.APOPHIS_DEFAULT_TENANT_ID || 'synthetic-demo';

function validTenantId(value) {
  return typeof value === 'string' && TENANT_PATTERN.test(value);
}

function tenantContext(req) {
  const supplied = typeof req?.headers?.['x-apophis-tenant'] === 'string' ? req.headers['x-apophis-tenant'].trim() : '';
  const trustHeader = process.env.APOPHIS_TRUST_TENANT_HEADER === '1';
  if (supplied && !validTenantId(supplied)) throw new Error('invalid_tenant_context');
  if (trustHeader) {
    if (!supplied) throw new Error('tenant_context_required');
    return { tenant_id: supplied, source: 'trusted-auth-adapter', authenticated: true };
  }
  if (supplied && supplied !== DEFAULT_TENANT) throw new Error('tenant_context_untrusted');
  return { tenant_id: DEFAULT_TENANT, source: 'loopback-demo-configured', authenticated: false };
}

function tenantMatches(record, context) {
  return Boolean(record && context && record.tenant_id === context.tenant_id);
}

function requireTenantOnRecord(record, context) {
  return tenantMatches(record, context);
}

module.exports = { DEFAULT_TENANT, validTenantId, tenantContext, tenantMatches, requireTenantOnRecord };
