#!/usr/bin/env node
// KaVa-14.10.26 — review watermark
const fs = require('fs');
const crypto = require('crypto');
const [bundlePath, approvalsPath] = process.argv.slice(2);
if (!bundlePath) { console.error('usage: node scripts/verify.js data/evidence-bundle.json [data/approvals.json]'); process.exit(2); }
const canonical = (value) => { if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`; if (value && typeof value === 'object') return `{${Object.keys(value).sort().map((k) => `${JSON.stringify(k)}:${canonical(value[k])}`).join(',')}}`; return JSON.stringify(value); };
const digest = (value) => crypto.createHash('sha256').update(canonical(value)).digest('hex');
const bundle = JSON.parse(fs.readFileSync(bundlePath, 'utf8')); const unsigned = { ...bundle }; delete unsigned.receipt; delete unsigned.signature;
const publicKey = crypto.createPublicKey({ key: Buffer.from(bundle.signature.public_key_spki_der_base64, 'base64'), type: 'spki', format: 'der' });
const receipt = bundle.receipt.bundle_hash === digest(unsigned);
const signature = crypto.verify(null, Buffer.from(canonical(unsigned)), publicKey, Buffer.from(bundle.signature.value_base64, 'base64'));
const fingerprint = crypto.createHash('sha256').update(Buffer.from(bundle.signature.public_key_spki_der_base64, 'base64')).digest('hex');
const identity = !bundle.identity?.active_fingerprint || bundle.identity.active_fingerprint === fingerprint;
let approvals = true;
let approvalsError = null;
if (approvalsPath) {
  try {
    if (!fs.existsSync(approvalsPath) || !fs.statSync(approvalsPath).isFile()) throw new Error('approvals_file_missing_or_not_regular');
    const log = JSON.parse(fs.readFileSync(approvalsPath, 'utf8'));
    if (!log || typeof log !== 'object' || Array.isArray(log) || !Array.isArray(log.records)) throw new Error('approvals_log_invalid');
    let previous = '0'.repeat(64);
    for (const record of log.records) {
      if (!record || typeof record !== 'object' || Array.isArray(record)) { approvals = false; break; }
      const raw = { ...record };
      delete raw.record_hash;
      const shapeOk = record.record_id && record.created_at && record.actor && ['author', 'reviewer', 'biosecurity'].includes(record.role) && ['approve', 'reject', 'escalate'].includes(record.decision) && record.rationale && record.scope === 'bundle-hcmv-demo-001' && record.bundle_hash === bundle.receipt.bundle_hash;
      if (!shapeOk || record.prev_hash !== previous || record.record_hash !== digest(raw)) approvals = false;
      previous = record.record_hash;
    }
    approvals = approvals && previous === (log.chain_head || '0'.repeat(64));
    if (!approvals) approvalsError = 'approvals_integrity_invalid';
  } catch (error) {
    approvals = false;
    approvalsError = error.code === 'ENOENT' ? 'approvals_file_missing_or_not_regular' : (error.message || 'approvals_log_unreadable');
  }
}
const result = { bundle_hash: bundle.receipt.bundle_hash, receipt_ok: receipt, signature_ok: signature, identity_ok: identity, approvals_ok: approvals, ...(approvalsError ? { approvals_error: approvalsError } : {}), valid: receipt && signature && identity && approvals };
console.log(JSON.stringify(result, null, 2)); process.exit(result.valid ? 0 : 1);
