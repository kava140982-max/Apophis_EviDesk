// Offline-only interoperability checks. External destinations may be recorded, never contacted.
'use strict';
const net = require('node:net');
const { denyExternalNetwork } = require('./network-policy');

const BLOCKED_HOST_SUFFIXES = ['.localhost', '.local', '.internal', '.test', '.invalid', '.example'];
const MAX_RESPONSE_BYTES = 256 * 1024;

function isBlockedIp(address) {
  const family = net.isIP(address);
  if (family === 4) {
    const octets = address.split('.').map(Number);
    const [a, b] = octets;
    return a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || (a === 198 && (b === 18 || b === 19));
  }
  if (family === 6) {
    const normalized = address.toLowerCase();
    return normalized === '::1' || normalized === '::' || normalized.startsWith('fc') || normalized.startsWith('fd') || normalized.startsWith('fe8') || normalized.startsWith('fe9') || normalized.startsWith('fea') || normalized.startsWith('feb') || normalized.startsWith('ff') || normalized.startsWith('2001:db8:') || normalized.startsWith('::ffff:127.') || normalized.startsWith('::ffff:10.') || normalized.startsWith('::ffff:192.168.');
  }
  return true;
}

function validateExternalUrl(raw, allowedHosts = new Set()) {
  let url;
  try { url = new URL(raw); } catch (_) { throw new Error('source_url_invalid'); }
  const hostname = url.hostname.toLowerCase();
  const allow = allowedHosts.size === 0 || allowedHosts.has(hostname);
  if (url.protocol !== 'https:' || url.username || url.password || url.hash || url.port && url.port !== '443' || net.isIP(hostname) || !hostname.includes('.') || BLOCKED_HOST_SUFFIXES.some((suffix) => hostname === suffix.slice(1) || hostname.endsWith(suffix)) || !allow) throw new Error('source_not_allowlisted');
  return url;
}

async function resolvePinnedAddress() {
  denyExternalNetwork('dns_resolution');
}

async function fetchPinned() {
  denyExternalNetwork('external_fetch');
}

module.exports = { isBlockedIp, validateExternalUrl, resolvePinnedAddress, fetchPinned, MAX_RESPONSE_BYTES };
