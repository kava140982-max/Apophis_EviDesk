'use strict';

const POLICY = Object.freeze({
  mode: 'offline-only',
  external_network: 'deny',
  remote_bind: 'deny',
  local_loopback_ui: 'allow'
});

function isLoopbackHost(host) {
  return ['127.0.0.1', '::1'].includes(String(host || '').toLowerCase());
}

function assertLoopbackHost(host, component = 'service') {
  if (!isLoopbackHost(host)) throw new Error(`${component}_remote_bind_disabled`);
  return true;
}

function denyExternalNetwork(operation = 'network_operation') {
  const error = new Error(`external_network_disabled:${operation}`);
  error.code = 'EXTERNAL_NETWORK_DISABLED';
  throw error;
}

module.exports = { POLICY, isLoopbackHost, assertLoopbackHost, denyExternalNetwork };
