#!/usr/bin/env node
'use strict';

// Application-layer emergency lock and recipient-encrypted application-data evidence snapshot.
// This is not a host/OS image, remote transfer client, or OT/physical emergency-stop system.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const zlib = require('node:zlib');
const { execFileSync } = require('node:child_process');
const { promisify } = require('node:util');
const gzip = promisify(zlib.gzip);
const ROOT = path.resolve(__dirname, '..');
const DATA = path.join(ROOT, 'data');
const CONTROL = path.join(DATA, 'emergency-control');
const LOCK = path.join(CONTROL, 'lock.json');
const REGISTRY = path.join(ROOT, 'config', 'authority-recipients.json');
const MAGIC = Buffer.from('APOPHIS-EVIDENCE-V1\n', 'ascii');
const MAX_BYTES = 512 * 1024 * 1024;

function canonical(value) {
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(',')}}`;
  return JSON.stringify(value);
}
function sha(value) { return crypto.createHash('sha256').update(value).digest('hex'); }
function readJson(file) { return JSON.parse(fs.readFileSync(file, 'utf8')); }
function writeAtomic(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  const temp = `${file}.tmp-${process.pid}`;
  fs.writeFileSync(temp, `${JSON.stringify(value, null, 2)}\n`, { flag: 'wx', mode: 0o600 });
  fs.renameSync(temp, file);
}
function authorize(operation, resource, resourceHash) {
  const adapter = process.env.APOPHIS_EMERGENCY_AUTHORIZER || process.env.APOPHIS_BACKUP_AUTHORIZER;
  if (!adapter || !path.isAbsolute(adapter) || !fs.statSync(adapter).isFile()) throw new Error('two_person_authorization_adapter_required');
  let text;
  try {
    text = execFileSync(adapter, [operation, path.resolve(resource), resourceHash], {
      encoding: 'utf8', timeout: 15000, stdio: ['ignore', 'pipe', 'ignore'],
      env: { PATH: process.env.PATH || '', LANG: process.env.LANG || 'C', APOPHIS_AUTHZ_PROTOCOL: 'apophis/dual-control-authorization/v1' }
    });
  } catch (_) { throw new Error('two_person_authorization_denied'); }
  let approval;
  try { approval = JSON.parse(text); } catch (_) { throw new Error('authorization_response_invalid'); }
  const actors = Array.isArray(approval.distinct_actors) ? approval.distinct_actors.filter((v) => typeof v === 'string' && v.trim()) : [];
  if (approval.schema !== 'apophis/dual-control-authorization/v1' || approval.decision !== 'allow' || approval.operation !== operation || approval.resource_sha256 !== resourceHash || !approval.authorization_id || new Set(actors).size < 2 || !Number.isFinite(Date.parse(approval.expires_at)) || Date.parse(approval.expires_at) <= Date.now()) throw new Error('two_person_authorization_invalid');
  return { id: approval.authorization_id, actors: [...new Set(actors)] };
}
function listFiles(dir, rel = '') {
  const result = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
    const next = path.posix.join(rel, entry.name);
    if (next === 'keys' || next.startsWith('keys/') || next === 'emergency-control' || next.startsWith('emergency-control/')) continue;
    if (entry.isSymbolicLink()) throw new Error(`evidence_symlink_rejected:${next}`);
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) result.push(...listFiles(full, next));
    else if (entry.isFile()) {
      const bytes = fs.readFileSync(full);
      if (bytes.length > MAX_BYTES) throw new Error(`evidence_file_too_large:${next}`);
      result.push({ path: next, bytes, sha256: sha(bytes) });
    }
  }
  return result;
}
function destination() {
  const value = process.env.APOPHIS_EMERGENCY_EVIDENCE_DIR;
  if (!value) throw new Error('external_evidence_destination_required');
  const resolved = path.resolve(value);
  if (resolved === ROOT || resolved.startsWith(`${ROOT}${path.sep}`)) throw new Error('evidence_destination_must_be_outside_project');
  return resolved;
}
function authority(id) {
  if (!/^[a-z0-9][a-z0-9._-]{1,79}$/i.test(id || '')) throw new Error('authority_id_invalid');
  if (!fs.existsSync(REGISTRY)) throw new Error('authority_recipient_registry_required');
  const registry = readJson(REGISTRY);
  const item = (registry.recipients || []).find((candidate) => candidate.id === id && candidate.enabled === true);
  if (!item || !path.isAbsolute(item.public_key_path)) throw new Error('authority_recipient_not_enabled');
  const pem = fs.readFileSync(item.public_key_path);
  const key = crypto.createPublicKey(pem);
  if (key.asymmetricKeyType !== 'rsa' || (key.asymmetricKeyDetails?.modulusLength || 0) < 3072) throw new Error('authority_key_must_be_rsa_3072_or_stronger');
  const der = key.export({ type: 'spki', format: 'der' });
  if (sha(der) !== item.public_key_sha256) throw new Error('authority_key_fingerprint_mismatch');
  return { id: item.id, label: String(item.label || item.id).slice(0, 160), jurisdiction: String(item.jurisdiction || '').slice(0, 120), key, fingerprint: sha(der) };
}
async function trigger(id) {
  if (fs.existsSync(LOCK)) throw new Error('emergency_lock_already_active');
  const recipient = authority(id);
  const outDir = destination();
  let files = listFiles(DATA);
  const manifest = files.map(({ path: name, sha256 }) => ({ path: name, sha256 }));
  const evidenceHash = sha(canonical(manifest));
  const approval = authorize('emergency_trigger', DATA, evidenceHash);
  // Close the application immediately after authorization; if packaging fails, it remains locked.
  const lock = { schema: 'apophis/emergency-lock/v1', state: 'locked', scope: 'apophis-application-only', activated_at: new Date().toISOString(), authorization_id: approval.id, authorized_actor_count: approval.actors.length, evidence_file: null, evidence_sha256: null, evidence_payload_sha256: null, recipient_id: recipient.id, recipient_public_key_sha256: recipient.fingerprint, evidence_state: 'creation_pending', physical_systems_stopped: false, release_requires_two_person_authorization: true };
  writeAtomic(LOCK, lock);
  const lockedFiles = listFiles(DATA);
  if (sha(canonical(lockedFiles.map(({ path: name, sha256 }) => ({ path: name, sha256 })))) !== evidenceHash) throw new Error('evidence_changed_during_authorization_system_remains_locked');
  files = lockedFiles;
  const payload = Buffer.from(JSON.stringify({ schema: 'apophis/application-evidence/v1', created_at: new Date().toISOString(), scope: 'application-data-only', recipient: { id: recipient.id, jurisdiction: recipient.jurisdiction, public_key_sha256: recipient.fingerprint }, files: files.map(({ path: name, bytes, sha256: digest }) => ({ path: name, data_base64: bytes.toString('base64'), sha256: digest })) }));
  if (payload.length > MAX_BYTES) throw new Error('evidence_payload_too_large');
  const compressed = await gzip(payload, { level: 9 });
  const dataKey = crypto.randomBytes(32); const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', dataKey, iv); cipher.setAAD(MAGIC);
  const ciphertext = Buffer.concat([cipher.update(compressed), cipher.final()]);
  const wrappedKey = crypto.publicEncrypt({ key: recipient.key, oaepHash: 'sha256', padding: crypto.constants.RSA_PKCS1_OAEP_PADDING }, dataKey);
  dataKey.fill(0);
  const envelope = Buffer.concat([MAGIC, Buffer.from([1]), Buffer.from([wrappedKey.length >> 8, wrappedKey.length & 255]), wrappedKey, iv, cipher.getAuthTag(), ciphertext]);
  fs.mkdirSync(outDir, { recursive: true, mode: 0o700 });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const target = path.join(outDir, `apophis-evidence-${stamp}.enc`);
  fs.writeFileSync(target, envelope, { flag: 'wx', mode: 0o600 });
  Object.assign(lock, { evidence_file: target, evidence_sha256: sha(envelope), evidence_payload_sha256: sha(payload), evidence_state: 'encrypted_snapshot_created' });
  writeAtomic(LOCK, lock);
  console.log(JSON.stringify({ locked: true, scope: lock.scope, evidence_file: target, evidence_sha256: lock.evidence_sha256, recipient_id: recipient.id, recipient_public_key_sha256: recipient.fingerprint, file_count: files.length, physical_systems_stopped: false, authorization_id: approval.id }));
}
function recordRelease(lock, approval) {
  const file = path.join(CONTROL, 'events.json');
  const store = fs.existsSync(file) ? readJson(file) : { schema: 'apophis/emergency-events/v1', events: [] };
  const previous = store.events.at(-1)?.record_sha256 || '0'.repeat(64);
  const event = { event_id: `release-${crypto.randomBytes(10).toString('hex')}`, action: 'release', occurred_at: new Date().toISOString(), lock_sha256: sha(fs.readFileSync(LOCK)), evidence_sha256: lock.evidence_sha256, authorization_id: approval.id, authorized_actor_count: approval.actors.length, previous_sha256: previous };
  event.record_sha256 = sha(canonical(event)); store.events.push(event); writeAtomic(file, store);
}
function release() {
  if (!fs.existsSync(LOCK)) throw new Error('emergency_lock_not_active');
  const lock = readJson(LOCK); const lockHash = sha(fs.readFileSync(LOCK));
  const approval = authorize('emergency_release', LOCK, lockHash);
  recordRelease(lock, approval);
  fs.unlinkSync(LOCK);
  console.log(JSON.stringify({ locked: false, released: true, authorization_id: approval.id, authorized_actor_count: approval.actors.length, evidence_sha256: lock.evidence_sha256 }));
}
function status() {
  if (!fs.existsSync(LOCK)) return console.log(JSON.stringify({ locked: false, scope: 'apophis-application-only' }));
  const lock = readJson(LOCK); console.log(JSON.stringify({ locked: true, scope: lock.scope, activated_at: lock.activated_at, evidence_file: lock.evidence_file, evidence_sha256: lock.evidence_sha256, recipient_id: lock.recipient_id, physical_systems_stopped: false, release_requires_two_person_authorization: true }));
}
(async () => {
  const [command, id] = process.argv.slice(2);
  if (command === 'trigger' && id) await trigger(id);
  else if (command === 'release') release();
  else if (command === 'status') status();
  else throw new Error('usage: node scripts/emergency-control.js <status|trigger <authority-id>|release>');
})().catch((error) => { console.error(error.message); process.exitCode = 1; });
