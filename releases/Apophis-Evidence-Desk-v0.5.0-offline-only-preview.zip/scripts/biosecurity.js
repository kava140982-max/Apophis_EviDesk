// KaVa-14.10.26 — review watermark
const CLASSES = {
  sequence: /\b(sequence|sequenz|primer|plasmid|genome|genom|nucleotide|nukleotid|amino acid|aminosäure)\b/i,
  protocol: /\b(step[- ]by[- ]step|protocol|protokoll|culture conditions|kulturbedingungen|transfection|transfektion|purification|aufreinigung)\b/i,
  dosing: /\b(dos(e|ierung)|dose|mg\/kg|µg\/kg|mol\/l|concentration|konzentration|injection|injektion)\b/i
};
function scan(text) {
  const input = String(text || '');
  const matches = Object.entries(CLASSES).filter(([, regex]) => regex.test(input)).map(([detail_class]) => detail_class);
  return { decision: matches.length ? 'block' : 'pass', escalate: matches.length > 0, classes: matches, reason: matches.length ? 'Operationalisierbare Detailklasse erkannt; menschliche Biosecurity-Prüfung erforderlich.' : 'Keine definierte Detailklasse erkannt.' };
}
if (require.main === module) process.stdin.setEncoding('utf8').on('data', (d) => process.stdout.write(JSON.stringify(scan(d))));
module.exports = { scan };
