#!/usr/bin/env node
'use strict';

// Passive local CSV analysis demo. No Core imports, network collection or control actions.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { analyze, validatePolicy } = require('./anomaly-detector');
const { assertLoopbackHost } = require('../scripts/network-policy');
const ROOT = path.resolve(__dirname, '..');
const STORE = path.resolve(process.env.APOPHIS_ANOMALY_DATA_DIR || path.join(ROOT, 'anomaly-demo', 'data'));
const WEB = path.join(ROOT, 'anomaly-demo', 'public');
const HOST = process.env.APOPHIS_ANOMALY_HOST || '127.0.0.1';
const PORT = Number(process.env.APOPHIS_ANOMALY_PORT || 3020);
const MAX_BODY = 4 * 1024 * 1024;
try { assertLoopbackHost(HOST, 'anomaly_demo'); } catch (error) { console.error(error.message); process.exit(1); }

function readJson(file, fallback) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (error) { if (error.code === 'ENOENT') return fallback; throw new Error('anomaly_store_invalid'); } }
function writeJson(file, value) { fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 }); const temp = `${file}.tmp-${process.pid}`; fs.writeFileSync(temp, JSON.stringify(value, null, 2) + '\n', { flag: 'wx', mode: 0o600 }); fs.renameSync(temp, file); }
function send(res, status, body, type = 'application/json; charset=utf-8') { res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'" }); res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body)); }
function bodyJson(req) { return new Promise((resolve, reject) => { let size = 0; const chunks = []; req.on('data', (chunk) => { size += chunk.length; if (size > MAX_BODY) { reject(new Error('body_too_large')); req.destroy(); } else chunks.push(chunk); }); req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch (_) { reject(new Error('invalid_json')); } }); req.on('error', reject); }); }
function normalizeSeries(raw) {
  if (!Array.isArray(raw) || raw.length < 12 || raw.length > 20000) throw new Error('series_point_count_out_of_range');
  return raw.map((point) => {
    const timestamp = new Date(point.timestamp);
    const value = Number(point.value);
    if (!Number.isFinite(timestamp.getTime()) || !Number.isFinite(value)) throw new Error('series_point_invalid');
    return { timestamp: timestamp.toISOString(), value };
  }).sort((a, b) => Date.parse(a.timestamp) - Date.parse(b.timestamp));
}
function seriesFile(id) { if (!/^[a-z0-9][a-z0-9._-]{1,63}$/.test(id)) throw new Error('series_id_invalid'); return path.join(STORE, `series-${id}.json`); }
function getPolicy() { return validatePolicy(readJson(path.join(STORE, 'policy.json'), { window_size: 48, min_history: 12, mad_multiplier: 4, absolute_tolerance: 0, relative_tolerance_percent: 15, min_consecutive: 2 })); }
function collectSeries() { return fs.readdirSync(STORE).filter((name) => /^series-[a-z0-9][a-z0-9._-]{1,63}\.json$/.test(name)).map((name) => readJson(path.join(STORE, name), null)).filter(Boolean); }
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url || '/', 'http://localhost');
  try {
    if (req.method === 'GET' && url.pathname === '/health') return send(res, 200, { ok: true, service: 'apophis-anomaly-demo', core_access: false, mode: 'passive-local-csv' });
    if (req.method === 'GET' && url.pathname === '/api/policy') return send(res, 200, { policy: getPolicy(), data_scope: 'local-only' });
    if (req.method === 'PUT' && url.pathname === '/api/policy') { const body = await bodyJson(req); const policy = validatePolicy(body); writeJson(path.join(STORE, 'policy.json'), { schema: 'apophis/anomaly-policy/v1', ...policy }); return send(res, 200, { saved: true, policy }); }
    if (req.method === 'GET' && url.pathname === '/api/series') return send(res, 200, { series: collectSeries().map(({ points, ...meta }) => ({ ...meta, points_count: points.length, analysis: analyze({ points }, getPolicy()) })) });
    if (req.method === 'POST' && url.pathname === '/api/series') {
      const body = await bodyJson(req);
      const points = normalizeSeries(body.points);
      const seriesId = String(body.series_id || '').toLowerCase();
      const source = String(body.source || '').slice(0, 120);
      const sourceUrl = String(body.source_url || '').slice(0, 500);
      const metric = String(body.metric || '').slice(0, 100);
      const unit = String(body.unit || '').slice(0, 40);
      if (!source || !metric || !unit) throw new Error('series_metadata_required');
      const rawHash = /^[a-f0-9]{64}$/i.test(body.original_file_sha256 || '') ? body.original_file_sha256.toLowerCase() : null;
      const series = { schema: 'apophis/anomaly-series/v1', series_id: seriesId, metric, unit, source, source_url: sourceUrl, source_file_sha256: rawHash, imported_at: new Date().toISOString(), provenance_note: 'Source label is supplied by the importer and is not independently verified.', points };
      seriesFile(seriesId);
      writeJson(seriesFile(seriesId), series);
      return send(res, 201, { imported: true, series_id: seriesId, points_count: points.length, source_file_sha256: rawHash, analysis: analyze(series, getPolicy()), classification: 'review_signal_only_not_attack_verdict' });
    }
    const deleteMatch = url.pathname.match(/^\/api\/series\/([a-z0-9][a-z0-9._-]{1,63})$/);
    if (req.method === 'DELETE' && deleteMatch) { const file = seriesFile(deleteMatch[1]); if (fs.existsSync(file)) fs.unlinkSync(file); return send(res, 200, { deleted: true, series_id: deleteMatch[1] }); }
    if (req.method === 'GET' && url.pathname === '/') return send(res, 200, fs.readFileSync(path.join(WEB, 'index.html')), 'text/html; charset=utf-8');
    if (req.method === 'GET' && url.pathname === '/app.js') return send(res, 200, fs.readFileSync(path.join(WEB, 'app.js')), 'text/javascript; charset=utf-8');
    return send(res, 404, { error: 'not_found' });
  } catch (error) { return send(res, error.message === 'anomaly_store_invalid' ? 500 : 400, { error: error.message || 'anomaly_request_failed' }); }
});
server.listen(PORT, HOST, () => console.log(`anomaly_demo_listening http://${HOST}:${PORT} core_access=none`));
