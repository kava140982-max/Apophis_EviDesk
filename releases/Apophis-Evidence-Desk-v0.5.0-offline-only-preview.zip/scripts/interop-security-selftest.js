#!/usr/bin/env node
'use strict';
const assert = require('node:assert/strict');
const { isBlockedIp, validateExternalUrl, fetchPinned, resolvePinnedAddress } = require('./interop-core');
assert.equal(isBlockedIp('127.0.0.1'), true);
assert.equal(isBlockedIp('10.0.0.1'), true);
assert.equal(isBlockedIp('169.254.169.254'), true);
assert.equal(isBlockedIp('::1'), true);
assert.equal(isBlockedIp('8.8.8.8'), false);
assert.throws(() => validateExternalUrl('http://example.org'), /source_not_allowlisted/);
assert.throws(() => validateExternalUrl('https://127.0.0.1'), /source_not_allowlisted/);
assert.throws(() => validateExternalUrl('https://allowed.example.org/path', new Set(['other.example.org'])), /source_not_allowlisted/);
assert.doesNotThrow(() => validateExternalUrl('https://allowed.example.org/path', new Set(['allowed.example.org'])));
(async () => {
  await assert.rejects(fetchPinned('https://allowed.example.org/path'), (error) => error.code === 'EXTERNAL_NETWORK_DISABLED');
  await assert.rejects(resolvePinnedAddress('https://allowed.example.org/path'), (error) => error.code === 'EXTERNAL_NETWORK_DISABLED');
  console.log(JSON.stringify({ verdict: 'PASS', external_dns: 'hard-denied', external_http: 'hard-denied', policy: 'offline-only' }, null, 2));
})().catch((error) => { console.error(error); process.exitCode = 1; });
