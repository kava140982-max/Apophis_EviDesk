#!/usr/bin/env node
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const net = require('node:net');
const { spawn, spawnSync } = require('node:child_process');
const { assertLoopbackHost, denyExternalNetwork, POLICY } = require('./network-policy');

const ROOT = path.join(__dirname, '..');
function freePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const port = server.address().port;
      server.close((error) => error ? reject(error) : resolve(port));
    });
  });
}
async function waitFor(base, child) {
  const deadline = Date.now() + 8000;
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw new Error(`server_exited_early:${child.exitCode}`);
    try { if ((await fetch(`${base}/api/capabilities`)).ok) return; } catch (_) {}
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  throw new Error('server_start_timeout');
}
function runEnabledModule(script, envName, config) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'apophis-offline-'));
  const configPath = path.join(dir, 'config.json');
  fs.writeFileSync(configPath, JSON.stringify(config));
  const child = spawnSync(process.execPath, [path.join(ROOT, script)], {
    env: { ...process.env, [envName]: configPath }, encoding: 'utf8', timeout: 5000
  });
  fs.rmSync(dir, { recursive: true, force: true });
  assert.equal(child.status, 1, `${script} enabled mode must fail closed`);
  assert.match(child.stderr, /external_network_disabled/);
  return true;
}

async function main() {
  assert.deepEqual(POLICY, { mode: 'offline-only', external_network: 'deny', remote_bind: 'deny', local_loopback_ui: 'allow' });
  assert.equal(assertLoopbackHost('127.0.0.1'), true);
  assert.throws(() => assertLoopbackHost('localhost'), /remote_bind_disabled/);
  assert.throws(() => assertLoopbackHost('0.0.0.0'), /remote_bind_disabled/);
  assert.throws(() => denyExternalNetwork('test'), (error) => error.code === 'EXTERNAL_NETWORK_DISABLED');

  const server = spawnSync(process.execPath, [path.join(ROOT, 'server.js')], {
    env: { ...process.env, HOST: '0.0.0.0', PORT: '0' }, encoding: 'utf8', timeout: 3000
  });
  assert.equal(server.status, 1);
  assert.match(server.stderr, /remote_bind_disabled/);
  for (const script of ['scripts/warning-radar-service.js', 'scripts/anomaly-demo-service.js']) {
    const hostKey = script.includes('warning-radar') ? 'APOPHIS_WARNING_HOST' : 'APOPHIS_ANOMALY_HOST';
    const portKey = script.includes('warning-radar') ? 'APOPHIS_WARNING_PORT' : 'APOPHIS_ANOMALY_PORT';
    const remote = spawnSync(process.execPath, [path.join(ROOT, script)], {
      env: { ...process.env, [hostKey]: '0.0.0.0', [portKey]: '0' }, encoding: 'utf8', timeout: 3000
    });
    assert.equal(remote.status, 1, `${script} must refuse a non-loopback bind`);
    assert.match(remote.stderr, /remote_bind_disabled/);
  }

  runEnabledModule('scripts/news-watch.js', 'APOPHIS_NEWS_CONFIG', { schema: 'apophis/news-sources/v1', enabled: true, allowed_hosts: ['feeds.example.org'], sources: [] });
  runEnabledModule('scripts/research-radar.js', 'APOPHIS_RESEARCH_CONFIG', {
    schema: 'apophis/research-radar-config/v1', enabled: true,
    queries: [{ id: 'test-query', label: 'Synthetic test', query: 'synthetic test query', enabled: true }]
  });

  const port = await freePort();
  const base = `http://127.0.0.1:${port}`;
  const app = spawn(process.execPath, [path.join(ROOT, 'server.js')], {
    env: { ...process.env, HOST: '127.0.0.1', PORT: String(port) }, stdio: 'ignore'
  });
  try {
    await waitFor(base, app);
    const blocked = await fetch(`${base}/api/references/check`, { method: 'POST' });
    assert.equal(blocked.status, 403);
    assert.deepEqual(await blocked.json(), { error: 'external_network_disabled', policy: 'offline-only' });
  } finally {
    if (app.exitCode === null) app.kill('SIGTERM');
    await new Promise((resolve) => {
      if (app.exitCode !== null) return resolve();
      const timer = setTimeout(() => { app.kill('SIGKILL'); resolve(); }, 2000);
      app.once('exit', () => { clearTimeout(timer); resolve(); });
    });
  }

  for (const rel of ['server.js', 'scripts/interop-core.js', 'scripts/news-watch.js', 'scripts/research-radar.js', 'scripts/warning-radar-service.js', 'scripts/anomaly-demo-service.js']) {
    const text = fs.readFileSync(path.join(ROOT, rel), 'utf8');
    assert.doesNotMatch(text, /\bfetch\s*\(/, `${rel} must not contain an outbound fetch`);
    assert.doesNotMatch(text, /https\.request\s*\(/, `${rel} must not contain an outbound HTTPS client`);
  }
  for (const rel of ['public/index.html', 'warning-radar/public/index.html', 'anomaly-demo/public/index.html']) {
    const html = fs.readFileSync(path.join(ROOT, rel), 'utf8');
    assert.doesNotMatch(html, /href\s*=\s*["']https?:\/\//i, `${rel} must not expose an active external link`);
  }
  for (const rel of ['deploy/apophis-offline.service', 'deploy/apophis-warning-offline.service', 'deploy/apophis-anomaly-offline.service']) {
    const service = fs.readFileSync(path.join(ROOT, rel), 'utf8');
    assert.match(service, /^IPAddressDeny=any$/m, `${rel} must deny non-loopback IP traffic`);
    assert.match(service, /^IPAddressAllow=localhost$/m, `${rel} must allow loopback`);
  }
  console.log(JSON.stringify({ verdict: 'PASS', outbound_connections: 'hard-denied', external_refresh_modules: 'fail-closed', non_loopback_binds: 'rejected', remote_reference_checks: '403', allowed_network_scope: 'loopback-only' }, null, 2));
}

main().catch((error) => { console.error(error); process.exitCode = 1; });
