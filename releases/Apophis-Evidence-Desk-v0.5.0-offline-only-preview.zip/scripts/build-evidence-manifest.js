#!/usr/bin/env node
'use strict';
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const outputDir = path.join(root, 'artifacts', 'release-evidence');
const files = [
  'artifacts/eu-controls-result.json',
  'artifacts/eu-controls-evidence.json',
  'SANDBOX-SBOM.json',
  'public/apophis-audit-pack.zip'
];

function sha256(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

function buildManifest(projectRoot = root, env = process.env) {
  const realRoot = fs.realpathSync(projectRoot);
  const entries = files.map((relative) => {
    const absolute = path.resolve(projectRoot, relative);
    if (!absolute.startsWith(`${path.resolve(projectRoot)}${path.sep}`) || !fs.realpathSync(absolute).startsWith(`${realRoot}${path.sep}`)) throw new Error(`evidence_path_outside_project:${relative}`);
    const stat = fs.statSync(absolute);
    if (!stat.isFile()) throw new Error(`evidence_not_regular_file:${relative}`);
    return { path: relative, bytes: stat.size, sha256: sha256(absolute) };
  });
  return {
    schema: 'apophis/audit-evidence-manifest/v1',
    project: 'apophis-evidence-desk',
    assessment_scope: 'local-loopback-synthetic-prototype',
    not_a_certification: true,
    commit_sha: env.GITHUB_SHA || 'local-unpinned-commit',
    workflow_run_id: env.GITHUB_RUN_ID || null,
    workflow_ref: env.GITHUB_WORKFLOW_REF || null,
    generated_at: new Date().toISOString(),
    files: entries
  };
}

if (require.main === module) {
  fs.mkdirSync(outputDir, { recursive: true });
  const manifest = buildManifest();
  const target = path.join(outputDir, 'manifest.json');
  const temp = `${target}.tmp-${process.pid}`;
  const fd = fs.openSync(temp, 'wx', 0o600);
  try { fs.writeFileSync(fd, `${JSON.stringify(manifest, null, 2)}\n`); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
  fs.renameSync(temp, target);
  console.log(JSON.stringify({ verdict: 'PASS', manifest: 'artifacts/release-evidence/manifest.json', files: manifest.files.length, hashes: manifest.files.map((entry) => ({ path: entry.path, sha256: entry.sha256 })) }, null, 2));
}

module.exports = { buildManifest, files };
