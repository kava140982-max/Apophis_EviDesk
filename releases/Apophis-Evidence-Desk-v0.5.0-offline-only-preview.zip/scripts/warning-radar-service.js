#!/usr/bin/env node
'use strict';

// Standalone warning inbox. It does not import server.js or access Core stores.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { assertLoopbackHost } = require('./network-policy');

const ROOT = path.resolve(__dirname, '..');
const STORE = path.resolve(process.env.APOPHIS_WARNING_DATA_DIR || path.join(ROOT, 'warning-radar', 'data'));
const WEB = path.join(ROOT, 'warning-radar', 'public');
const HOST = process.env.APOPHIS_WARNING_HOST || '127.0.0.1';
const PORT = Number(process.env.APOPHIS_WARNING_PORT || 3011);
const TOKEN = process.env.APOPHIS_WARNING_INGEST_TOKEN || '';
const ZERO = '0'.repeat(64);
const MAX_BODY = 128 * 1024;
try { assertLoopbackHost(HOST, 'warning_radar'); } catch (error) { console.error(error.message); process.exit(1); }

function canonical(value) {
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(',')}}`;
  return JSON.stringify(value);
}
function hash(value) { return crypto.createHash('sha256').update(canonical(value)).digest('hex'); }
function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch (error) { if (error.code === 'ENOENT') return fallback; throw new Error('warning_store_invalid'); }
}
function writeJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  const temp = `${file}.tmp-${process.pid}`;
  fs.writeFileSync(temp, JSON.stringify(value, null, 2) + '\n', { mode: 0o600, flag: 'wx' });
  fs.renameSync(temp, file);
}
function clean(value, max = 2000) {
  if (typeof value !== 'string') return '';
  return value.replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);
}
function timingSafeToken(req) {
  const expected = Buffer.from(TOKEN);
  const received = Buffer.from((req.headers.authorization || '').replace(/^Bearer\s+/i, ''));
  return expected.length >= 32 && received.length === expected.length && crypto.timingSafeEqual(expected, received);
}
function sourceConfig() {
  const config = readJson(path.join(STORE, 'sources.json'), { enabled: false, sources: [] });
  if (config.enabled !== true || !Array.isArray(config.sources)) return [];
  return config.sources.filter((source) => source?.enabled === true && typeof source.id === 'string' && typeof source.family === 'string' && typeof source.name === 'string' && typeof source.origin === 'string');
}
function readEvents() { return readJson(path.join(STORE, 'events.json'), { schema: 'apophis/warning-events/v1', events: [], chain_head: ZERO }); }
function verifyChain(store) {
  let previous = ZERO;
  for (const event of store.events || []) {
    const unsigned = { ...event }; delete unsigned.record_hash;
    if (event.previous_hash !== previous || event.record_hash !== hash(unsigned)) return false;
    previous = event.record_hash;
  }
  return previous === (store.chain_head || ZERO);
}
function appendEvent(payload, source) {
  const file = path.join(STORE, 'events.json');
  const store = readEvents();
  if (!verifyChain(store)) throw new Error('warning_event_chain_invalid');
  const sourceUrl = new URL(payload.source_url);
  if (sourceUrl.protocol !== 'https:' || sourceUrl.origin !== source.origin) throw new Error('source_url_not_allowlisted');
  const eventType = payload.event_type;
  if (!['published', 'update', 'withdrawal', 'all_clear'].includes(eventType)) throw new Error('event_type_invalid');
  const correlationId = clean(payload.correlation_id, 160);
  const title = clean(payload.title, 300);
  const summary = clean(payload.summary, 5000);
  const issuedAt = clean(payload.issued_at, 50);
  const expiresAt = clean(payload.expires_at, 50);
  if (!correlationId || !title || !summary || !Number.isFinite(Date.parse(issuedAt)) || !Number.isFinite(Date.parse(expiresAt))) throw new Error('warning_fields_invalid');
  const rawHash = crypto.createHash('sha256').update(canonical(payload)).digest('hex');
  const record = {
    event_id: `warning-${crypto.randomBytes(10).toString('hex')}`,
    correlation_id: correlationId,
    event_type: eventType,
    source_id: source.id,
    source_family: source.family,
    source_name: source.name,
    source_url: sourceUrl.toString(),
    issued_at: new Date(issuedAt).toISOString(),
    expires_at: new Date(expiresAt).toISOString(),
    title,
    summary,
    instruction: clean(payload.instruction, 3000),
    hazard_type: clean(payload.hazard_type, 100),
    severity: clean(payload.severity, 60),
    payload_sha256: rawHash,
    recorded_at: new Date().toISOString(),
    previous_hash: store.chain_head || ZERO
  };
  record.record_hash = hash(record);
  store.events.push(record); store.chain_head = record.record_hash;
  writeJson(file, store);
  return record;
}
function aggregate() {
  const store = readEvents();
  if (!verifyChain(store)) throw new Error('warning_event_chain_invalid');
  const groups = new Map();
  for (const event of store.events) {
    const group = groups.get(event.correlation_id) || new Map();
    group.set(event.source_id, event);
    groups.set(event.correlation_id, group);
  }
  const now = Date.now();
  return [...groups.entries()].map(([correlationId, bySource]) => {
    const latest = [...bySource.values()].sort((a, b) => b.recorded_at.localeCompare(a.recorded_at));
    const active = [...bySource.values()].filter((event) => !['withdrawal', 'all_clear'].includes(event.event_type) && Date.parse(event.expires_at) > now);
    const families = new Set(active.map((event) => event.source_family));
    const resolved = active.length === 0;
    return {
      correlation_id: correlationId,
      stage: resolved ? 'resolved' : families.size >= 2 ? 'source_confirmed' : 'preliminary',
      title: latest[0]?.title || '', summary: latest[0]?.summary || '', instruction: latest[0]?.instruction || '',
      updated_at: latest[0]?.recorded_at || '',
      sources: latest.map(({ source_id, source_family, source_name, source_url, issued_at, event_type, payload_sha256, expires_at }) => ({ source_id, source_family, source_name, source_url, issued_at, event_type, payload_sha256, expires_at }))
    };
  }).sort((a, b) => b.updated_at.localeCompare(a.updated_at));
}
function send(res, status, body, contentType = 'application/json; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': contentType, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'" });
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}
function bodyJson(req) { return new Promise((resolve, reject) => { let size = 0; const chunks = []; req.on('data', (chunk) => { size += chunk.length; if (size > MAX_BODY) { reject(new Error('body_too_large')); req.destroy(); } else chunks.push(chunk); }); req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch (_) { reject(new Error('invalid_json')); } }); req.on('error', reject); }); }

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url || '/', 'http://localhost');
  try {
    if (req.method === 'GET' && url.pathname === '/health') return send(res, 200, { ok: true, service: 'apophis-warning-radar', core_access: false, source_count: sourceConfig().length });
    if (req.method === 'GET' && url.pathname === '/api/warnings') return send(res, 200, { schema: 'apophis/warning-inbox/v1', warnings: aggregate(), core_integration: 'none' });
    if (req.method === 'POST' && url.pathname === '/api/intake') {
      if (!timingSafeToken(req)) return send(res, 401, { error: 'source_adapter_authentication_required' });
      const payload = await bodyJson(req);
      const source = sourceConfig().find((item) => item.id === payload.source_id);
      if (!source) return send(res, 403, { error: 'source_not_enabled' });
      const record = appendEvent(payload, source);
      return send(res, 201, { accepted: true, event_id: record.event_id, stage: aggregate().find((item) => item.correlation_id === record.correlation_id)?.stage, core_access: 'none' });
    }
    if (req.method === 'GET' && url.pathname === '/') return send(res, 200, fs.readFileSync(path.join(WEB, 'index.html')), 'text/html; charset=utf-8');
    if (req.method === 'GET' && url.pathname === '/app.js') return send(res, 200, fs.readFileSync(path.join(WEB, 'app.js')), 'text/javascript; charset=utf-8');
    return send(res, 404, { error: 'not_found' });
  } catch (error) {
    return send(res, error.message === 'warning_event_chain_invalid' || error.message === 'warning_store_invalid' ? 500 : 400, { error: error.message || 'warning_request_failed' });
  }
});
server.listen(PORT, HOST, () => console.log(`warning_radar_listening http://${HOST}:${PORT} core_access=none`));
