#!/usr/bin/env node
'use strict';
const assert = require('node:assert/strict');
const net = require('node:net');
const path = require('node:path');
const { spawn } = require('node:child_process');

function freePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      server.close((error) => error ? reject(error) : resolve(port));
    });
  });
}

async function waitForServer(baseUrl, child) {
  const deadline = Date.now() + 8000;
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw new Error(`server_exited_early:${child.exitCode}`);
    try {
      const response = await fetch(`${baseUrl}/health`);
      if (response.ok) return;
    } catch (_) { /* wait for the listener to bind */ }
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  throw new Error('server_start_timeout');
}

async function main() {
  const port = await freePort();
  const baseUrl = `http://127.0.0.1:${port}`;
  const child = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], {
    env: { ...process.env, HOST: '127.0.0.1', PORT: String(port), APOPHIS_TRUST_TENANT_HEADER: '1' },
    stdio: 'ignore'
  });
  try {
    await waitForServer(baseUrl, child);

    const protectedPaths = [
      '/api/projects', '/api/groups', '/api/access-requests', '/api/approvals',
      '/api/approvals/status', '/api/audit/verify', '/api/audit/worm/verify',
      '/api/privacy/export?actor=synthetic-author'
    ];
    for (const route of protectedPaths) {
      const response = await fetch(`${baseUrl}${route}`);
      assert.equal(response.status, 401, `${route} must fail closed without trusted tenant context`);
    }

    const otherHeaders = { 'x-apophis-tenant': 'other-tenant' };
    const otherProjectsResponse = await fetch(`${baseUrl}/api/projects`, { headers: otherHeaders });
    assert.equal(otherProjectsResponse.status, 200);
    assert.deepEqual((await otherProjectsResponse.json()).projects, []);
    const hiddenProjectResponse = await fetch(`${baseUrl}/api/projects/project-hcmv-demo-001`, { headers: otherHeaders });
    assert.equal(hiddenProjectResponse.status, 404, 'foreign project IDs must not reveal a record');
    const otherApprovals = await fetch(`${baseUrl}/api/approvals`, { headers: otherHeaders });
    assert.deepEqual((await otherApprovals.json()).records, []);

    const demoHeaders = { 'x-apophis-tenant': 'synthetic-demo' };
    const demoProjectsResponse = await fetch(`${baseUrl}/api/projects`, { headers: demoHeaders });
    assert.equal(demoProjectsResponse.status, 200);
    const demoProjects = await demoProjectsResponse.json();
    assert.equal(demoProjects.projects.length, 1);
    assert.equal(demoProjects.projects[0].tenant_id, 'synthetic-demo');
    assert.equal((await fetch(`${baseUrl}/api/projects/project-hcmv-demo-001`, { headers: demoHeaders })).status, 200);

    const wormResponse = await fetch(`${baseUrl}/api/audit/worm/verify`, { headers: demoHeaders });
    assert.equal(wormResponse.status, 200);
    const worm = await wormResponse.json();
    assert.equal(worm.storage_mode, 'append-only-content-addressed-local-prototype');
    assert.equal(worm.physical_worm_guarantee, false);

    console.log(JSON.stringify({ verdict: 'PASS', missing_tenant_rejected: protectedPaths.length, foreign_project_hidden: true, tenant_scoped_approval_list: true, demo_project_visible: true, worm_endpoint_available: true }, null, 2));
  } finally {
    if (child.exitCode === null) child.kill('SIGTERM');
    await new Promise((resolve) => {
      if (child.exitCode !== null) return resolve();
      const timer = setTimeout(() => { child.kill('SIGKILL'); resolve(); }, 2000);
      child.once('exit', () => { clearTimeout(timer); resolve(); });
    });
  }
}

main().catch((error) => { console.error(error); process.exitCode = 1; });
