# Apophis Evidence Desk — Übergabe- und Betriebsleitfaden

## Was ist das?

Apophis Evidence Desk ist ein lokaler Due-Diligence- und Evidence-Arbeitsplatz für Forschungsvorhaben mit erhöhtem Sicherheits-, Ethik- oder Regulatory-Bedarf. Das System ordnet öffentliche Referenzen, Claims, Gegenclaims, Unsicherheiten, Prüfrollen und Freigabestufen. Es soll nachvollziehbar machen, was beobachtet wurde, wie es bewertet wurde und welche Entscheidung überhaupt zulässig ist.

Die zentrale Grenze lautet: `Observation != Assessment != Decision`. Ein Quellenbezug ist kein Beweis für einen konkreten Kandidaten. Ein Assessment ist keine Freigabe. Ein Approval-Record ist kein Nachweis der Identität oder fachlichen Qualifikation einer realen Person.

## Wie wird es eingesetzt?

1. Das Projekt lokal entpacken und Node.js 20 oder neuer verwenden.
2. Mit `npm run check` Syntax prüfen.
3. Mit `npm run build:bundle` das signierte Evidence Bundle bauen. Beim ersten Lauf entsteht die lokale Ed25519-Identität; der private Schlüssel liegt unter `data/keys/` und muss geschützt werden.
4. Mit `npm run verify` Bundle, Signatur, Identitäts-Fingerprint und Approval-Chain offline prüfen.
5. Mit `npm run smoke` den lokalen Server- und Healthcheck ausführen.
6. Mit `npm start` den Desk auf `http://127.0.0.1:3000` starten.
7. Claims und Gegenclaims fachlich prüfen. Die Approval-Route akzeptiert keine unbekannten Rollen oder Entscheidungen. Ein wirksames Gate erfordert mindestens zwei verschiedene Actors und die getrennten Rollen `author`, `reviewer` und `biosecurity`.
8. Mit `npm run export:pack` einen Audit-Pack-Export erstellen. Der Export ist für Übergabe, Review und Archivierung gedacht, nicht für eine automatische Zulassungs- oder Laborentscheidung.

Der Link-Rot-Check ist ein expliziter Netzwerkpfad über `POST /api/references/check`. Er ist nicht als Hintergrunddienst aktiviert. News- oder RSS-Feeds sollten nur mit Allowlist, Abrufzeit, Roh-Hash und menschlicher Triage ergänzt werden. Kein News-Eintrag darf automatisch einen Claim-Status erhöhen.

## Was ist tatsächlich geschützt?

Das Bundle besitzt einen SHA-256-Receipt und eine Ed25519-Signatur. Die Approval-Chain ist hashverkettet und an den jeweils aktuellen Bundle-Hash gebunden. Der Offline-Verifier kann diese Eigenschaften ohne Server prüfen. Der deterministische Biosecurity-Scanner blockiert definierte Sequenz-, Protokoll- und Dosierungsdetailklassen zur menschlichen Prüfung.

Diese Mechanismen schützen gegen versehentliche oder nachträgliche Konsistenzfehler in den gespeicherten Artefakten. Sie beweisen nicht, dass die Person hinter einem Actor-Namen echt ist, dass ein Schlüssel organisatorisch verwahrt wird oder dass die zugrunde liegende wissenschaftliche Aussage richtig ist.

## Harte Grenzen

Apophis ist kein Labor, kein klinisches Entwicklungssystem, kein Regulatory-Informationssystem, keine Rechtsberatung und kein DURC-Freigabesystem. Es behauptet nicht, dass ein Kandidat sicher, wirksam, herstellbar oder zulassungsfähig ist. Diese Fragen müssen an Labor, Ethik, Regulatory und zuständige Biosecurity-Fachstellen übergeben werden.

## Übergabe-Checkliste

Vor einer externen Übergabe sollten der Scope des Runs, der Bundle-Hash, die verwendete Identität, alle offenen Claims, die Gegenclaims, die Rollen der Prüfer, die nicht ausgeführten Prüfungen und die Grenzen des Exports gemeinsam gelesen werden. Der private Schlüssel gehört nicht in einen öffentlichen Download oder in ein ungeschütztes gemeinsames Laufwerk.

---

**KaVa-14.10.26**
