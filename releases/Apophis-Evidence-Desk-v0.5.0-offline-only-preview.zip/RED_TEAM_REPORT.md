# Operation Black Ice — Red-Team-Nachtrag

## Scope

Geprüft wurde ausschließlich die lokale Projektkopie `/home/ubuntu/work/apophis-v03/project` mit Bundle-Schema v5 und Paketversion 0.3.0. Der Ausgangsbestand im Upload-Archiv wurde nicht verändert. Tests wurden mit synthetischen Daten und temporären Kopien ausgeführt.

## Komponentenmatrix

| Komponente | Vorhanden | Ausführbar | Nachweis |
|---|---:|---:|---|
| Frontend | Ja | Ja | `public/index.html`, `public/app.js`, Smoke-Test |
| API/Backend | Ja | Ja | `server.js`, `/health`, `/api/*` |
| Authentifizierung | Nein | Nicht anwendbar | localhost-only, kein Login |
| Autorisierung | Teilweise | Ja | serverseitige Rollen- und Gate-Prüfung; Organisationsidentität fehlt |
| Datenbank | Nein | Nicht anwendbar | JSON-Dateien, lokaler Speicher |
| Mandantentrennung | Nein | Nicht anwendbar | Single-workspace-Demo, keine Mandantenarchitektur |
| Audit-Log | Ja | Ja | append-only Hashkette in `data/approvals.json` |
| Release-/Offline-Verifier | Ja | Ja | `scripts/verify.js` |
| Freigabegates | Ja | Ja | 2-Augen-Regel, Rollen, Bundle-Hash-Bindung |
| Tests | Ja | Ja | `npm run check`, `npm run verify`, `npm run smoke`, Negativtests |

## Befunde und Maßnahmen

### Geschlossen: veraltete Approval-Chain konnte semantisch weiterwirken

Vor der Korrektur prüfte die Chain ihre Hashintegrität, aber nicht, ob jeder Record zum aktuell geprüften Bundle gehörte. Dadurch konnte eine intakte Chain für einen alten Bundle-Hash sichtbar bleiben. Server und Offline-Verifier prüfen jetzt `record.bundle_hash === current bundle_hash`; ein Bundle-Wechsel macht alte Approvals ungültig.

### Geschlossen: unbekannte Approval-Zustände waren nicht fail-closed

Die Append-Route akzeptierte nur bekannte Werte, aber die reine Chain-Verifikation validierte die Record-Form nicht ausreichend. Server und Offline-Verifier validieren jetzt Rolle, Entscheidung, Scope, Pflichtfelder, Vorgängerhash, Recordhash und Bundle-Bindung.

### Bestätigt: keine echte Authentifizierung oder Organisationsidentität

Actor-Namen sind weiterhin selbst deklariert. Das ist kein Identitätsnachweis. Die Implementierung behauptet deshalb keine Organisationsfreigabe. Für Betrieb mit externem Vertrauen fehlen Login, Rollenverwaltung, geschützter Key-Store/HSM und unabhängige Identitätsprovider.

### Bestätigt: keine Mandantenisolation

Das Projekt ist ein lokaler Single-workspace-Demonstrator. Es gibt keine Tenant-ID, keine Datenbank und keinen Anspruch auf Multi-Tenant-Sicherheit. Mandantentests sind daher `NOT_APPLICABLE`, nicht bestanden.

### Bestätigt: Linkcheck ist ein expliziter Netzwerkpfad

`POST /api/references/check` ist manuell, zeitbegrenzt und wertet Links nicht automatisch als Evidenz auf. Für Hochsicherheitsbetrieb sollte dieser Pfad außerhalb des Default-Betriebs deaktiviert oder über eine feste Allowlist und einen separaten Egress-Proxy geführt werden.

## Reproduzierbare Verifikation

```text
npm run check       PASS
npm run verify      valid: true
npm run smoke       SMOKE_OK
Biosecurity benign  decision=pass
Biosecurity detail  decision=block, classes=sequence/protocol/dosing
Approval ohne Rolle HTTP 400 invalid_approval
```

## Verdict

`PARTIALLY-VERIFIED` für den lokalen Single-workspace-Scope: Integrität, Signatur, Approval-Chain und definierte Biosecurity-Grenzen sind reproduzierbar geprüft. `NOT_APPLICABLE` für Authentifizierung, echte Organisationsautorisierung und Mandantenisolation. Keine Aussage über Sicherheits-, Wirksamkeits-, Herstellbarkeits-, Zulassungs- oder DURC-Reife.

---

**KaVa-14.10.26**
