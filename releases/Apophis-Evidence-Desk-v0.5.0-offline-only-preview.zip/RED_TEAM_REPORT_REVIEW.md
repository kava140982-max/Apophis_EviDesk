# Red-Team-Folgeprüfung — 20.10.2026

## Umfang

Geprüft wurde die schlüsselfreie Review-Kopie 0.3.1-review mit synthetischen Approval-Records und lokalen Tests. Das historische `RED_TEAM_REPORT.md` bleibt ein separater Bericht über den früheren Stand. Keine externen Repositorys oder Netzwerkdienste wurden aufgerufen.

## Reproduzierte Befunde im eingegangenen Stand

Ein synthetischer Lauf mit drei Approvals (Author, Reviewer, Biosecurity) und anschließendem `reject` für dasselbe Bundle ergab in der Eingangskopie weiterhin `ready: true`; ein `escalate` blockierte ebenfalls nicht. Außerdem wurde beschädigtes Approval-JSON durch einen generischen Fallback als leeres Log behandelt. Ein unauthentifiziertes `HOST`-Override konnte den Server an eine Nicht-Loopback-Adresse binden.

Das hochgeladene Gesamt-ZIP enthielt den privaten Ed25519-Schlüssel, der zum öffentlichen Schlüssel und aktiven Fingerprint des Demo-Bundles passt. Der separate Audit-Pack enthielt keinen privaten Schlüssel. Das Gesamt-ZIP ist nicht zur öffentlichen Weitergabe geeignet.

## Korrekturen in dieser Review-Kopie

`reject` und `escalate` sind jetzt sichtbare Blocker des `ready`-Gates. Nicht parsebares gespeichertes JSON führt zu einem Fehler und wird beim Append nicht überschrieben. Der Server verweigert nicht-lokale Bind-Adressen ohne Authentifizierung. Die Review-Kopie enthält keinen privaten Schlüssel; das vorhandene Bundle ist weiterhin offline verifizierbar.

## News-Inbox — Befund, Korrektur und Restgrenze

Im Ausgangsstand genügte HTTPS; Host-Allowlist und Bodylimit fehlten und Fetch folgte Redirects. Die Review-Kopie verlangt jetzt exakte Hosts aus einer expliziten Allowlist, verbietet IP-/lokale Hostnamen und nichtstandardmäßige Ports, fordert Redirects manuell an und weist 3xx zurück. Content-Type, Bodylimit (256 KiB), Timeout (10 s), maximal 10 Quellen und 20 Items pro Quelle sind begrenzt; Inbox-Dateien werden atomar geschrieben. Offline-Negativtests prüfen nicht erlaubte URLs und übergroße Bodies.

Der Refresh bleibt deaktiviert und wurde nicht live ausgeführt. DNS-Auflösung wird nicht an geprüfte IPs gepinnt und es gibt keine institutionelle Egress-Firewall; daher ist dies eine lokale Härtung, keine Produktionsfreigabe für beliebige Netzwerke.

## Nachweis und Grenze

`npm test` bestanden. Die Governance-Regression prüft vollständige Approvals, Reject, Escalate, beschädigtes Approval-JSON und den Remote-Bind-Guard. Diese Tests belegen nur den lokalen Single-Workspace-Scope. Login, Organisationsidentität, Mehrmandantenisolation, Key-Store/HSM und produktive Repository-Adapter bleiben offen. Kein Sicherheits-, wissenschaftliches, regulatorisches oder Biosecurity-Freigabeurteil.

---

**KaVa-14.10.26**
