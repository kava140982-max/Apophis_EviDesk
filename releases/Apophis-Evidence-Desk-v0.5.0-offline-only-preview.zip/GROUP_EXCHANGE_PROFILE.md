# Group Exchange Profile v1

Der SocialHub-Vorschlag liefert ein gutes Interaktionsmuster: Gruppen bündeln Teilnehmer und Nachrichten. Für Apophis wird daraus kein öffentlicher Social Feed, sondern ein privater, strukturierter Projektkanal.

## Ablauf zwischen zwei Systemen

1. System A ruft `POST /api/federation/challenge` auf und erhält eine kurzlebige, einmalige Challenge.
2. System B stellt sich mit `community_id`, `system_id`, Origin, Capability-Profil und Ed25519-Public-Key vor und signiert exakt diese Challenge.
3. System A prüft Signatur, Ablaufzeit, Audience und Replay-Schutz. Das Ergebnis ist `identified`, nicht `trusted`.
4. Erst danach kann ein Gruppenkanal mit `POST /api/groups/:groupId/exchanges` genutzt werden. Jede Nachricht enthält `peer_id`, `handshake_id`, einen Typ und einen begrenzten Payload.
5. Eingehende Daten werden als `received-needs-review` gespeichert. Kein Gruppenmitglied, kein Repository-Status und keine Signatur öffnet automatisch ein Apophis-Gate.

## Warum dieser Zuschnitt sinnvoll ist

Die Systeme kommunizieren tatsächlich, um ihre Identität und Fähigkeiten abzugleichen. Trotzdem wird Gemeinschaft nicht mit blindem Vertrauen verwechselt. Für den produktiven Betrieb müssen Organisationsschlüssel, Zertifikats-/DID-Bindings, Mitgliederverwaltung, Rate Limits, Authentifizierung, Replay-Speicher, Verschlüsselung und eine explizite Trust List ergänzt werden.

Das Profil ist bewusst kompatibel mit der vorherigen Discovery-Schicht. ActivityPub-/Matrix-Anbindungen können später dieselbe Handshake- und Review-Grenze verwenden; ein externer Feed oder eine Gruppenchat-Nachricht darf niemals direkt Claim-Status oder Approval-Status ändern.
