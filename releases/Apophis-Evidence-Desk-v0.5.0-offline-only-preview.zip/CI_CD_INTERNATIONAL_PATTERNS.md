# Internationale CI/CD-Muster und Apophis-Umsetzung

**Stand:** 20. Oktober 2026  
**Scope:** technische Pipeline- und Lieferkettenhärtung, keine Sicherheitszertifizierung.

## Beobachtete Muster

GitHub empfiehlt minimale `GITHUB_TOKEN`-Berechtigungen, das Pinnen von Actions auf vollständige Commit-SHAs, vorsichtigen Umgang mit untrusted Pull Requests und OIDC statt langlebiger Cloud-Secrets. [1] GitHub exportiert SBOMs im SPDX-Format und unterstützt SBOM-Erzeugung als Workflow-Artefakt. [2]

OpenSSF Scorecard liefert automatisierte Supply-Chain-Prüfungen und SARIF-Ausgaben für GitHub Code Scanning. Die offizielle Action verlangt bei veröffentlichten Ergebnissen besondere Berechtigungen und empfiehlt ebenfalls vollständig gepinnte Action-Referenzen. [3]

GitLab verbindet CycloneDX-SBOMs mit Dependency Scanning, transitive Abhängigkeiten, Merge-Request-Findings und kontinuierlicher Schwachstellenüberwachung. [4] Snyk bietet CI/CD-Scans für Node.js und kann Ergebnisse als SARIF an GitHub Code Scanning übergeben. [5] CycloneDX führt darüber hinaus Open-Source- und kommerzielle Werkzeuge für SBOM-Validierung, Supply-Chain-Analyse, Signierung und CRA-/Release-Evidenz. [6]

## Was Apophis davon übernimmt

1. Ein verpflichtendes, vendor-neutrales Quality-Gate läuft in `.github/workflows/quality.yml`.
2. `npm test` bleibt der zentrale fail-closed Testvertrag.
3. `test:eu-controls` erzeugt SHA-256-Evidenzreports für jede referenzierte Datei.
4. CI-Artefakte enthalten Testlog, EU-Control-Report, Evidenz-Hashreport, Audit-Pack und SBOM.
5. `.github/workflows/scorecard.yml` führt einen getrennten OpenSSF-Scan aus.
6. `test:ci-workflow` blockiert nicht gepinnte Actions und privilegierte `pull_request_target`-Trigger.
7. Alle externen Actions in den mitgelieferten Workflows sind auf vollständige Commit-SHAs gepinnt.
8. `.github/workflows/release-evidence.yml` erzeugt für `main`-Läufe keyless Sigstore/Cosign-Bundles und verifiziert sie gegen die konkrete GitHub-Workflow-Identität.
9. `artifacts/release-evidence/manifest.json` bindet Commit, Workflow-Lauf, Dateigrößen und SHA-256-Hashes in ein prüfbares Release-Evidence-Manifest.

## Bewusste Grenzen

Snyk, GitLab Ultimate, GitHub Advanced Security, OPA, SLSA-Provenance und externe SBOM-Datenbanken sind nicht als harte Voraussetzung eingebaut. Cosign ist für den privilegierten `main`-Release-Workflow vorgesehen, nicht für Pull Requests. Der lokale Kern bleibt ohne Drittanbieter-NPM-Pakete, langlebige Secrets und private Signierschlüssel ausführbar.

Die CI-Pipeline beweist reproduzierbare technische Prüfungen und dokumentierte Evidenz. Sie beweist keine DSGVO-, AI-Act-, NIS2-, CRA-, eIDAS- oder EHDS-Konformität.

## References

[1]: https://docs.github.com/en/actions/security-for-github-actions/security-guides/security-hardening-for-github-actions "GitHub Actions security hardening"
[2]: https://docs.github.com/en/code-security/supply-chain-security/understanding-your-software-supply-chain/exporting-a-software-bill-of-materials-for-your-repository "GitHub software bill of materials"
[3]: https://github.com/ossf/scorecard-action "OpenSSF Scorecard GitHub Action"
[4]: https://docs.gitlab.com/user/application_security/dependency_scanning/dependency_scanning_sbom/ "GitLab dependency scanning using SBOM"
[5]: https://docs.snyk.io/developer-tools/integrations/snyk-ci-cd-integrations/github-actions-for-snyk-setup-and-checking-for-vulnerabilities "Snyk GitHub Actions"
[6]: https://cyclonedx.org/tool-center/ "CycloneDX Tool Center"
[7]: https://docs.sigstore.dev/quickstart/quickstart-ci/ "Sigstore CI Quickstart"
[8]: https://slsa.dev/spec/v1.0/levels "SLSA build security levels"
