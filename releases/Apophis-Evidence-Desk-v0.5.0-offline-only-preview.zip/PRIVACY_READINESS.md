# Datenschutz-Readiness — Apophis Evidence Desk

**Status:** nicht als DSGVO-konform freigegeben; nur lokaler synthetischer Prototyp.  
**Wasserzeichen:** KaVa-14.10.26

## Aktueller Zustand

Die Review-Kopie ist standardmäßig auf Loopback beschränkt und enthält keine Anmeldung, Telemetrie oder Drittanbieter-Pakete. Die enthaltenen Demodaten sind synthetisch. Projekte sind standardmäßig privat, externe Synchronisation ist opt-in. Discovery- und Capability-Endpunkte identifizieren eine Gemeinschaft, erteilen aber keine automatische Vertrauens- oder Freigabeaussage. Der News-Refresh und der Referenz-Linkcheck verlangen nun exakte HTTPS-Hosts aus einer Allowlist; der Linkcheck nutzt zusätzlich DNS-Auflösung mit adressgebundener Verbindung, blockiert private Ziele und folgt keinen Redirects. Das ist weiterhin kein vollständiger Produktions-Egress-Schutz.

Bei realer Nutzung können Approval-Actor-IDs, Rollen, Begründungen, Claim-Inhalte, Quell-URLs und Zeitstempel personenbezogen oder vertraulich sein. Lokale Speicherung allein beseitigt diese Einordnung nicht. Die Anwendung enthält jetzt ein konfigurierbares Privacy-Profil sowie lokale actor-scoped Export- und Löschpfade. Diese sind technische Readiness-Bausteine: Authentifizierung, Rollenprüfung, Rechtsgrundlage, Berichtigung, Einschränkung, Fristenläufe, Backup-Löschung, Mandantentrennung und dokumentierte Datenschutzprozesse sind für den Echtbetrieb weiterhin offen.

## Erforderliche Freigaben vor realen personenbezogenen Daten

1. Verantwortliche Stelle, Zweck, betroffene Personen, Datenkategorien und Empfänger festlegen; Rechtsgrundlage und Transparenzinformationen von Datenschutzverantwortlichen prüfen lassen.
2. Datenfluss- und Speicherinventar erstellen, einschließlich Backups, Logs, Exporte, Repository-Adapter und möglicher Feed-Abrufe. Datenminimierung und Pseudonymisierung verbindlich machen.
3. Löschfristen, Auskunft/Berichtigung/Löschung/Widerspruch, Export, Sperrung und sichere Backup-Rotation implementieren und testen.
4. Rollen-/Rechtekonzept, Authentifizierung, Organisationszuordnung, Mandantentrennung, sichere Schlüsselverwaltung, Audit-Zugriff und Incident-Prozess vor einem Mehrbenutzerbetrieb einführen.
5. Hostingstandort, Auftragsverarbeitung, Unterauftragsverarbeiter, Drittlandtransfers und Aufbewahrungs-/Backup-Standorte prüfen. Datenschutz-Folgenabschätzung zumindest systematisch auf Erforderlichkeit bewerten.
6. Datenschutz- und Sicherheitsprüfung durch zuständige Stellen sowie unabhängige technische Prüfung vor Pilotfreigabe dokumentieren.

## Sperrkriterien

Keine realen Nutzerkonten, sensiblen Forschungsdaten, klinischen Daten oder institutionellen Freigaben in dieser Review-Instanz verwenden. Keine öffentliche Serverbindung oder Mehrmandanten-Nutzung. Keine DSGVO-Konformitätsbehauptung, bevor Verantwortliche, Rechtsgrundlage, Datenfluss, Schutzmaßnahmen und Betriebsprozesse tatsächlich festgelegt und geprüft sind.

Diese Notiz ist ein technischer Readiness-Hinweis und keine Rechtsberatung oder formelle Datenschutzbewertung.
