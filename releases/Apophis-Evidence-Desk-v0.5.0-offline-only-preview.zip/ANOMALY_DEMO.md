# Lokales Anomalie-Demo: reale Zeitreihen, Prüfhinweise und individuelle Anpassung

## Was das Demo macht

Das Demo ist ein eigenständiger, loopback-gebundener Prozess mit eigener Oberfläche, API und Datenablage. Es importiert CSV-Dateien erst nach einer bewussten lokalen Aktion, berechnet eine historische Baseline und zeigt anhaltende statistische Abweichungen als **Prüfhinweis**. Es sendet keine Daten ins Internet, liest keine Core-Daten, verändert keine Anlage und verbindet sich nicht automatisch mit SIEM, SCADA, Zählern oder dem separaten Warnmeldungsdienst.

## Reale Daten ausprobieren

### Öffentliche Strommarktdaten

1. Öffne [SMARD – Daten herunterladen](https://www.smard.de/home/downloadcenter).
2. Wähle eine öffentliche Zeitreihe, zum Beispiel „Stromverbrauch / Realisierter Stromverbrauch / Netzlast“ für Deutschland, sowie Zeitraum und Auflösung.
3. Lade die CSV herunter. SMARD stellt solche Marktdaten unter CC BY 4.0 bereit; bei Weitergabe oder Veröffentlichung ist „Bundesnetzagentur | SMARD.de“ zu nennen. Siehe [SMARD Datennutzung](https://www.smard.de/home/datennutzung).
4. Starte `npm run anomaly:start`, öffne `http://127.0.0.1:3020/`, wähle die CSV und ordne Zeit-, optionale Uhrzeit- und Messwertspalte zu.

SMARD bezieht Marktdaten direkt von ENTSO-E. Der veröffentlichte realisierte Verbrauch ist ein aggregierter, zeitlich gemittelter Marktwert und wird mit Verzögerung bereitgestellt. Er zeigt **nicht** die Spannung, Frequenz, den Stromverbrauch oder den Netzwerkverkehr einer einzelnen KRITIS-Anlage. Ein Ausschlag in dieser Reihe bedeutet weder lokale Störung noch Cyberangriff. Er demonstriert CSV-Import, Baseline und Toleranzverfahren an einer realen öffentlichen Zeitreihe, nicht Angriffserkennung.

### Betreibereigene Netzwerk- oder Strommessungen

Ein Betreiber kann einen freigegebenen CSV-Export aggregierter Messwerte lokal importieren. Empfohlen werden Zeitstempel, anonymisierte Messreihenkennung, Messwert, Einheit und Erfassungsqualität. Keine Paketmitschnitte, Inhalte, Zugangsdaten, personenbezogenen Kennungen, exakten Netzpläne oder Anlagen-Topologien in den Demo-Import übernehmen. Die Eignung und Datenschutzfreigabe muss der Betreiber vor Ort festlegen.

Das Demo stellt keine Verbindung zu echten Zählern, Netzwerksensoren oder industriellen Steuerungen her. Für eine spätere passive Integration ist ein gesonderter, read-only Adapter nötig, der minimale Zeitreihen liefert und die Echtzeitumgebung nicht belastet.

## Erkennungslogik im Preview

Das initiale Modell `rolling_median_mad_v1` ist ein robuster, transparenter statistischer Detektor:

- pro Messreihe nimmt er nur vergangene Werte innerhalb eines konfigurierbaren Fensters als Baseline;
- Median und mediane absolute Abweichung (MAD) begrenzen den Einfluss einzelner Ausreißer;
- absolute und relative Mindesttoleranzen sowie ein Streuungsmultiplikator bestimmen den Schwellenwert;
- eine konfigurierbare Mindestanzahl aufeinanderfolgender Ausreißer reduziert einzelne Kurzzeit-Fehlalarme;
- das Ergebnis enthält beobachteten Wert, Baseline-Median, Toleranz, Abweichungsrichtung, Zeitraum und Abweichungsstärke.

Die Implementierung bewertet nicht, ob ein Angriff stattfindet. Wartungsarbeiten, Wetter, Schichtwechsel, Saison, Marktverhalten, Messfehler, Datenlücken oder legitime Lastspitzen können ebenfalls eine Abweichung verursachen. Umgekehrt kann ein Angriff innerhalb normaler Grenzen bleiben oder Messwerte reduzieren. „Keine Abweichung erkannt“ ist kein Beweis, dass kein Vorfall vorliegt.

## Individuelle Anpassung ist zwingend

**Baseline, Modellparameter und Qualitätsgrenzen müssen für jede Institution, Anlage, Messgröße und Betriebsart eigens angepasst werden.** Es gibt keine sichere allgemeine Toleranz in Prozent. Vor einem Pilot müssen Fachexperten mindestens Folgendes festlegen:

- Welche Anlage/Komponente und welche Messgröße wird beobachtet? Welcher Messbereich und welche Einheit gelten?
- Welche Zeitauflösung, Zeitzone, Latenz, Datenlücken und Sensorfehler treten auf?
- Wie unterscheiden sich Normalbetrieb, Start/Stopp, Wartung, Schichtbetrieb, saisonale Muster und Notbetrieb?
- Wie lang muss die Baseline sein und wie breit ist das Vergleichsfenster? Für periodische Reihen kann ein einzelner gleitender Verlauf unpassend sein; Schicht- oder Wochentagsmuster benötigen getrennte Referenzgruppen.
- Welche absolute Mindestabweichung ist physikalisch oder betrieblich relevant? Welche relative Abweichung ist bei kleinen Grundwerten sinnvoll?
- Wie viele aufeinanderfolgende Werte müssen auffällig sein? Wie viel Verzögerung ist vertretbar und welche Fehlalarmrate können Fachkräfte bearbeiten?
- Welche Folgen haben falsch positive und falsch negative Hinweise? Wer prüft sie, innerhalb welcher Zeit und anhand welcher zweiten Signale?
- Wie werden Datenänderung, Sensorwechsel, Firmware-/Prozessänderung und Baseline-Drift neu geprüft?

Die im Demo voreingestellten Parameter (`Fenster 48`, `Mindesthistorie 12`, `4 × MAD`, relative Abweichung 15 %, zwei aufeinanderfolgende Punkte) sind **nur Startwerte für synthetische Demonstration**. Bei anderer Zeitauflösung bedeutet ein Fenster von 48 Punkten eine andere Dauer. Diese Werte dürfen nicht unverändert als Schwellen eines produktiven Warnsystems übernommen werden. Ein Pilot sollte zunächst passiv im Schattenbetrieb laufen; Toleranzen werden anhand gelabelter Normal- und Störfälle fachlich kalibriert und bei jeder wesentlichen Änderung neu bewertet.

## Eigene KI gegenüber Demo-Detektor

Der v0.4.5-Preview enthält bewusst noch keine trainierte KI, die einen Cyberangriff identifiziert. Der eingebaute Median/MAD-Detektor ist eine erklärbare Baseline für den Datenfluss und die lokale Prüfoberfläche. Die nächste KI-Stufe wäre ein austauschbarer lokaler Modelladapter, trainiert oder kalibriert ausschließlich mit institutionell freigegebenen und repräsentativen Betriebsdaten. Er sollte nur Signale korrelieren, Unsicherheit ausweisen und Erklärmerkmale liefern; die Entscheidung „Cybervorfall“ bleibt bei qualifizierten Verantwortlichen.

NIST empfiehlt OT-Netzwerk-Baselining, Beobachtung von Kommunikationsbeziehungen und Analyse von Anomalien als Teil der Überwachung; sein Beispiel zu Behavioral Anomaly Detection beschreibt passive Alarme, die von Betriebsfachleuten geprüft werden. Das passt zum Prüfhinweis-Modell, nicht zu automatischen Eingriffen.

Quellen:

- [SMARD Datennutzung und CC BY 4.0](https://www.smard.de/home/datennutzung)
- [SMARD Datenbasis und Netzlast-Metadaten](https://www.smard.de/home/ueber-smard)
- [NIST SP 800-82 Rev. 3, OT-Netzwerküberwachung](https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=956505)
- [NIST Behavioral Anomaly Detection in Manufacturing](https://www.nist.gov/blogs/manufacturing-innovation-blog/detecting-abnormal-cyber-behavior-cyberattack)
