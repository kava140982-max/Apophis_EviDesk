# Release-Notiz – Härtungskopie, historische Basis v0.3.1-review

Dies ist eine lokale Review-/Härtungskopie von Apophis Evidence Desk v0.3.1-review. Sie ist nicht produktionsreif und kein Sicherheits- oder Zulassungssiegel.

Die historische Review änderte drei fail-closed Eigenschaften: `reject` und `escalate` blockieren das Approval-Gate; beschädigtes gespeichertes JSON wird nicht als leeres Log behandelt; nicht-lokale Bind-Adressen werden ohne Authentifizierung abgewiesen. Der damalige Regressionstest deckte diese Fälle sowie eine vollständige synthetische Approval-Kette ab.

Der aktive private Ed25519-Schlüssel aus dem Upload wurde aus dieser Kopie ausgeschlossen. Das bestehende signierte Bundle bleibt offline verifizierbar, aber die alte Identität kann mit dieser Kopie nicht fortgesetzt werden. Das Original-ZIP nicht öffentlich verteilen. Falls der Schlüssel reale Vertrauensbedeutung hatte, ist Rotation/Widerruf vor weiterer Nutzung erforderlich.

Der historische Stand richtete keine realen Nutzeridentitäten ein und verarbeitete keine produktiven Daten. Der Interop-Selbsttest prüft nur das lokale JSON-Mapping.

Die News-Inbox bleibt deaktiviert. Der Refresh-Pfad hat jetzt exakte HTTPS-Host-Allowlist, keine Redirects, Content-Type-Check, Body-/Zeit-/Quellenlimits und Offline-Negativtests. DNS-Pinning und Egress-Kontrollen fehlen weiterhin; es wurde kein Live-Refresh ausgeführt und keine Produktionsfreigabe erteilt.

## Ergänzungen v0.4.5-anomaly-demo-preview

Das Preview enthält zusätzlich ein manuelles, verschlüsseltes Anwendungsdaten-Backup, ein separates Warnmeldungs-Radar sowie ein passives lokales Anomalie-Demo. Das Anomalie-Demo lädt keine Live-Daten ab: Nutzende können öffentliche SMARD-CSV-Zeitreihen oder vor Ort freigegebene aggregierte Messdaten lokal importieren. SMARD-Daten sind öffentlich nutzbar unter CC BY 4.0 mit Namensnennung „Bundesnetzagentur | SMARD.de“. Die eingebaute Median/MAD-Auswertung ist eine statistische Detektorvorstufe, kein trainierter Cyberangriffsklassifikator. Der Demo-Port ist standardmäßig Loopback-only; die Core- und Warnmeldungsdienste erhalten die Messreihen nicht.

Einstellungen, Baselines, erwartete Betriebsregime und Fehlalarmgrenzen müssen je Organisation und Messgröße individuell festgelegt und mit geeigneten Normal-/Störfällen kalibriert werden. Die öffentlichen SMARD-Strommarktdaten sind aggregierte Netzlastwerte, keine Telemetrie einer einzelnen KRITIS-Anlage.

---

**KaVa-14.10.26**

## Ergänzungen v0.4.6-emergency-control-preview

Der Prototyp ergänzt einen durch Zwei-Personen-Autorisierung ausgelösten Apophis-Anwendungsstopp. Vor dem Sperren wird ein verschlüsseltes Anwendungsdaten-Beweispaket für einen konkret konfigurierten Behördenempfänger erzeugt; sein Schlüssel wird für dessen gepinnten RSA-Public-Key verpackt. Zwei weitere Personen müssen die Wiederfreigabe autorisieren. Das ist kein vollständiges Systemabbild und löst keine Abschaltung von Host, Strom, Netzwerk, OT/SCADA oder Sicherheitstechnik aus. Behörden-PKI, Identitätsadapter, Remote-Transfer und automatische Löschfristen sind nicht enthalten; der Empfänger muss je Institution individuell konfiguriert und geprüft werden.
# 0.4.7 — Öffentliche Produktmuster (20.10.2026)

- Resilienzregister ergänzt `pdca_stage` und verantwortliche, terminierte Korrekturmaßnahmen.
- Arbeitsbericht weist ungültige sowie offene/überfällige Maßnahmen aus.
- Regressionstests decken Registergrundlage, PDCA-Werte, Fristen, Status und ungültige Maßnahmen ab.
- Isolierte Ende-zu-Ende-Tests prüfen verschlüsselte Backup-Erstellung/Verifikation/Wiederherstellung, Zwei-Personen-Sperren, Schlüsselablehnung, Manipulationserkennung, Symlink-Schutz und Notfallfreigabe.
- Muster aus GRC/BCM, KI-Agenten-Kontrollen, Anomalieerkennung und Backup-Unveränderbarkeit abstrahiert dokumentiert.
- Keine produktive KI, externe Identität, SIEM-Anbindung oder unveränderbare externe Backup-Ablage ergänzt.
- Grundlage ist eine Auswahl öffentlicher Herstellerdokumentation; es werden keine Alleinstellungs- oder Überlegenheitsansprüche erhoben.

