# Separates Warnmeldungs-Radar: Architektur und API-Vertrag

## Grenze zum Apophis Core

Das Warnmeldungs-Radar ist ein eigenständiger Prozess (`scripts/warning-radar-service.js`) mit eigener Oberfläche, eigenem Loopback-Port und eigenem Verzeichnis `warning-radar/data/`. Der Dienst importiert weder `server.js` noch Core-Module und greift nicht auf Core-Daten, Approval-Status, Audit-WORM, Projekte oder Datenbank zu. Es gibt keine Route vom Warnmeldungsdienst in den Core und keine Synchronisierung. Die Integration in die Produktoberfläche erfolgt nicht als Core-Plugin; Nutzende öffnen die eigenständige Warnradar-Oberfläche.

```text
Amtliche Quellen / geprüfte API-Adapter
                 |
        normalisierte Intake API
                 v
     Separater Warnmeldungsdienst
        eigene Events + UI + API
                 X
            Apophis Core
```

Der Dienst bindet standardmäßig ausschließlich an `127.0.0.1:3011`. Andere Bind-Adressen werden verweigert. Ein lokaler Quellenadapter ist mit einem zufälligen Bearer-Token (mindestens 32 Zeichen) authentisiert. Der Dienst selbst ruft keine externe URL ab; damit sind Quellenabruf und Warnmeldungsdarstellung zusätzlich getrennt. Ein produktiver Adapter kann als eigener Prozess mit festem Endpunkt und eigener Egress-Allowlist angebunden werden.

## Zweistufiger Status

- `preliminary` / **Vormeldung**: Eine aktive Meldung einer konfigurierten Quellenfamilie ist eingegangen. Die Oberfläche sagt ausdrücklich, dass keine unabhängige Bestätigung vorliegt.
- `source_confirmed` / **Quellenbestätigt**: Zu derselben `correlation_id` liegen aktive Meldungen aus mindestens zwei verschiedenen konfigurierten `source_family`-Werten vor.
- `resolved` / **Aufgehoben oder abgelaufen**: Keine der zuletzt je Quelle bekannten Meldungen ist mehr aktiv, wurde zurückgenommen/entwarnt oder ist abgelaufen.

„Quellenbestätigt“ beschreibt ausschließlich die Quellenlage. Es ist kein Urteil über Wahrheit, Gefährlichkeit oder behördlichen Status. Die Korrelation über `correlation_id` muss vom geprüften Adapter oder einer verantwortlichen Stelle nach transparenten Matching-Regeln gebildet werden; ähnliche Titel allein sind kein ausreichendes Matching. Spiegelungen derselben Quelle müssen derselben Quellenfamilie angehören und zählen nicht als unabhängige Bestätigung. Eine amtliche Vormeldung wird sofort angezeigt; das Modul wartet nicht auf eine zweite Quelle. Amtliche Handlungshinweise sind immer direkt bei der herausgebenden Stelle maßgeblich.

Jede Aufnahme ist ein neues Event. Bestehende Meldungen werden nicht überschrieben. Quell-ID, Quellenfamilie, Original-URL, Ausstellungs- und Erfassungszeit, Ablaufzeit, Meldungstyp, Payload-Hash sowie Hash-Verkettung bleiben nachvollziehbar. `update`, `withdrawal` und `all_clear` sind eigene Event-Typen.

## API

- `GET /health`: Dienststatus, keine Core-Verbindung.
- `GET /api/warnings`: gruppierte Warnmeldungen mit Stufe und Herkunftsdaten.
- `POST /api/intake`: normalisierte Warnmeldung; nur mit Bearer-Token und nur für eine explizit aktivierte Quelle aus `warning-radar/data/sources.json`.

Beispiel des Intake-Objekts:

```json
{
  "source_id": "example-agency",
  "correlation_id": "event-2026-001",
  "event_type": "published",
  "source_url": "https://agency.example.gov/alerts/123",
  "issued_at": "2026-10-20T10:00:00Z",
  "expires_at": "2026-10-20T18:00:00Z",
  "title": "Beispielhafte Lageinformation",
  "summary": "Kurzbeschreibung der Originalmeldung.",
  "instruction": "Wortgetreuer oder klar gekennzeichneter Auszug aus der Quelle.",
  "hazard_type": "other",
  "severity": "unknown"
}
```

Das Quellregister muss `id`, `family`, `name`, `origin` und `enabled: true` enthalten; die `source_url` muss HTTPS und exakt auf diese Origin begrenzt sein. Das Beispielobjekt ist synthetisch. Es ist kein API-Aufruf an eine reale Behörde.

## Quellenstatus und nächster Adapter

Das BBK beschreibt, dass Warn-App NINA amtliche Warnmeldungen aus MoWaS sowie unter anderem Wetter- und Hochwasserinformationen aufnimmt; warnung.bund.de bündelt amtliche Warnungen und Hinweise verschiedener zuständiger Stellen. Die verfügbaren BBK-Seiten belegen diese Quellenbeziehungen, veröffentlichen in der hier geprüften Dokumentation aber keinen stabilen Entwicklervertrag für einen öffentlichen Echtzeit-API-Adapter. Deshalb ist das Quellregister standardmäßig deaktiviert und leer; der Prototyp ruft keine inoffiziellen oder undokumentierten Endpunkte ab. Vor Aktivierung einer realen Quelle müssen Betreiber die aktuelle API, Nutzungsbedingungen, Rate Limits, Datenfelder, Aktualisierung, Widerruf/Entwarnung und Zuordnung zur Quellenfamilie mit dem Anbieter verifizieren.

Referenzen:

- [BBK: MoWaS und Warn-App NINA](https://www.bbk.bund.de/DE/Warnung-Vorsorge/Warnung-in-Deutschland/MoWaS/mowas_node.html)
- [warnung.bund.de: Informationen zu amtlichen Meldungen und Quellen](https://warnung.bund.de/)
- [BBK: Funktionen und Inhalte der Warn-App NINA](https://www.bbk.bund.de/DE/Warnung-Vorsorge/Warn-App-NINA/Funktion-Inhalt/funktion-inhalt_node.html)

## Grenzen vor Produktivbetrieb

Noch nicht enthalten sind reale Provider-Adapter, Polling-Zeitplan, Push-Benachrichtigungen, Rollenverwaltung über Maschinenidentitäten, externer Serverbetrieb, Hochverfügbarkeit, Replikation, Geo-Matching, Konfliktauflösung und unabhängige Sicherheitsprüfung. Der Prototyp ist eine getrennte Review-Inbox, kein behördliches Warnmittel, kein Ausfallschutz und kein Ersatz für Cell Broadcast, Sirenen, NINA oder Weisungen der zuständigen Stellen. Keine echte Krisenlage damit allein überwachen.
