# Apophis Allrounder

Der Allrounder bündelt vier Funktionen, ohne die Sicherheitsgrenzen zu verwischen:

1. **Evidence Desk:** Quellen, Claims, Gegenclaims, Unsicherheiten, Statuswerte, Coverage-Matrix und Approval-Gates.
2. **Integrity Desk:** Ed25519-Identität, Rotation-Log, SHA-256-Referenzhashes, Bundle-Receipt, Approval-Hashkette und Offline-Verifier.
3. **Integration Desk:** kanonisches `data/interoperability-package.json`, Adaptervertrag, Systemmatrix und Interoperabilitäts-Selbsttest. Fremdsystem-Importe sind bewusst noch nicht ausgeführt.
4. **News Inbox:** deaktivierte-by-default News-Inbox mit Allowlist, Zeitlimit, Roh-Hash und menschlicher Triage. News ändern niemals automatisch Claim- oder Gate-Status.

## Kommandos

```bash
npm run check
npm run build:bundle
npm run interop:check
npm run news:refresh
npm run verify
npm run smoke
npm run export:pack
```

## Read-only APIs

- `GET /api/news` liefert den letzten News-Inbox-Stand.
- `GET /api/interoperability` liefert das kanonische Austauschformat.
- `POST /api/references/check` führt den expliziten Link-Check aus.

Die APIs zeigen Daten oder führen klar begrenzte Prüfungen aus. Keine API erteilt eine wissenschaftliche, regulatorische oder DURC-Freigabe.

---

**KaVa-14.10.26**
