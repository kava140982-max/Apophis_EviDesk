# Apophis Evidence Desk 0.5.0-offline-only-preview

## Ergänzungen 0.5.0

Alle eingebauten externen Netzwerkzugriffe sind gesperrt. Nur Loopback für die lokale Oberfläche ist erlaubt; aktive Refresh- und Referenzprüfungen schlagen geschlossen fehl. Details und die Grenze zwischen Anwendungssperre und Host-Firewall stehen in `OFFLINE_ONLY.md`.

## Ergänzungen 0.4.9

Dokumentation des reproduzierten Apophis-Core-Grenzwerttests ergänzt: 2.000 synthetische, unvollständige CBOR-Eingaben wurden lokal abgewiesen. Aussageumfang und Herkunft: `APOPHIS_2000_INPUT_TEST.md`. Der Produktcode ist gegenüber 0.4.8 unverändert; diese Preview-Version ergänzt die nachvollziehbare Testherkunft.

## Ergänzungen 0.4.8

Der Offline-Verifier lehnt fehlende oder ungültige explizit angegebene Approval-Dateien fail-closed ab. Fünf Regressionfälle sind in `npm test` integriert. Der vollständige lokale Prüflauf auf einer frischen Kopie bestand; dies ist keine externe Sicherheitsprüfung oder Produktionsfreigabe.

## Ergänzungen 0.4.7

Öffentlich dokumentierte Muster aus GRC/BCM, KI-Agenten-Kontrollen, Anomalieerkennung und Backup-Produkten wurden auf ihre Übertragbarkeit geprüft. Das Resilienzregister enthält nun je Eintrag eine PDCA-Arbeitsphase sowie verantwortliche und terminierte Korrekturmaßnahmen; der Bericht zählt offene und überfällige Maßnahmen. Die übrigen Muster sind als Architekturziele oder Betreiberanforderungen dokumentiert und werden nicht als bereits implementierte Funktionen ausgegeben. Details und Quellen: `PUBLIC_PATTERN_ADAPTATIONS.md`.

Apophis ist ein lokaler Due-Diligence-Prototyp für Quellen, Claims, Gegenclaims, Unsicherheit und menschliche Übergaben. Er ist weder Forschungsrepository noch Sicherheits-, Wirksamkeits-, Zulassungs- oder DURC-Siegel.

## Was vorhanden ist

Das Projekt enthält ein signiertes Evidence Bundle mit SHA-256-Receipt, Ed25519-Offline-Verifier, strukturierte Claims und Grenzen, eine lokale Approval-Hashkette, einen einfachen LLM-freien Biosecurity-Scanner, einen Audit-Pack-Export und einen lokalen JSON-Mapping-Selbsttest. Die Demo-Daten sind synthetisch markiert.

Die Review-Härtung macht `reject` und `escalate` zu Blockern des `ready`-Gates und zeigt sie in der UI an. Beschädigtes gespeichertes JSON wird nicht als leere Daten behandelt. Nicht-Loopback-Bind-Adressen werden ohne Authentifizierung abgewiesen. `RED_TEAM_REPORT_REVIEW.md` dokumentiert die reproduzierten Befunde und Korrekturen.

## Lokale Prüfung

Voraussetzung ist Node.js 20 oder neuer. `npm test` führt Syntaxprüfung aller JavaScript-Dateien, Bundle-/Approval-Verifikation samt negativen Approval-Dateifällen, lokalen Interop-Formatcheck, Workflow- und Manifest-Regressionen, WORM- und Tenant-Tests einschließlich HTTP-Integration sowie Governance-, News-Sicherheitsregression und Smoke-Test aus. Wird beim Offline-Verifier ein Approval-Dateipfad angegeben, muss die Datei vorhanden und gültig sein; fehlende oder fehlerhafte Freigaben führen zu einem Fehlerstatus. Es sind keine npm-Pakete von Dritten erforderlich.

```bash
npm test
npm run export:pack
npm start
```

`npm run test:eu-controls` validiert das maschinenlesbare EU-Kontrollprofil, löst jede referenzierte Evidenzdatei sicher relativ zum Projektwurzelverzeichnis auf und schreibt für jede Datei Dateigröße und SHA-256 in `artifacts/eu-controls-evidence.json`. Der vollständige Control-Report steht in `artifacts/eu-controls-result.json`. Der Test schlägt bei ungültigem Profil, fehlender/unlesbarer Evidenz oder Pfaden außerhalb des Projekts fehl. Optionale, im Profil allowlistete Prüfkommandos können mit `npm run test:eu-controls:run` ausgeführt werden; im aktuellen Profil sind keine solchen Kommandos aktiviert.

## Verbindliche Offline-only-Policy (v0.5.0)

Alle von Apophis verwalteten externen Netzwerkzugriffe sind gesperrt. Nur lokale Loopback-Verbindungen für die Oberfläche sind erlaubt; nicht-lokale Bind-Adressen werden abgelehnt. Forschungs-/News-Abruf und Referenzprüfung schlagen geschlossen fehl. Siehe [`OFFLINE_ONLY.md`](OFFLINE_ONLY.md) und die drei systemd-Vorlagen in `deploy/`. Sie werden durch Entpacken nicht automatisch installiert; eine hostweite Netzsperre gilt erst nach Installation und Prüfung.

## Forschungs-Radar (offline deaktiviert)

Das Quellen-Radar ist in v0.5.0 offline-only: `npm run research:refresh` führt keine Abfrage an Europe PMC oder einen anderen externen Dienst aus. Ist es aktiviert, bricht es geschlossen mit `external_network_disabled` ab. Quellen-URLs in gespeicherten Datensätzen sind passive Metadaten.

Der Radar schreibt ausschließlich in sein separates Verzeichnis, hat keinen direkten Core- oder Datenbankzugriff und kann keine Freigaben oder Claims ändern. Die Recherche-Ergebnisse sind ein Review-Eingang: bibliografische Identität und Hash belegen Herkunft/Version des abgerufenen Metadatensatzes, nicht die wissenschaftliche Qualität oder Wahrheit einer Studie. Lokale KI-Vorschläge, Volltextverarbeitung und eine Core-API-Integration sind in dieser Version noch nicht implementiert. Der beigefügte Entwicklerbrief beschreibt diese späteren, getrennten Ausbaustufen.

## Verschlüsseltes Daten-Backup (Prototyp, manuell)

`npm run backup:create` erstellt ein AES-256-GCM-verschlüsseltes Abbild der Anwendungsdaten unter `data/` und schreibt es in ein lokales Sicherungsverzeichnis. Netzlaufwerke und externe Server sind wegen der Offline-only-Sperre nicht zulässige Ziele. Private Signierschlüssel aus `data/keys/` sind ausgeschlossen und müssen separat über einen institutionellen Schlüsselverwaltungsprozess gesichert werden. Es handelt sich nicht um ein vollständiges Betriebssystem- oder Serverabbild und noch nicht um einen automatisierten Zeitplan oder einen Remote-Upload-Client.

Das Prototyp-CLI verlangt ein außerhalb des Projekts liegendes Zielverzeichnis und `APOPHIS_BACKUP_AUTHORIZER`. Der absolute Pfad verweist auf einen institutionellen Adapter, der OIDC/SSO-Identitäten tatsächlich prüft und für die angeforderte Operation, die Backup-Prüfsumme und eine kurze Gültigkeitsdauer zwei unterschiedliche Freigebende bestätigt. Er muss JSON gemäß `apophis/dual-control-authorization/v1` mit `decision`, `operation`, `resource_sha256`, `authorization_id`, zwei `distinct_actors` und `expires_at` ausgeben; für `create`, `verify` und `restore` zusätzlich einen kurzlebigen 32-Byte-Datenschlüssel (`key_hex`). Seine Freigaben protokolliert der Adapter selbst. Das CLI vertraut diesem Adapter; ein Demo-Skript oder frei konfigurierbarer Ersatz ist keine echte Zwei-Personen-Sicherung. Der Schlüssel liegt kurzzeitig im Prozessspeicher. Für den Produktivbetrieb ist ein KMS-Adapter vorzuziehen, der die Schlüsseloperation selbst ausführt.

Mit angeschlossenem, geprüftem Adapter prüft `npm run backup:verify -- <datei>` Entschlüsselung und Inhalts-Hashes; `npm run backup:restore -- <datei> <leeres-verzeichnis>` stellt in ein neues, leeres Verzeichnis wieder her; `APOPHIS_BACKUP_KEEP=14 npm run backup:prune` behält die jüngsten 14 Abbilder und verlangt für tatsächliche Löschungen ebenfalls zwei Freigaben. Aufbewahrungszahl und Ausführungsintervall sind je Institution festzulegen. Der Zielpfad muss auf einem lokalen Datenträger liegen; ein Netzwerk-Mount widerspricht der Offline-only-Policy.

**Der institutionelle Identitäts- und Backup-Autorisierungsadapter ist nicht enthalten.** Bis ein solcher Adapter integriert und unabhängig geprüft ist, sind Erstellung, Verifikation, Wiederherstellung und Löschung gesperrt; das lokale Demo-System darf nicht für echte Daten verwendet werden. Details und KI-Leitplanken stehen in `AI_GOVERNANCE_AND_BACKUP.md`.

## Separates Warnmeldungs-Radar (API-Prototyp)

Das optionale Warnmeldungs-Radar läuft als eigener Prozess (`npm run warning:start`) auf `127.0.0.1:3011`. Es importiert weder `server.js` noch Core-Daten, APIs oder Approval-Stores. Eigene Oberfläche: `http://127.0.0.1:3011/`; eigener Speicher: `warning-radar/data/`. Es gibt bewusst keinen Link, keine Synchronisierung und keinen Rückschreibepfad im Core.

Die Inbox führt eine Einzelquellenmeldung als `preliminary`/Vormeldung. Erst wenn zu derselben bewusst gesetzten `correlation_id` aktive Meldungen aus mindestens zwei unterschiedlichen `source_family`-Werten vorliegen, lautet der Status `source_confirmed`/quellenbestätigt. Dies ist eine Quellenzählung, kein Wahrheits-, Gefahren- oder behördliches Freigabeurteil. Aktualisierungen, Rücknahmen und Entwarnungen werden als neue, hashverkettete Ereignisse geführt; die Oberfläche zeigt Herkunft, Zeitpunkt, Original-Link und Payload-Hash.

Das Quellregister ist deaktiviert und leer. In dieser Version wird kein externer Quelladapter unterstützt: das lokale Intake ist nur über Loopback erreichbar, alle nicht-lokalen Bindings werden beim Start abgewiesen und ausgehende Verbindungen sind im Apophis-Code gesperrt. Ein Betreiber kann Warnmeldungen lokal einspielen; die Quellenangabe wird nicht live abgerufen.

API: `GET /api/warnings`, `GET /health`, `POST /api/intake`. Die Warnoberfläche ist ein separates Modul; amtliche Handlungsanweisungen sind immer direkt bei der herausgebenden Stelle zu beachten. Ein produktiver Betrieb benötigt einen geprüften und lizenzierten Quelladapter, API-Verfügbarkeits-/Aktualitätsmonitoring, echte Dienstidentitäten und organisatorische Regeln.

## Lokales Anomalie-Demo (CSV, passiv)

`npm run anomaly:start` startet einen weiteren unabhängigen Loopback-Dienst auf `127.0.0.1:3020` mit eigener UI unter `http://127.0.0.1:3020/` und eigenem Verzeichnis `anomaly-demo/data/`. Er importiert keine Core-Module, kontaktiert keine externen Systeme, steuert keine Anlage und greift nicht auf den Warnmeldungsdienst zu.

In der UI lassen sich Zeitreihen-CSV lokal importieren, etwa ein von SMARD heruntergeladener öffentlicher Netzlast-/Erzeugungswert oder ein vom Betreiber ausdrücklich freigegebener aggregierter Netzwerkzähler. CSV-Datei, Quelle, Messgröße, Einheit und Hash des Originalexports werden erfasst. Die Quellenangabe wird als Importmetadatum dargestellt, nicht unabhängig verifiziert. Ein synthetisches Beispiel ist klar als erfunden markiert.

Der erste lokale Detektor verwendet einen robusten gleitenden Median/MAD-Vergleich plus individuell einstellbare absolute und relative Mindestabweichung sowie Mindestdauer. Das ist ein transparenter statistischer Anomalie-Detektor, kein trainierter Angriffsklassifikator und keine GenAI. Ein Treffer lautet ausschließlich „Prüfhinweis“. Datenlücken, Zeitauflösung und Betriebsregime beeinflussen die Aussagekraft. Öffentliche SMARD-Netzlast ist ein aggregierter Marktwert, kein Sensorwert einer konkreten Anlage und kein Nachweis für Stromnetzangriffe. Vollständige Anpassungs- und Datennutzungshinweise: `ANOMALY_DEMO.md`.

## Notfallmodus und behördlicher Empfängerschlüssel (Prototyp)

v0.4.6 ergänzt einen lokalen CLI-Notfallmodus. `npm run emergency:trigger -- <authority-id>` erstellt nach Zwei-Personen-Autorisierung ein verschlüsseltes Anwendungsdaten-Beweispaket für genau einen in `config/authority-recipients.json` konfigurierten Behördenempfänger und sperrt anschließend die Apophis-HTTP-Routen. `npm run emergency:release` verlangt zwei neue, unterschiedliche Freigebende. Der Empfängerschlüssel ist behörden-/zuständigkeitsbezogen; es gibt keinen universellen Masterkey. Konfigurations-, Schlüssel- und Adapteranforderungen stehen in `EMERGENCY_CONTROL.md`.

Das ist kein vollständiges Systemabbild und kein Fernübertragungs- oder Automatikdienst. Der Notfallmodus fährt weder Host, Stromversorgung, Leitstellen noch OT-/Sicherheitsanlagen herunter. Ein produktiver Empfänger, echte Behörden-PKI, Identitätsadapter und gesicherter Transfer fehlen; bis dahin nur synthetische Daten verwenden.

## KRITIS-Resilienz-Arbeitsregister

`data/kritis-resilience-catalog.json` enthält ein versioniertes, quellenverknüpftes Arbeitsmodell zu ausgewählten Pflichten aus BSIG §§ 30–32, 38 und KRITIS-DachG §§ 12–13 (Stand des Katalogs: 20.10.2026). Es ist ein Startpunkt für Betreiber und muss anhand von Sektor, Einrichtung, konkreter Rechtslage und späteren sektoralen Vorgaben angepasst werden. Es ist weder vollständig noch eine Rechtsauslegung oder Konformitätsaussage.

`data/kritis-resilience-register.json` ist ein synthetisches, bewusst leeres Register. Zuständigkeit, Anwendbarkeit, Status, nächste Prüfung und Evidenzreferenzen können dort vom Pilotteam gepflegt werden. `npm run kritis:resilience-report` erzeugt daraus einen Bericht auf stdout, prüft Vollständigkeit, Termine und Evidenzpfade und berechnet SHA-256 für referenzierte Projektdateien. Ein Status `evidenced` verlangt mindestens eine vorhandene Datei; das belegt nur deren Vorhandensein und Hash, nicht deren fachliche Richtigkeit oder Wirksamkeit. Der Bericht bleibt immer `WORKING_REGISTER_ONLY` und `not_a_certification: true`.

`data/kritis-exercise-template.json` bietet ein strukturiertes Format für synthetische Tabletop- und Wiederherstellungsübungen einschließlich gemessener RTO/RPO-Werte, Beobachtungen und Folgeaufgaben. Für dieses lokale Arbeitsregister keine Live-Zugangsdaten, genauen Anlagenpläne oder ausnutzbaren Asset-Details eintragen. Der Prototyp führt weder Meldungen aus noch erkennt er Angriffe; BSIG-Meldewege und Fristen müssen Betreiber und zuständige Stellen für ihren konkreten Fall verifizieren.

Für GitHub Actions sind ein verpflichtendes lokales Quality-/Evidence-Gate (`.github/workflows/quality.yml`) und ein separater OpenSSF-Scorecard-Workflow (`.github/workflows/scorecard.yml`) enthalten. Alle verwendeten Drittanbieter-Actions sind auf vollständige Commit-SHAs gepinnt. `npm run test:ci-workflow` prüft diese Vorgabe und blockiert privilegierte `pull_request_target`-Trigger. Der Scorecard-Upload zu GitHub Code Scanning ist bewusst fehlertolerant, weil private Repositories dafür GitHub Advanced Security benötigen können; das SARIF-Artefakt bleibt trotzdem erhalten.

Der Release-Workflow (`.github/workflows/release-evidence.yml`) erzeugt auf `main` ein SHA-256-Manifest und signiert Manifest, EU-Control-Reports, SBOM und Audit-Pack keyless mit Sigstore/Cosign. Anschließend verifiziert er jede Signatur gegen die konkrete GitHub-Workflow-Identität. Der Workflow benötigt keine privaten Signierschlüssel; die eigentliche Sigstore-Signierung kann nur in GitHub Actions mit OIDC ausgeführt werden, nicht im lokalen Sandbox-Lauf.

Änderungen an Approvals, Projekten, Access-Requests und Gruppen-Exchanges werden zusätzlich in einem content-addressed, append-only Evidence-Store unter `data/worm-evidence/` gespiegelt. `npm run test:worm-storage` prüft Überschreibschutz, Hashnamen, Namespace-Validierung und Manipulationserkennung. `GET /api/audit/worm/verify` liefert den lokalen Prüfstatus und weist `physical_worm_guarantee: false` aus. Die API filtert Tenant-Datensätze einschließlich Approvals und Privacy-Export/-Erase über `tenant_id`; im Adapter-Modus (`APOPHIS_TRUST_TENANT_HEADER=1`) wird fehlender Tenant-Kontext auf geschützten Routen mit HTTP 401 abgewiesen. Der Modus authentifiziert den Header selbst nicht: Er darf nur hinter einem verifizierenden OIDC-/SAML-/AAI-Adapter laufen. Der Demo-Modus ist nicht authentifiziert und kein Produktionsersatz. Details stehen in [WORM_AND_TENANT_IMPLEMENTATION.md](WORM_AND_TENANT_IMPLEMENTATION.md).

Der Server bindet nur an Loopback, standardmäßig `127.0.0.1:3000`. Diese Demo hat keine Anmeldung oder Organisationsidentität und ist kein Netzwerkdienst.

`npm run build:bundle` wurde bewusst nicht ausgeführt. Der Befehl kann beim Fehlen einer lokalen Identität einen neuen privaten Ed25519-Schlüssel in `data/keys/` erzeugen. Die vorhandene Demo-Identität wurde nicht neu erzeugt oder rotiert.

## Schlüsselhinweis

Die Paketnotizen weisen darauf hin, dass das ursprüngliche Gesamtpaket den privaten Ed25519-Schlüssel zur aktiven Demo-Identität enthielt. Schlüsselmaterial wird in dieser Arbeit weder erzeugt noch gelesen oder verwendet. Das vorhandene signierte Bundle bleibt mit dem enthaltenen öffentlichen Schlüssel offline prüfbar. Weiterzugebende ZIPs müssen private Schlüsseldateien ausschließen. Das Originalpaket nicht öffentlich oder an Pilotpartner weitergeben; falls der Schlüssel reale Vertrauensbedeutung hatte, Widerruf und Rotation vor weiterer Nutzung dokumentieren. Die externe Datei `HARDENING_NOTES.md` ist kein Bestandteil dieses Pakets.

## Integrationen und Grenzen

`npm run interop:check` prüft nur das lokale Austauschformat. Es wurde kein OSF-, Zenodo-, Dataverse- oder InvenioRDM-System live angebunden. Ein sinnvoller nächster Entwicklungsschritt ist ein synthetischer Contract-Pilot gegen eine isolierte Dataverse- oder InvenioRDM-Testinstanz mit Export, Read-back, Versionswechsel und Revoke/Supersede.

Weiterhin fehlen echte Authentifizierung, institutionell bestätigte Rollen, HSM/Key-Store, produktive Mandantentrennung mit Datenbank-RLS, unabhängige Zeitstempel und produktiv betriebene Adapter. Approval-Actors und Begründungen wären bei realer Nutzung personenbezogene Daten; Aufbewahrung, Zweckbindung und Zugriffsschutz sind nicht umgesetzt. Daher wird weder DSGVO-Konformität noch Produktionsreife behauptet.

Ein begrenzter Produktisierungs- und 90-Tage-Pilotentwurf mit Aufwand, offenen Gates und wirtschaftlichen Grenzen steht in [PRODUCTIZATION_AND_FOUNDATION_OFFER.md](PRODUCTIZATION_AND_FOUNDATION_OFFER.md). Er ist keine Umsatzprognose und kein Kundenangebot.

Der Biosecurity-Scanner ist eine begrenzte Regex-Heuristik. Ein Ergebnis `pass` beweist nicht, dass Inhalt sicher ist. Die News-Inbox bleibt deaktiviert. Der Refresh-Pfad verlangt exakte HTTPS-Hosts, folgt Redirects nicht und begrenzt Quellen, Antwortgröße und Laufzeit; die Regression testet Allowlist und Größenlimit. DNS-Pinning und institutionelle Egress-Kontrollen fehlen weiterhin, daher nicht als produktionssicheren Netzwerkdienst aktivieren. Datenschutzstatus und offene Freigaben stehen in `PRIVACY_READINESS.md`; der synthetische Repository-Pilot ist in `PILOT_STRATEGY.md` beschrieben.

## Vergleichstest

Ein wiederholbares, anbieterneutrales Vergleichsprotokoll mit sechs synthetischen Szenarien steht in `COMPARATIVE_TEST_PROTOCOL.md`. Apophis wurde lokal teilweise daran geprüft; HiScout, verinice, ServiceNow, Microsoft Sentinel und Veeam sind ausdrücklich `NOT_RUN`, weil keine zugelassenen Testinstanzen vorlagen. Die Vergleichsmatrix behauptet keine Rangfolge. Prüfergebnisse und Grenzen stehen in `VALIDATION_REPORT.md` und `comparative-eval/`.

---

**KaVa-14.10.26**
