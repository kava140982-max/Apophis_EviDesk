# Interoperability Profile v1

Apophis is an evidence-governance overlay. It does not replace OSF, Zenodo, Dataverse, InvenioRDM, Matrix or ActivityPub. The profile makes the boundary explicit so two installations can discover one another, identify a shared community and exchange records without silently granting trust.

## Discovery and community identity

Each deployment exposes `/api/capabilities`, `/.well-known/apophis-community.json`, `/.well-known/webfinger` and, when a public HTTPS origin is configured, `/.well-known/did.json`. WebFinger is discovery only. A DID document or Verifiable Credential authenticates a key or issuer; it does not prove that a claim is true or that a project is approved.

The community manifest contains the supported profile names, adapter targets, privacy defaults, project policy and non-claims. The same `community_id` is a coordination label, not a trust shortcut. A future production federation must add signed membership credentials, issuer allowlists, replay protection, rate limits and explicit consent before delivery.

## Project exchange

`GET /api/projects` lists local project metadata. `POST /api/projects` creates a private project with an explicit retention period and opt-in external links. A connector may import a bundle into a project or create a review case. It may not map `published`, `registered`, `released`, `approve` or an unknown external state to `geprüft`, `freigegeben` or `sicher`.

Für den Austausch mehrerer Systeme in einer Gruppe beschreibt `GROUP_EXCHANGE_PROFILE.md` einen kurzlebigen Challenge–Response-Handshake. Eine erfolgreiche Signaturprüfung ergibt `identified`, nicht `trusted`. Gruppennachrichten werden als `received-needs-review` gespeichert und verändern keine Claims oder Approval-Gates.

Adapter targets are represented by stable profile identifiers:

- **OSF**: project and registration references; no automatic approval.
- **Zenodo**: deposit/record/version/DOI references; publication is not review.
- **Dataverse**: dataset/version/collection references; metadata is not evidence.
- **InvenioRDM**: community/record/version/role references; curation is not biosecurity clearance.
- **C2PA / VC**: provenance and issuer/subject/verifier metadata; verifiability is not truth.
- **Matrix / ActivityPub**: optional discovery and message delivery profiles; disabled by default in this local build.

## GDPR-oriented defaults

The build defaults to loopback, no telemetry, private projects and no external sync. It exposes access/export and actor-scoped erasure for the local synthetic store. Production use still requires a controller, legal basis, notices, retention and backup deletion, access control, processor agreements, transfer assessment, DPIA assessment and an incident process. The application must not be advertised as GDPR-compliant merely because these endpoints exist.

## DNS pinning

Any future connector must validate an HTTPS hostname against an explicit allowlist, resolve all A/AAAA addresses, reject loopback/private/link-local/multicast/metadata/documentation ranges, then connect through the validated address while preserving the original hostname for Host, SNI and certificate verification. Redirects are rejected. Re-resolution on retry must repeat the policy. This closes the validation-to-connection gap described by OWASP; an allowlist alone does not close DNS rebinding.

## References

[1]: https://www.w3.org/TR/activitypub/ "ActivityPub"
[2]: https://spec.matrix.org/v1.16/server-server-api/ "Matrix Server-Server API"
[3]: https://www.w3.org/TR/vc-data-model-2.0/ "Verifiable Credentials Data Model 2.0"
[4]: https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng "Regulation (EU) 2016/679"
[5]: https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html "OWASP SSRF Prevention Cheat Sheet"
