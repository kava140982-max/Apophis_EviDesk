# Interoperabilitätstestplan

## Ziel

Ein identischer synthetischer Run soll in Apophis und einem Repository-System nachvollziehbar bleiben. Der Test prüft nicht wissenschaftliche Wahrheit, sondern Datenverlust, Versionierung, Rollenbindung, Exportierbarkeit und sichere Fehlermeldungen.

## Testfixture

Die Fixture besteht aus vier öffentlichen Referenzkarten, sechs Claims, sechs Gegenclaims, fünf Coverage-Zeilen, drei Rollen, einem blockierten Biosecurity-Beispiel und zwei Bundle-Versionen. Es werden keine Sequenzen, Protokolle, Dosierungen oder realen Zugangsdaten verwendet.

## Adapter-Schritte

1. Apophis erzeugt Bundle v5 und berechnet die Bundle-ID sowie SHA-256-Referenzhashes.
2. Der Adapter exportiert Records, Claims, Quellen, Status, Unsicherheit, Gegenclaims, Rollen und Hashes in `data/interoperability-package.json`.
3. Ein Zielsystem nimmt nur die dafür vorgesehene Repository-Struktur auf. Es darf keine fachliche Freigabe aus dem Import ableiten.
4. Der Adapter liest die Zielversion zurück und vergleicht IDs, Hashes, Scope, Statuswerte und Gegenclaims.
5. Eine neue Bundle-Version wird erzeugt. Die alte Approval-Chain muss für die neue Version ungültig sein.
6. Ein manipulierter Hash, ein unbekannter Status und ein blockierter Detailtext müssen fail-closed behandelt werden.
7. Der Export wird ohne laufenden Server mit `scripts/verify.js` geprüft.

## Akzeptanzkriterien

- Kein Claim verliert seine Gegenclaim- oder Unsicherheitsfelder.
- Kein Zielsystem-Export wird als wissenschaftliche oder regulatorische Freigabe interpretiert.
- Ein alter Approval wird bei Bundle-Wechsel nicht als gültig gezählt.
- Unbekannte Statuswerte führen zu Ablehnung statt zu `PASS`.
- Der Export enthält eine sichtbare Quellen- und Scope-Grenze.
- Das Ergebnis kann ohne proprietären Client zumindest kryptografisch geprüft werden.

## Status

Die lokale Apophis-Seite des Tests ist ausführbar. Fremdsystem-Importe sind noch `NOT-EXECUTED`, weil keine lokale Instanz, keine synthetische Testumgebung und keine Zugangsdaten für OSF, Zenodo, Dataverse oder InvenioRDM bereitgestellt wurden. Das ist eine offene Integrationsprüfung, kein PASS.

---

**KaVa-14.10.26**
