# Apophis Evidence Desk: KI-Leitplanken und lokales Modell

**Konzeptentwurf auf Basis der Produktpakete v0.4.1 und v0.4.2**  
**Stand: 20. Oktober 2026**

## Zweck und Status

Dieses Papier beschreibt zwei getrennte KI-Bausteine für Apophis:

1. eine optional angebundene KI über eine externe API mit klar begrenzten Rechten;
2. einen lokalen Inferenzdienst mit einem für den jeweiligen Einsatz quantisierten Modell.

Beide Bausteine bleiben außerhalb des Apophis Core. Der Core verwaltet Evidenz, Status und menschliche Freigaben. Er vertraut keiner KI-Ausgabe automatisch und stellt keine automatische Verbindung zu einem Modell her. In v0.4.2 sind beide KI-Bausteine noch nicht implementiert. Das Research Radar ist eine optionale, standardmäßig deaktivierte Metadaten-Inbox ohne KI und ohne Schreibzugriff auf den Core.

Die vorliegenden Pakete beschreiben einen lokalen Prototyp, keine produktive KRITIS-Plattform. Die hier skizzierten Regeln sind daher ein Entwurf für die nächste Entwicklungs- und Pilotstufe, kein Nachweis einer Zertifizierung oder Konformität.

## 1. Gemeinsame Sicherheitsregel: Jede Nachricht wird eingeordnet

Keine Nachricht geht ungeprüft an ein Modell und keine Modellantwort gelangt ungeprüft in den Core. Jede Anfrage und Antwort erhält eine nachvollziehbare Nachrichtenhülle (Envelope) und durchläuft Richtlinienprüfungen.

### Mindestangaben der Nachrichtenhülle

- eindeutige `message_id` und verkettete `conversation_id`;
- authentifizierte `actor_id`, Organisation/Mandant und wirksame Rolle — vom Identity-Adapter bestätigt, nie aus einem frei gesetzten Client-Header übernommen;
- Richtung: `user_to_model` oder `model_to_apophis`;
- Zweck und erlaubte Aufgabe, zum Beispiel `summarize_approved_source`;
- Datenklassen und Schutzstufe, etwa öffentlich, intern, vertraulich, personenbezogen oder besonders schutzbedürftig;
- Referenzen auf freigegebene Quellen/Snapshots, nicht nur frei übermittelter Text;
- ausgewählter Modellweg (`api` oder `local`), Modell-/Providerkennung sowie Richtlinien- und Schema-Version;
- Prüfergebnis, Entscheidung (`allow`, `redact`, `deny`, `human_review`) und Begründungscode;
- Zeitstempel, Audit-Referenz, Eingabe- und Ausgabehash, sofern Aufbewahrung und Datenschutzkonzept dies zulassen.

Die Kennung ist für Auditierbarkeit, Berechtigung und Rückverfolgung gedacht. Sie ist kein Beweis, dass Inhalt wahr, zulässig oder sicher ist. Nutzdaten dürfen nicht unkontrolliert in Klartext-Logs geschrieben werden.

### Externe Sicherung und Zwei-Personen-Autorisierung

Als Wiederherstellungsvorsorge können in angemessenen, für den Betrieb festgelegten Abständen verschlüsselte Systemabbilder auf einem externen Sicherungsserver abgelegt werden. Das Sicherungsziel ist ein eigener, kontrollierter Datenfluss und keine KI- oder Modellverbindung. Vor der Aktivierung muss die Institution bestimmen, welche Daten in ein Abbild gehören, wo es gespeichert werden darf, wie lange es aufbewahrt wird und wann es sicher gelöscht wird.

- Verschlüsselung erfolgt vor der Übertragung und bleibt auch auf dem Sicherungsserver aktiv. Schlüssel und Wiederherstellungsgeheimnisse werden getrennt vom Sicherungsziel verwahrt.
- Sicherungsserver und Apophis-Core erhalten getrennte Identitäten, Rollen und Berechtigungen. Zugriff wird auf benannte Personen beschränkt und protokolliert.
- **Jeder administrative Zugriff auf Sicherungsabbilder sowie jede Wiederherstellung erfordert die Autorisierung durch zwei verschiedene, authentifizierte Personen.** Eine Person darf nicht beide Zustimmungen erteilen. Die Freigabe gilt nur für den angegebenen Zweck, das konkrete Abbild und einen begrenzten Zeitraum.
- Erstellung, Zugriff, Wiederherstellung und Löschung werden mit Akteur, Zeit, Backup-ID, Zweck und Ergebnis revisionsfähig protokolliert. Protokolle enthalten nach Möglichkeit keine Klartextinhalte oder Schlüssel.
- Aufbewahrungsfristen und Löschläufe werden verbindlich konfiguriert. Abgelaufene Abbilder und temporäre Wiederherstellungskopien werden kontrolliert gelöscht; Löschung und Ergebnis werden protokolliert.
- Wiederherstellbarkeit wird regelmäßig in einer isolierten Testumgebung mit freigegebenen Testdaten geprüft. Das Ergebnis und die verwendete Backup-Version werden dokumentiert.
- Ein Notfallverfahren darf den Zwei-Personen-Grundsatz nicht stillschweigend umgehen. Falls ein Betreiber einen Break-Glass-Prozess benötigt, muss dieser vorab institutionell geregelt sein, eine nachträgliche unabhängige Prüfung verlangen und vollständig protokolliert werden.

Die Zwei-Personen-Autorisierung muss technisch erzwungen werden, etwa durch getrennte Freigaben im Backup-/Schlüsselverwaltungssystem und eine kurzlebige Wiederherstellungsberechtigung. Eine bloße Vier-Augen-Regel in einer Arbeitsanweisung genügt nicht als technische Zugriffssperre. Welche konkrete Lösung geeignet ist, hängt von Identitätsverwaltung, Sicherungsserver und Schlüsselverwahrung der jeweiligen Institution ab.

### Prüfablauf je Nachricht

1. **Identität und Mandant prüfen:** gültige Sitzung und Rolle, Mandantenzuordnung, Zweck und Objektberechtigung feststellen.
2. **Inhalt klassifizieren:** Datenklasse, Quellstatus, Geheimnisse, personenbezogene Inhalte, kritische Betriebsdetails und nicht vertrauenswürdige eingebettete Anweisungen erkennen.
3. **Regel anwenden:** nur die für Aufgabe, Rolle, Datenklasse und Modellweg freigegebene Minimalmenge weitergeben; andernfalls schwärzen, an lokale Verarbeitung verweisen, menschliche Prüfung verlangen oder blockieren.
4. **Modell isoliert aufrufen:** keine zusätzlichen Rechte durch Prompt oder Modellantwort; nur fest definierte Eingaben und Ausgaben.
5. **Antwort prüfen:** Schema, Länge, Quellenbezug, verbotene Felder, Statusänderungen, Datenabfluss und policy-konforme Ausgabe validieren.
6. **Als Vorschlag speichern:** Ausgabe erhält eigene KI-Herkunft, Modell- und Promptversion und bleibt `pending`. Eine berechtigte Person entscheidet ausdrücklich über Annahme, Ablehnung oder Eskalation.

Prompt-Injection-Schutz ist kein einzelner Klassifikator. Quelleninhalte, Anhänge und Nutzertext gelten als Daten, nicht als privilegierte Systemanweisungen. Die Durchsetzung erfolgt serverseitig über Zugriffsrechte, Allowlist-Aufgaben, Schemas und isolierte Werkzeuge. Modelltext kann diese Regeln nicht überschreiben.

## 2. Baustein A: externe KI über API

### Erlaubt — eng begrenzte Vorschläge

Eine API-KI darf nur für einzeln freigegebene, nicht kritische Aufgaben genutzt werden, zum Beispiel:

- freigegebene, geeignete Quellen in einfacher Sprache zusammenfassen;
- mögliche Claims und Gegenbefunde aus bereitgestellten Textausschnitten extrahieren;
- Unsicherheiten, methodische Hinweise und offene Prüffragen vorschlagen;
- Text strukturieren oder in ein validiertes Apophis-Vorschlagsformat überführen.

Jeder Vorschlag muss auf konkrete Quell-IDs und Fundstellen verweisen. Fehlt ein belastbarer Quellenbezug, wird er als unbelegt gekennzeichnet oder verworfen. Die KI darf nicht behaupten, einen Volltext geprüft zu haben, wenn sie nur Metadaten oder ein Abstract erhielt.

### Verboten — keine Core- oder Entscheidungsrechte

Die API-KI darf nicht:

- den Core, dessen Datenbank oder Signierschlüssel direkt beschreiben;
- Evidenz, Freigaben, Rollen, Status, Prüffristen oder Audit-Datensätze selbst ändern;
- `approved`, `verified`, `safe`, `compliant` oder einen vergleichbaren Entscheidungsstatus setzen;
- fachliche, rechtliche, regulatorische, KRITIS-, Biosecurity- oder Sicherheitsfreigaben erteilen;
- eigenständig Quellen suchen, URLs öffnen, Tools aufrufen, Code ausführen oder Aktionen in angeschlossenen Systemen auslösen;
- Mandanten- oder Projektdaten zusammenführen oder Daten anderer Mandanten sehen;
- personenbezogene, geheime, klinische, klassifizierte oder anlagenkritische Daten erhalten, solange dafür keine gesonderte Rechts-, Datenschutz-, Sicherheits- und Vertragsfreigabe vorliegt;
- stillschweigend auf einen anderen Anbieter oder lokalen/cloudbasierten Fallback wechseln.

### Datenfreigabe und Betriebsgrenze

Vor Versand muss ein serverseitiger Egress-Gate prüfen, ob Zweck, Anbieter, Datenklasse, Region/Verarbeitung, Aufbewahrung, Vertragsbedingungen und konkrete Felder für diesen Einsatz freigegeben sind. Standard ist: **kein Versand**. Nur explizit freigegebene, minimierte Inhalte dürfen die kontrollierte API-Grenze passieren. Redaktion von Geheimnissen ist eine Schutzmaßnahme, aber kein Ersatz für Freigabe und Datenschutzprüfung.

Der API-Adapter erhält nur kurzlebige, auf den Dienst beschränkte Zugangsdaten aus einem Secret Store. Schlüssel gehören weder in Browser, Prompts, Datenpakete noch Logs. Netzwerkzugriff ist auf den freigegebenen Anbieter beschränkt; Timeout, Größenlimit, Rate-Limit, Kostenlimit, Abbruchschalter und nachvollziehbarer Fehlerpfad sind Pflicht. Ist der Anbieter nicht verfügbar oder die Eingabe nicht freigegeben, bleibt der normale Apophis-Betrieb verfügbar.

### API-Antwortvertrag

Die API darf nur ein validiertes Vorschlagsobjekt liefern, zum Beispiel:

```json
{
  "schema": "apophis/ai-suggestion/v1",
  "message_id": "msg-…",
  "task": "source_review_summary",
  "source_ids": ["source-123"],
  "claims": [
    {
      "text": "…",
      "evidence": [{"source_id": "source-123", "locator": "abstract:Results"}],
      "status": "unverified_suggestion"
    }
  ],
  "limitations": ["…"],
  "conflicting_findings": [],
  "review_required": true
}
```

Unbekannte Felder, Ausführungsanweisungen und Freigabestatus werden abgewiesen. Die Apophis-Vorschlags-API darf nur eine getrennte Inbox befüllen; die spätere Übernahme ist eine authentifizierte menschliche Aktion mit eigener Begründung und Auditspur.

## 3. Baustein B: lokale KI und Quantisierungsbauplan

Das lokale Modell wird als separater Dienst betrieben. Der Prozess hat keinen direkten Datenbankzugriff auf den Core, keine ausgehende Netzwerkroute, keine Secrets und keine Werkzeuge. Er erhält ausschließlich die nach Prüfung freigegebenen Ausschnitte. Als Schnittstelle dient ein lokaler Socket oder Loopback mit zusätzlicher Dienstauthentisierung; eine bloße Bindung an `127.0.0.1` allein ist keine ausreichende Produktionsabsicherung.

### Quantisierung in einfachen Worten

Quantisierung speichert Modellgewichte mit weniger Bits, damit ein Modell weniger Speicher benötigt und auf vorhandener Hardware schneller oder überhaupt lokal laufen kann. Das kann Antwortqualität, Genauigkeit, Stabilität, Kontextlänge oder Geschwindigkeit beeinflussen. Quantisierung schafft für sich allein weder Datenschutz noch Sicherheit, Fachwissen, Faktenprüfung oder Schutz vor Prompt Injection. Sie ist außerdem nicht dasselbe wie Fine-Tuning.

### Umsetzungsplan

**Schritt 1 — Einsatzprofil festlegen**  
Vor einer Modellauswahl werden Aufgaben, Sprachen, fachliche Begriffe, maximale Kontextlänge, erlaubte Datenklassen, gleichzeitige Nutzer, Latenzziel, Offline-Anforderung, Betriebsdauer und verfügbare Hardware erfasst. Dazu gehören GPU/VRAM oder CPU/RAM, Betriebssystem, Energie- und Wartungsgrenzen sowie Lizenz- und Bezugsbedingungen des Modells.

**Schritt 2 — Basismodell festlegen**  
Ein geeignetes, lizenzrechtlich geprüftes Basismodell wird zunächst in der bestmöglichen praktikablen Präzision als Qualitätsreferenz betrieben. Modellname, genaue Version, Gewichte, Lizenz, Laufzeit und Hash werden festgehalten. Eine Modellgröße wird nicht allein aufgrund allgemeiner Empfehlungen festgelegt.

**Schritt 3 — Testkorpus und Referenzantworten aufbauen**  
Ein repräsentativer, freigegebener Korpus aus synthetischen oder ausdrücklich zugelassenen Apophis-Beispielen wird erstellt. Fachpersonen markieren erwartete Quellenbezüge, Grenzen, Gegenbefunde, korrekte JSON-Ausgaben und kritische Fehlermuster. Personenbezogene oder kritische Echtdaten werden nicht ohne gesonderte Freigabe in den Kalibrierungskorpus aufgenommen.

**Schritt 4 — abgestufte Kandidaten erzeugen**  
Vom Referenzmodell aus werden mehrere Quantisierungsstufen gebaut. Je nach Runtime können beispielsweise GGUF-Varianten wie Q8, Q6, Q5 und Q4 verglichen werden; bei anderen Inferenzstacks kommen deren unterstützte Formate in Betracht. Das sind Testkandidaten, keine pauschale Empfehlung. Die konkreten Stufen hängen von Modellarchitektur, Runtime, Hardware und Lizenz ab.

**Schritt 5 — Qualität, Leistung und Fehlermodi messen**  
Jeder Kandidat wird auf demselben eingefrorenen Testset verglichen: belegte Claims und Fundstellen, unbelegte Behauptungen, Erkennung von Grenzen und Gegenbefunden, Schema-Treue, Sprachqualität, sensible Daten im Output, Latenz, Durchsatz und Speicherbedarf. Zusätzlich werden absichtliche Prompt-Injection-, Mandantentrennungs- und Abbruchfälle geprüft. Ergebnisse werden pro Aufgabe und Datenklasse dokumentiert; ein einzelner Gesamtscore reicht nicht.

**Schritt 6 — passende Variante auswählen**  
Die Institution setzt Mindestwerte für Qualität, Speicher, Latenz und Fehlerraten. Gewählt wird die speichersparsamste Variante, die alle fachlich und sicherheitsseitig gesetzten Mindestwerte erfüllt. Verfehlt jede quantisierte Variante die Mindestwerte, wird eine höhere Präzision, ein anderes Modell oder ein engerer Aufgabenbereich geprüft.

**Schritt 7 — reproduzierbar bereitstellen und überwachen**  
Artefakte werden versioniert und gehasht. Modell-, Quantisierungs-, Runtime-, Prompt-, Schema- und Policy-Versionen sind in jedem Vorschlag referenziert. Updates durchlaufen denselben Benchmark erneut. Rollback auf die zuvor freigegebene Version und ein Kill-Switch sind vorgesehen. Die KI bleibt Vorschlagsgeberin; Ergebnisqualität wird regelmäßig fachlich überprüft.

### Anpassung an jede Institution

**Der Quantisierungsplan und die Modellwahl müssen individuell angepasst werden.** Unterschiedliche Organisationen haben andere Hardware, Sprachen, Fachgebiete, Datenklassen, Risikotoleranzen, Rechtsgrundlagen, Offline-Anforderungen und Betriebsbedingungen. Selbst innerhalb einer Organisation kann ein Modell für öffentliche Quellen geeignet, für vertrauliche Betriebsdaten aber ungeeignet sein. Deshalb werden Datenfreigabe, Basismodell, Quantisierungsstufe, Testkorpus, Qualitätsgrenzen und Betriebsprofil für jeden Einsatzfall neu festgelegt und dokumentiert. Eine einmal getestete Quantisierung ist keine allgemeine Freigabe für andere Aufgaben oder Betreiber.

## 4. Gemeinsame Zielarchitektur

```text
Nutzer / authentifizierte Institution
                 |
                 v
       Nachrichten-Gateway
Identität · Mandant · Zweck · Klassifikation
                 |
           Policy-Entscheid
          /       |        \
     blocken   lokal   externe API
                 |        |
       isolierter Dienst  freigegebener Egress
          \       |        /
           Antwortprüfung
   Schema · Quellen · DLP · Policy
                 |
      KI-Vorschlags-Inbox (pending)
                 |
      menschliche Prüfung und Aktion
                 |
          Apophis Core / Audit
```

Das Gateway setzt Richtlinien durch, nicht das Sprachmodell. Die Kern-API kennt keine Modellidentität mit Schreibrechten. Menschliche Aktionen nutzen eigene, rollenbasierte Berechtigungen. Vorschläge und Entscheidungen sind unterschiedliche Objekte und erhalten unterschiedliche Herkunftskennzeichnungen.

Die Sicherung läuft als separater Betriebsweg: Core/Systemabbild → Verschlüsselung → externer Sicherungsserver. Lesen oder Wiederherstellen wird durch zwei unabhängige Freigaben autorisiert. Das Modell und die KI-API erhalten keinen Zugriff auf Sicherungsabbilder oder Sicherungsschlüssel.

## 5. Mindest-Gates vor einem Pilot

- dokumentierte Datenklassen und eindeutige Regeln, welche Felder an welchen Modellweg dürfen;
- echte Authentifizierung und serverseitig verifizierte Rollen/Mandanten, kein Vertrauen in unbestätigte Header;
- API-Egress nur nach Freigabe, ohne automatischen Fallback;
- lokaler Dienst ohne Core-Datenbankzugriff und ohne Egress;
- Schema- und Policy-Prüfung sowohl vor als auch nach der Inferenz;
- append-only nachvollziehbare Prüf- und Übernahmeereignisse mit Datenschutz- und Aufbewahrungskonzept;
- freigegebener Sicherungsumfang, externe verschlüsselte Ablage, getrennte Schlüsselverwahrung sowie angemessene Aufbewahrungs- und Löschfristen;
- technisch erzwungene Zustimmung zweier verschiedener Personen vor Zugriff auf Sicherungsabbilder oder Wiederherstellung, einschließlich protokollierter Testwiederherstellung;
- repräsentativer Fachbenchmark und dokumentierte Fehlerschwellen für jede Modell-/Quantisierungsversion;
- explizite menschliche Prüfung vor jeder Übernahme in Evidenz oder Status;
- Abschalt- und Rollback-Möglichkeit, unabhängiges Security-/Datenschutzreview und Pilot mit synthetischen oder freigegebenen Daten.

## 6. Einordnung des Projektstands

Die v0.4.2-Paketunterlagen beschreiben das Research Radar als deaktiviertes, separates Metadaten-CLI. Es ruft nach bewusster Aktivierung Metadaten ab und legt sie in einer Review-Inbox ab; Volltextanalyse, lokale KI, API-Vorschläge, produktive Authentifizierung und Core-Integration fehlen noch. Die v0.4.1- und v0.4.2-Unterlagen betonen zudem, dass Apophis ein lokaler Prototyp und kein produktiver KRITIS-Dienst oder Konformitätsnachweis ist.

v0.4.3-preview ergänzt einen manuellen AES-256-GCM-verschlüsselten Anwendungssnapshot und einen fail-closed Autorisierungshaken für Prüfen, Wiederherstellen und Löschen. Es ist kein vollständiges Systemabbild, kein automatischer Zeitplan oder Remote-Transfer enthalten. Der externe IdP-/Backup-Autorisierungsadapter und die Zwei-Personen-Prüfung selbst fehlen weiterhin. Für einen Pilot müssen sie in der konkreten Infrastruktur umgesetzt und geprüft werden; die vorhandene lokale WORM-ähnliche Ablage ersetzt weder externe Backups noch eine solche Zugriffskontrolle.

Der nächste sinnvolle Entwicklungsschritt ist daher zunächst ein technischer Entwurf und ein synthetischer Pilot für das Nachrichten-Gateway, den Vorschlagsvertrag und den isolierten lokalen Modelladapter. Erst danach werden konkreter API-Anbieter, lokales Basismodell und Quantisierungsstufe für eine benannte Institution und Hardware ausgewählt.

## Implementierter Prototypumfang in v0.4.3-preview

Der Paketstand ergänzt einen manuellen CLI-Prototyp für verschlüsselte **Anwendungsdaten**. Er sammelt reguläre Dateien unter `data/`, lehnt symbolische Links ab, schließt `data/keys/` aus, bildet pro Datei SHA-256-Prüfsummen und verschlüsselt das komprimierte Abbild mit AES-256-GCM. Das Zielverzeichnis muss außerhalb des Projektverzeichnisses liegen. Ein externer Autorisierungsadapter gibt nach zwei authentifizierten Zustimmungen den 32-Byte-Schlüssel kurzzeitig an den CLI-Prozess zurück.

Befehle:

```bash
APOPHIS_BACKUP_AUTHORIZER=/usr/local/libexec/apophis-backup-authorizer \
APOPHIS_BACKUP_DIR=/mnt/approved-backup/apophis \
npm run backup:create

APOPHIS_BACKUP_AUTHORIZER=/usr/local/libexec/apophis-backup-authorizer \
npm run backup:verify -- /mnt/approved-backup/apophis/<backup-datei>

APOPHIS_BACKUP_AUTHORIZER=/usr/local/libexec/apophis-backup-authorizer \
npm run backup:restore -- /mnt/approved-backup/apophis/<backup-datei> /restore/empty-directory

APOPHIS_BACKUP_AUTHORIZER=/usr/local/libexec/apophis-backup-authorizer APOPHIS_BACKUP_DIR=/mnt/approved-backup/apophis APOPHIS_BACKUP_KEEP=14 npm run backup:prune
```

Das Wiederherstellen schreibt ausschließlich in ein leeres Zielverzeichnis und überschreibt keine vorhandenen Dateien. Es tauscht keine laufende Installation aus und startet keine Anwendung neu. Eine externe Ablage ist nur dann gegeben, wenn `APOPHIS_BACKUP_DIR` tatsächlich auf den institutionell freigegebenen, eingebundenen Backup-Server zeigt. Automatisierung des Intervalls ist deployment-spezifisch und noch nicht konfiguriert. Der Befehl `prune` löscht ältere Dateien anhand einer konfigurierbaren Anzahl; Frist, Intervall, Uhrzeit und Freigaben sind je Einsatzfall festzulegen.

### Nicht umgesetzt / vor Echtdaten erforderlich

- Es wird kein vollständiges Betriebssystem-/Datenträgerabbild erstellt.
- Es gibt keinen Remote-Upload- oder Transport-Client und keinen Timer/ Scheduler.
- Die Zwei-Personen-Freigabe für Lesen, Schlüsselverwendung und Wiederherstellung ist nicht implementiert, da die Demo keine verifizierte Identität oder Rollenverwaltung hat. Das Backup-CLI darf daher nicht als Zugriffskontrolle für Echtdaten eingesetzt werden.
- Signierschlüssel unter `data/keys/` werden absichtlich nicht gesichert. Dafür braucht es einen getrennten, institutionellen Key-Management-/HSM-Prozess einschließlich zweier unabhängiger Autorisierungen.
- Die Ausführung benötigt eine unabhängige Prüfung von Schlüsselbereitstellung, Serverzugriff, Retention/Löschung und Wiederherstellungsverfahren, bevor echte Daten verwendet werden.

### Fail-closed Adaptervertrag für Zwei-Personen-Freigaben

Das Backup-CLI verlangt bei `create`, `verify`, `restore` und tatsächlichem `prune` die Umgebungsvariable `APOPHIS_BACKUP_AUTHORIZER` mit einem absoluten Pfad zu einem institutionellen Autorisierungsprogramm. Es erhält Operation, Ziel und SHA-256 des konkreten Backup-Artefakts (bei `create`: Digest des Datenbestands; bei `prune`: Hash der zu löschenden Namen und Inhalte). Es muss binnen 15 Sekunden eine gültige, noch nicht abgelaufene Freigabe mit zwei unterschiedlichen Akteur-IDs zurückgeben. Für `create`, `verify` und `restore` enthält die Antwort außerdem den 32-Byte-Datenschlüssel. Fehlt der Adapter, schlägt er fehl oder passt die Freigabe nicht zur konkreten Aktion und Ressource, wird die Operation verweigert.

Der Adapter ist nicht Teil dieses Pakets. Er muss die Akteur-IDs aus einer vertrauenswürdigen Identitätsquelle beziehen, zwei voneinander unabhängige Zustimmungen erfassen, Scope und Ablaufzeit binden sowie seine Auditspur außerhalb des Apophis-Prozesses dauerhaft sichern. Die bloße Ausgabe zweier Namen genügt in einer produktiven Umgebung nicht. Schlüsselentschlüsselung muss ebenfalls hinter dem KMS-/Backup-Zwei-Personen-Verfahren liegen; ein lokal lesbarer Schlüssel hebt diese Kontrolle auf. Bis diese Integration vorhanden und geprüft ist, ist die Funktion nur ein Prototyp für synthetische Daten.

## Separates Warnmeldungs-Radar

v0.4.4-preview ergänzt ein eigenständiges Warnmeldungsmodul für die vorgeschlagene Zweistufen-Anzeige. Der Dienst läuft separat mit eigener API, eigener Oberfläche und eigenem Datenverzeichnis. Er importiert weder Core-Code noch greift er auf Core-Daten, Freigaben oder Audit-Ereignisse zu; es existiert kein Rückschreibepfad. Die Daten sind daher auch nicht in Core-Sicherungen enthalten. Betrieb und Sicherung des Warnradars müssen getrennt geplant werden.

Eine einzelne konfigurierte Quellenfamilie erzeugt eine **Vormeldung**. Erst zwei verschiedene aktive Quellenfamilien zur gleichen `correlation_id` ergeben **quellenbestätigt**. Die Oberfläche zeigt sofort die Vormeldung; sie wartet nicht auf eine zweite Quelle. „Quellenbestätigt“ ist kein Wahrheits- oder Gefahrenurteil. Rücknahme und Entwarnung werden als neue Ereignisse gespeichert. Das Quellenregister ist deaktiviert/leer; es gibt noch keinen Live-Provider-Adapter, keinen Polling-Zeitplan und keine Push-Funktion.

API-Vertrag, Eventschema und Betriebsgrenzen stehen in [WARNING_RADAR_ARCHITECTURE.md](WARNING_RADAR_ARCHITECTURE.md). BBK-Informationen beschreiben NINA als Empfänger amtlicher MoWaS-Warnungen und warnung.bund.de als Portal mit Meldungen verschiedener zuständiger Stellen. In den hier geprüften offiziellen Informationen fand sich kein stabiler öffentlicher Entwicklervertrag für einen Echtzeit-Adapter. Daher werden keine inoffiziellen Endpunkte abgefragt. Ein konkreter Adapter wird erst nach Verifikation der API, Nutzungsbedingungen, Aktualisierung, Entwarnungs- und Quellenregeln eingebunden.

## Lokales Anomalie-Demo mit CSV-Zeitreihen

v0.4.5-preview ergänzt ein weiteres unabhängiges, passives Loopback-Demo. Es kann eine bewusst ausgewählte CSV-Zeitreihe importieren, lokal eine Baseline bilden und Abweichungen als Prüfhinweis ausgeben. Reale öffentliche SMARD-Marktdaten können als CSV exportiert und importiert werden; betreibereigene aggregierte Netzwerk-/Strommesswerte sind ebenfalls möglich, wenn sie vor Ort dafür freigegeben sind. Rohdaten bleiben lokal. Der Dienst greift nicht auf den Core, den Warnmeldungsdienst, Sensoren oder Steuerungen zu. Es gibt kein Live-Polling und keine automatischen Gegenmaßnahmen.

Die enthaltene Erkennung ist ein robuster gleitender Median/MAD-Detektor. Das ist eine statistische Modellvorstufe, **keine trainierte Angriffserkennungs-KI**. Eine eigenständige, lokal trainierte/anpassbare KI ist ein späterer Modelladapter. Jeder Messreihen-Pilot braucht individuell definierte Referenzzeiträume, Zeitauflösung, Saison-/Schichtmuster, zulässige Datenlücken, absolute/relative Toleranzen, Persistenz und Fehlalarmgrenzen. Die Demo-Standardwerte sind Platzhalter und kein Betriebsprofil.

Öffentliche SMARD-Netzlastdaten sind aggregierte Marktwerte. Sie eignen sich zum Zeigen des Import-/Baseline-Flows, aber nicht als Sensorwerte einer einzelnen Anlage und nicht als Beleg für einen Cyberangriff. Details, Setup, Lizenzhinweis und Kalibrierungscheckliste stehen in [ANOMALY_DEMO.md](ANOMALY_DEMO.md).

## Notfallmodus und zuständigkeitsbezogener Behördenempfänger in v0.4.6-preview

Der separate Entwurf `EMERGENCY_CONTROL.md` beschreibt den implementierten Applikations-Notfallmodus: Zwei Personen autorisieren den Trigger, Apophis sperrt daraufhin seine HTTP-Routen und legt ein AES-256-GCM-verschlüsseltes Anwendungsdaten-Beweispaket ab. Der zufällige Datenschlüssel wird mit dem RSA-3072+-öffentlichen Schlüssel eines einzelnen, lokal registrierten Behördenempfängers umhüllt; der registrierte SHA-256-Fingerprint muss stimmen. Zwei verschiedene Personen autorisieren auch die Freigabe, die an die konkrete Lock-Datei gebunden wird.

Es wird kein universeller oder in Apophis gespeicherter Behörden-Masterkey eingebaut. Ein Behördenempfänger kann nur Pakete mit seinem zugehörigen privaten Schlüssel öffnen. Die Behörde bzw. Institution muss Schlüsselherkunft, Zuständigkeit, Rotation und private Schlüsselverwahrung selbst absichern. Konfigurationsdatei, Schlüsselmaterial, echter Identitätsadapter, Remote-Transport, Terminierung und automatische Löschung sind deployment-spezifisch und hier nicht enthalten.

Der Auslöser nimmt ausschließlich Apophis-Anwendungsrouten außer Betrieb. Der Snapshot ist kein Host-/OS-Abbild; physische Anlagen, Strom, Netz, SCADA, Warnsysteme und Sicherheitstechnik werden nicht abgeschaltet. Für solche Systeme bleiben ausschließlich getrennt entwickelte und freigegebene Standortverfahren maßgeblich. Die Funktion ist bis zu unabhängiger Implementierungsprüfung, echter Zwei-Personen-Identität, Empfänger-Key-Verifikation und getesteter Rücksicherung nicht für Echtdaten freigegeben.
