# Öffentliche Produktmuster: Auswahl und Apophis-Umsetzung

**Stand:** 20. Oktober 2026 · **Apophis-Preview:** 0.4.7  
Dieses Papier beschreibt eine eigenständige, abstrahierte Umsetzung allgemein sichtbarer Produktmuster. Es kopiert weder Quellcode noch nicht öffentliche Inhalte anderer Anbieter. Anbieterangaben belegen deren veröffentlichte Produktbeschreibung, nicht eine unabhängige Prüfung.

## Übernommene und angepasste Muster

| Öffentlich dokumentiertes Muster | Apophis-Entscheidung | Stand in 0.4.7 |
|---|---|---|
| ISMS-/BCM-Tools wie HiScout und verinice verbinden Verantwortliche, regelmäßige Reviews, Übungen und Folgeaufgaben. | Resilienzregister um PDCA-Arbeitsphase und explizite, verantwortliche, terminierte Korrekturmaßnahmen ergänzen. Ein abgeschlossener Eintrag ersetzt keine Prüfung der Wirksamkeit. | Im Registerschema und im Bericht umgesetzt; leere synthetische Vorlage. |
| GRC-Agenten wie ServiceNow Otto für IRM verwenden kontrollierte Identitäten, getrennte User-/Data-Access-Berechtigungen, freigegebene Werkzeuge und gezielte Aktivierung/Tests. | Für Apophis dieselben Kontrollziele als Mindestprofil übernehmen: Dienstidentität, eng beschränkte Aufgaben und Daten, standardmäßig deaktivierte Ausführung, nur Vorschlags-Inbox, menschliche Übernahme und versionierte Testfälle. | Architekturvorgabe; kein KI-Agent und kein Identity Provider integriert. |
| SIEM-Anomalieprodukte wie Microsoft Sentinel zeigen Baselines, Kontext und messbare Abweichungen statt bloß eines Alarmworts. | Bestehende Median/MAD-Demo zeigt Messwert, Baseline, Toleranz, Richtung und Stärke des Ausschlags. Die Größe des Ausschlags heißt ausdrücklich nicht „Angriffswahrscheinlichkeit“ oder „Konfidenz“. Fehlende Daten, Betriebszustände und Fehlalarme bleiben Teil der Bewertung. | Erklärung in der Demo und Anleitung; kein Live-SIEM-Anschluss, kein trainiertes Erkennungsmodell. |
| Backup-Produkte wie Veeam kombinieren Verschlüsselung und konfigurierbare Speicherunveränderbarkeit/Retention. | Verschlüsselung, Unveränderbarkeit, Löschung und Wiederherstellbarkeit als getrennte Kontrollen behandeln. Apophis darf „immutable“ nur behaupten, wenn das externe Speicherziel seine Lock-/Retention-Garantie tatsächlich durchsetzt und das unabhängig verifiziert ist. | Anforderung für spätere Backup-Adapter; aktueller lokaler Prototyp bietet keine unveränderbare externe Ablage. |

## Änderung am Resilienzregister

Jeder Registereintrag enthält nun `pdca_stage` (`plan`, `do`, `check`, `act`) und `actions`. Eine Maßnahme hat eine eindeutige `id`, einen Status (`open`, `in_progress`, `complete`, `cancelled`), eine verantwortliche Person/Rolle und optional ein Fälligkeitsdatum. Der Bericht zählt offene und überfällige Maßnahmen und weist fehlerhafte Felder aus. Die synthetische Vorlage enthält noch keine echten Aufgaben oder Personen.

Die Maßnahme ist eine Arbeitserinnerung, kein Beleg für Umsetzung oder Wirksamkeit. Für einen Abschluss sind passende Nachweise und eine eigene fachliche Prüfung erforderlich. Der generierte Bericht bleibt ausdrücklich `WORKING_REGISTER_ONLY` und `not_a_certification: true`.

## Was noch nicht in Software umgesetzt ist

- produktive OIDC-/SAML-Identität und Agenten-Identitäten;
- wirksame serverseitige Trennung von Lese-, Vorschlags- und Schreibrechten für einen KI-Dienst;
- Zweipersonen-Freigabe in einem echten Identity-/Backup-/KMS-System;
- externe, getrennte und unveränderbare Backup-Ablage samt Retention-Lock;
- passive Integration realer SIEM-/OT-/Stromdaten und standortspezifischer Kalibrierung.

Diese Punkte sind keine fertigen Fähigkeiten. Eine lokale Demo oder Konfigurationsdatei kann ihre Durchsetzung nicht belegen.

## Quellen der Muster

- [HiScout GRC und BCM](https://www.hiscout.com/loesungen/) und [HiScout BCM](https://www.hiscout.com/module/bcm/)
- [verinice GRC/ISMS/BCM](https://verinice.com/) und [verinice BCM-Releaseinformationen](https://verinice.com/en/products/verinice-classic/release-notes)
- [ServiceNow Otto for IRM: KI-Agenten und Sicherheitskontrollen](https://www.servicenow.com/docs/r/zurich/governance-risk-compliance/grc-common-functions/use-agentic-ai-in-risk-sustainability.html)
- [Microsoft Sentinel: Baselines und Anomaliearten](https://learn.microsoft.com/en-us/azure/sentinel/anomalies-reference)
- [Veeam: Immutability von Backup-Dateien](https://helpcenter.veeam.com/docs/vbr/userguide/immutability_hv.html)

Die Auswahl ist bewusst auf relevante Nachbarmuster begrenzt. Sie ist keine vollständige Marktübersicht und kein unabhängiger Funktionstest der genannten Produkte.
