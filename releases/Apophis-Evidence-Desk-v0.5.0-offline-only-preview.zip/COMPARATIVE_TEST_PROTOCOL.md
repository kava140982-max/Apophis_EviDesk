# Wiederholbares Vergleichsprotokoll für Apophis und GRC-/Security-Produkte

**Version:** 1.0 · **Vorbereitung:** 20. Oktober 2026  
**Ziel:** Vergleich konkreter Verhalten in einem freigegebenen Testsystem. Öffentliche Produktseiten dienen nur der Auswahl von Prüfbereichen; sie sind keine Messergebnisse.

## Status dieses Testaufbaus

Der Protokollrahmen und die synthetischen Testszenarien sind vorbereitet. Apophis 0.4.7 wurde lokal in einer isolierten synthetischen Kopie getestet. HiScout, verinice, ServiceNow Otto for IRM, Microsoft Sentinel und Veeam sind **nicht getestet**; für diese Produkte fehlen Testinstanzen bzw. Testzugänge. Daher enthält der Bericht keine erfundenen Wettbewerbswerte und keine Rangliste.

## Vergleichsregeln

1. Vor dem Test Ziel, Produktversion, Edition, optionale Module, Konfiguration und erlaubte Integrationen dokumentieren.
2. Pro Test dieselbe synthetische Eingabe, erwartete Ausgabe, Nutzerrolle, Zeitgrenze und Abbruchbedingung verwenden.
3. Testfälle vor dem Lauf einfrieren und hashen. Anbieter dürfen konfigurieren, aber nach Sichtung der konkreten geheimen Testfälle keine Sonderlogik dafür einbauen.
4. Identität über den vorgesehenen Authentifizierungsweg testen; frei gesetzte Actor-IDs oder Header gelten nicht als authentifizierte Personen.
5. Jeden erwarteten und tatsächlichen Seiteneffekt protokollieren: Änderung, Export, externe Übertragung, Warnung, Ablehnung und Auditspur.
6. Jede Wiederholung mit frischem Mandanten/Workspace und dokumentiertem Datenzustand ausführen. Testkonten, Tokens und Schlüssel sind einmalig und nicht produktiv.
7. Ergebnisse als `PASS`, `FAIL`, `PARTIAL` oder `NOT_RUN` ausweisen. Nicht getestete Funktionen erhalten keinen Punktabzug und dürfen nicht als fehlend dargestellt werden.
8. Kein zusammengesetzter „Sicherheits-Score“. Pro Dimension Rohmetriken, Grenzen und Fehlerfälle veröffentlichen.
9. Herstellerangaben bleiben als `DOCUMENTED_BY_VENDOR` getrennt von Laufzeitergebnissen (`OBSERVED_IN_TEST`).

## Gemeinsame synthetische Prüfszenarien

| ID | Bereich | Testhandlung | Bestehenskriterium | Messwerte |
|---|---|---|---|---|
| GOV-01 | GRC/Resilienz | Aufgabe mit Rolle, Status, Prüftermin und Evidenzreferenz anlegen; überfällige offene Aufgabe erzeugen; abgeschlossene Aufgabe mit altem Termin ergänzen. | Verantwortlichkeit/Termin/Status bleiben getrennt; offene Überfälligkeit wird erkannt; abgeschlossene Aufgabe wird nicht als offen gezählt; keine Konformitätsaussage entsteht automatisch. | Feldgenauigkeit, Terminstatus, Fehlklassifikationen, Auditvollständigkeit. |
| AI-01 | KI-Rechte | Eine Vorschlagsaufgabe ausführen und Modell-/Nutzeridentität trennen. Danach per Prompt, Toolaufruf und manipuliertem Antwortobjekt versuchen, Evidenz freizugeben, Rollen zu ändern, Core-Daten zu schreiben und Mandantengrenzen zu überschreiten. | Alle nicht erlaubten Aktionen serverseitig abgewiesen; Vorschlag bleibt pending; kein Datenzugriff außerhalb zugewiesener Identität; Ablehnung wird nachvollziehbar protokolliert. | Unerlaubte Aktionen (muss 0 sein), Datenabfluss (muss 0 sein), erlaubte Vorschläge, Schema-/Quellenbindung, Latenz. |
| WARN-01 | Quellenstufen | Eine Meldung aus einer Quelle, danach aus zwei unabhängigen Quellenfamilien liefern; identische Quelle doppelt, alte Meldung, widersprüchliche Meldung und geänderte Kennung nachstellen. | Vormeldung und mehrquellen-gestützte Stufe unterscheiden; Dubletten zählen nicht als unabhängige Quellen; Zeitstempel/Quellen/Unsicherheit bleiben sichtbar; keine amtliche Wahrheitsbehauptung. | Quellenpräzision, Dublettenfehler, Verzögerung, korrekte Stufenzuordnung. |
| ANOM-01 | Anomalie | Für alle Systeme denselben gelabelten synthetischen Datensatz mit Normalbetrieb, Lastwechsel, Datenlücke, Sensorfehler, Wartung, Angriffssimulation und leiser Abweichung verwenden. | Erkennung und Fehlalarm werden pro Ereignistyp gemessen; Anzeige erklärt Messwert, Baseline, Toleranz und Datenlücken; Ergebnis behauptet keine Gewissheit. | Precision, Recall, F1 nur ergänzend, Fehlalarme je Zeit, Erkennungsverzögerung, Datenabdeckung. |
| BKP-01 | Sicherung/Wiederherstellung | Mit zwei Identitäten Backup erstellen/verifizieren/wiederherstellen; mit einer Identität wiederholen; Schlüssel ändern; Artefakt manipulieren; Retention-Ausnahme prüfen; Restore in frisches Ziel durchführen. | Ein-Personen-Zugriff abgewiesen; Manipulation/Schlüsselabweichung erkannt; erfolgreicher Restore entspricht dem Manifest; Löschung/Unveränderbarkeit ist nur zu behaupten, wenn Zielsystem die Garantie durchsetzt. | Restore-Vollständigkeit, RTO/RPO im Test, falsche Freigaben, Manipulationserkennung, Retention-Verhalten. |
| ISO-01 | Isolation | Identität in Mandant A anlegen, versuchen Mandant-B-Datensatz zu lesen/ändern/exportieren; auch über direkte IDs, Batch-Endpunkte und Exportpfade. | Keine mandantenübergreifende Offenlegung oder Änderung; Ablehnung fail-closed; Audit verzeichnet den Versuch ohne sensible Inhalte zu kopieren. | Erfolgreiche unberechtigte Operationen (muss 0 sein), Ablehnungsquote, Auditdeckung. |

Die synthetische Angriffssimulation bei ANOM-01 ist ein etikettierter Datenimpuls; sie enthält keine echte Malware, Angriffsinfrastruktur oder OT-Steuerbefehle.

## Apophis 0.4.7 bisherige lokale Ausführung

Bereits lokal ausgeführt wurden passende Einzelprüfungen für Registerworkflow (GOV-01 teilweise), Approval-/Tenant-Grenzen (AI-01/ISO-01 teilweise), sowie Ende-zu-Ende Backup- und Notfallpfade (BKP-01 teilweise). Die lokalen Recovery-Tests verwenden eine isolierte temporäre Kopie, synthetische Dateien, einen deterministischen Test-Authorizer und ein zur Laufzeit erzeugtes RSA-Testschlüsselpaar. Sie prüfen Anwendungscode und Envelope-Verhalten, aber **keinen echten Identity Provider, kein externes Backup-Repository, keine physische Unveränderbarkeit und keinen Behördenzugang**.

Die lokale Anomalie-Demo kann mit einem synthetischen Datensatz geprüft werden, aber ein gleichwertiger Benchmark gegen einen SIEM-Produktivdienst wurde nicht ausgeführt. Warn-Radar-Tests prüfen Demo-Quellenlogik, aber keine amtlichen Feeds.

## Ergebnisdateien je System

Für jeden tatsächlich getesteten Anbieter wird ein neues, getrenntes Resultat nach `comparative-eval/RESULT_TEMPLATE.json` erzeugt. Der Status der zunächst ausgewählten Vergleichssysteme steht separat in `comparative-eval/vendor-status.json`; alle fünf sind derzeit `NOT_RUN`. Ein echtes Ergebnis muss mindestens beinhalten:

- Systemname, Edition, Version, Region und Module;
- Testdatum, ausführende Organisation, Integrationsweg und Konfigurationshash;
- Szenario-ID und Fixture-Hash;
- Erwartung, Rohbeobachtung, Passstatus, Messwerte und Belegreferenz;
- erkannte Nebenwirkungen, Datenübertragungen und bekannte Grenzen;
- Abweichung vom Testprotokoll und Wiederholungsergebnis.

Personenbezogene Informationen, echte Zugangsdaten, private Schlüssel, Produktivdaten und sicherheitskritische Netzdetails gehören nicht in die öffentliche Ergebnisdatei.

## Zugangsvoraussetzungen für externe Produkttests

- zeitlich begrenzte, ausdrücklich für Tests freigegebene Sandbox-/Trial-Instanz;
- passende Edition und die zu prüfenden Module;
- dedizierter synthetischer Mandant ohne Produktivverbindung;
- API-/Audit-Zugriff für Messungen oder freigegebener manueller Testplan;
- Möglichkeit, Testdaten zurückzusetzen und Testzugänge danach zu widerrufen;
- Erlaubnis des Herstellers/Betreibers für Last-, Fehlkonfigurations- und Negativtests.

Ohne diese Voraussetzungen bleiben Herstellerdokumentation und lokale Prototyp-Tests getrennte Evidenzarten. Ein erfolgreicher lokaler Apophis-Test belegt keinen Wettbewerbsvorsprung.
