# Produktisierung und Pilotangebot

## Status und Positionierung

Apophis ist derzeit ein lokaler, synthetischer Due-Diligence- und Evidence-Governance-Prototyp. Er verknüpft Quellen, Claims, Gegenclaims, Unsicherheit, menschliche Review, ein signiertes Demo-Bundle und nachvollziehbare Release-Artefakte. Die Positionierung lautet:

> Evidence-first, purpose-bound, verifiable release integrity without trust inflation.

Das Projekt ist ein fortgeschrittener High-Assurance-Prototyp für kontrollierte synthetische Piloten. Es ist kein fertiges KRITIS-Produkt und keine Bestätigung von NIS2-, DSGVO-, CRA-, AI-Act-, eIDAS- oder EHDS-Konformität. Die konkrete Einstufung hängt von Betreiber, Sektor, Mitgliedstaat, Produkt- und Betriebsmodell ab.

## Geeignete Pilotumfelder

- Forschungsinstitute mit Bedarf an nachvollziehbarer Quellen- und Claim-Review,
- Open-Science-Infrastrukturen und Forschungsverbünde,
- öffentliche IT für synthetische Supply-Chain- oder Governance-Tests,
- verantwortungsvolle KI-Projekte, die Unsicherheit und menschliche Übergaben dokumentieren,
- Biosecurity-Projekte mit eng begrenzten, nicht-operativen Review-Daten,
- Software-Supply-Chain-Piloten für SBOM-, Provenance- und Signaturprüfung.

Der Startumfang sollte synthetische oder öffentliche Daten und einen klar begrenzten Zweck verwenden. Personenbezogene, klinische, biologische oder vertrauliche Organisationsdaten sind für den aktuellen Build nicht freigegeben.

## Mögliche Rolle einer Stiftung

Eine Stiftung kann einen Referenzpilot finanzieren, offene Infrastruktur fördern, einen Forschungsverbund vermitteln oder eine unabhängige technische und fachliche Evaluation beauftragen. Sie muss nicht als klassischer Vertriebspartner auftreten: Ihre Rolle kann darin liegen, ein öffentlich nützliches Verfahren zu ermöglichen, während Beschaffung, Betrieb und Support bei Institut oder Infrastrukturbetreiber liegen.

## Beispiel für einen 90-Tage-Pilot

Der folgende Umfang ist ein Gesprächs- und Planungsentwurf, kein Angebot und keine Compliance-Zusage.

| Zeitraum | Arbeit | Ergebnis |
| --- | --- | --- |
| Woche 1–2 | Zweck, Stakeholder, Datenfluss, Bedrohungsmodell und Abbruchkriterien festlegen | freigegebener Pilotplan mit synthetischem Datensatz |
| Woche 3–5 | isolierte Testumgebung, institutionelle Testidentitäten und Rollenmodell vorbereiten | kontrollierter Zugang und dokumentierte Grenzen |
| Woche 6–9 | SBOM-/Provenance-Workflow und einen klar begrenzten Repository- oder Metadatenadapter integrieren | wiederholbarer Export-/Read-back-Test |
| Woche 10–11 | Cross-Tenant-, Fehler-, Restore- und Incident-Übungen ausführen | Befunde, Testprotokolle und Maßnahmenliste |
| Woche 12–13 | gemeinsame Review und unabhängige Bewertung beauftragen oder vorbereiten | Abschlussbericht, Betriebsentscheidung und Folgeplan |

Der Pilot endet mit einer Entscheidung über Weiterentwicklung, begrenzten Betrieb oder Abbruch. Er endet nicht automatisch mit Produktfreigabe oder regulatorischer Anerkennung.

## Support- und Governance-Modell

Ein mögliches wiederkehrendes Modell kombiniert technische Wartung und Governance-Unterstützung:

- festgelegte Reaktionszeiten und monatliches Wartungsfenster,
- Dependency-, SBOM- und Release-Evidence-Review,
- Pflege von Rollen-, Zweck- und Aufbewahrungsentscheidungen,
- Unterstützung bei Audit-Vorbereitung und Incident-Übungen,
- klar begrenzte Integrationsstunden und getrennt beauftragte Sonderentwicklung.

Preis, Umfang, Haftung, Verfügbarkeit und Reaktionszeiten müssen mit Betreiber, Datenschutz- und Sicherheitsverantwortlichen vereinbart werden. Eine Support-Pauschale ist kein 24/7-Sicherheitsbetrieb.

## Open-Core und Dual Licensing

Eine mögliche Struktur hält Protokolle, Verifier, synthetische Fixtures und Kernformate offen. Bezahlte Leistungen könnten institutionelle Adapter, Deployment-Unterstützung, Wartung, definierte Support-SLAs und Governance-Beratung umfassen. Eine Dual-Licensing-Entscheidung benötigt zuvor eine Rechte- und Beitragsprüfung, eine klare Lizenzmatrix und Regeln für externe Beiträge. Dieser Bericht empfiehlt keine konkrete Lizenz, weil die Rechtekette nicht geprüft wurde.

## Technische Roadmap

1. Verifizierter OIDC-/SAML-/AAI-Adapter mit institutioneller Rollen- und Tenant-Zuordnung.
2. PostgreSQL mit `tenant_id` in jeder geschützten Tabelle, `SET LOCAL app.tenant_id`, Row-Level Security und Objekt-Autorisierung.
3. Getrennter Object-Lock-Speicher mit Compliance Retention, Versionierung und getrennten Schreib-/Lese-Rollen.
4. KMS/HSM, Schlüsselrotation, Widerruf, Wiederherstellung und getrennte Schlüsselrollen.
5. Dokumentierte Backup-/Restore-Ziele mit ausgeführtem Wiederherstellungstest.
6. Incident Response, Alarmierung, Schwachstellenprozess und geübte Verantwortlichkeiten.
7. Unabhängige Sicherheits-, Datenschutz- und fachliche Prüfung des konkreten Einsatzfalls.

## Grobe Aufwandsannahmen

Für einen begrenzten synthetischen Pilot sind grob 8–12 Personenwochen über 90 Tage plausibel, verteilt auf Softwareentwicklung, Plattformbetrieb, Sicherheit/Datenschutz und fachliche Review. Das ist eine frühe Planungsannahme, keine geprüfte Schätzung. Institutionelle Beschaffung, Authentifizierungsintegration, Datenschutz-Folgenabschätzung, Verfügbarkeitsanforderungen oder externe Sicherheitsbefunde können den Aufwand deutlich erhöhen.

Vor dem ersten zahlenden Kunden fehlen mindestens: verifizierte Authentifizierung, Datenbank-RLS, produktive Speicherung, Schlüsselverwaltung, getestetes Backup/Restore, Betriebs- und Incident-Prozesse, Supportgrenzen, Datenschutz-/Vertragsprüfung, unabhängiger Security-Test und eine konkrete rechtliche Bewertung des Einsatzes.

## Wirtschaftliche Grenze

Ein einzelnes ZIP-Archiv ist keine belastbare wiederkehrende Erlösbasis. Einnahmen könnten eher aus bezahlten Piloten, Support, Governance-Beratung, CI/CD- und SBOM-Integration, Audit-Vorbereitung und Wartung entstehen. Ein Nettoziel von 2.500 € pro Monat lässt sich daraus nicht garantieren; es hängt unter anderem von Kundengewinnung, Auslastung, Preis, Kosten, Steuern und Vertragslaufzeit ab.

