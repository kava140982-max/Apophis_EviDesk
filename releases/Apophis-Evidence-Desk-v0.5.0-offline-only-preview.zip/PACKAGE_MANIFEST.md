# Paketmanifest — Apophis Evidence Desk 0.5.0-offline-only-preview

v0.5.0 sperrt die eingebauten externen Netzwerkpfade, verweigert nicht-loopback Listener, schaltet Quellenabrufe geschlossen ab und ergänzt `OFFLINE_ONLY.md`, eine systemd-Vorlage sowie Regressionstests. Die systemd-Vorlage ist nicht automatisch installiert; sie belegt keine hostweite Sperre.

Diese Review-Kopie enthält den lokalen Due-Diligence-Prototyp, das offline prüfbare Demo-Bundle, UI/API, synthetische Fixtures, Red-Team-Berichte, Datenschutz-Readiness-Notiz, synthetischen Repository-Pilotplan, lokale Regressionstests, Audit-Pack-Export und PDF-Auditbericht.

Das Preview ergänzt vier voneinander getrennte Arbeitsmodule: manuelle verschlüsselte Anwendungsdaten-Backups mit verpflichtendem Zwei-Personen-Autorisierungsadaptervertrag; ein isoliertes Warnmeldungs-Radar mit Vormeldung/Quellenbestätigung; ein lokales passives Zeitreihen-Anomalie-Demo mit CSV-Import, SMARD-Importanleitung und individuell einstellbarer robuster Baseline; sowie einen Apophis-Anwendungs-Notfallmodus mit verschlüsseltem App-Daten-Beweispaket, empfängerbezogenem Behörden-Public-Key und Zwei-Personen-Freigaben. Für die Module sind externe Identitäts-/Autorisierungs-/Quelladapter nicht mitgeliefert; es gibt keinen Remote-Transfer und keine produktive Betriebsfreigabe.

## Inhalt und Schutzumfang

`server.js` stellt den lokalen HTTP-Server, Bundle-/Approval-Verifikation und API-Routen bereit. Er verweigert nicht-lokale Bind-Adressen ohne Authentifizierung. `public/` enthält UI, Styles, aktualisierten Audit-Pack und markiertes PDF. `data/` enthält den signierten synthetischen Demo-Run und Registerdaten. `SANDBOX-SBOM.json` inventarisiert den npm-Baum (null externe Komponenten); `scripts/` enthält SBOM-Verifier, Bundle-Build, Offline-Verifier, begrenzte Biosecurity-Heuristik, Export, lokale Checks sowie Governance- und News-Sicherheitsregression.

`RED_TEAM_REPORT.md` bewahrt den historischen Befundstand für 0.3.0; `RED_TEAM_REPORT_REVIEW.md` enthält den historischen Follow-up für 0.3.1-review. Beide Berichte sind keine Prüfung dieser 0.4.9-Version. `PRIVACY_READINESS.md` dokumentiert Datenschutzgrenzen; `PILOT_STRATEGY.md` beschreibt den synthetischen Repository-Pilot. Eine vollständige externe Forensic Baseline ist in diesem ZIP nicht enthalten.

## Schlüsselstatus

`data/keys/ed25519-private.pem` ist in dieser Review-Kopie nicht vorhanden. Das vorhandene signierte Bundle bleibt mit dem eingebetteten öffentlichen Schlüssel verifizierbar. Ein neuer Build kann eine neue lokale Identität erzeugen; sie ist keine Fortsetzung der alten.

Das hochgeladene Gesamt-ZIP enthielt den aktiven privaten Schlüssel und ist kein öffentliches Release-Artefakt. Falls der Schlüssel reale Vertrauensbedeutung hatte, ist Rotation/Widerruf erforderlich.

## Checks

```bash
npm test
npm run sbom:verify
npm run export:pack
```

`npm run test:verify` prüft zusätzlich den Offline-Verifier mit gültigen, fehlenden und fehlerhaften Approval-Dateien. Wird ein Approval-Dateipfad ausdrücklich angegeben, muss die Datei lesbar und strukturell gültig sein; andernfalls schlägt die Gesamtprüfung fehl.

Die Tests sind lokal und synthetisch. Fremdsysteme, Login, institutionelle Rollen, Key-Store/HSM, Behörden-Schlüsselbereitstellung, Emergency-Control-Identitätsadapter, sicherer Remote-Transfer, Mehrmandantenbetrieb und externe Zeitstempel sind nicht geprüft.

## Herkunft und Aussagegrenze

`APOPHIS_2000_INPUT_TEST.md` dokumentiert den reproduzierten, begrenzten CBOR-Grenzwerttest aus dem historischen Apophis-Core-Quellstand. Er ist ausdrücklich kein Angriffstest und kein Sicherheitsnachweis für diese Preview-Version.

Das separat geprüfte historische Quellarchiv `Apophis-Evidence-Desk-v0.2.zip` wurde gegen den dokumentierten SHA-256-Digest `b97119e6f3afd1c8738a04b88fade98cd1ab3e8964ec3823e64e9e679bab0dfa` geprüft; es ist nicht Bestandteil dieser Review-Kopie.

Status: `PARTIALLY-VERIFIED` für eine lokale Single-Workspace-Demo. Keine Aussage zu DSGVO-Konformität, Authentifizierung, Organisationsautorisierung, Mandantentrennung, wissenschaftlicher Wahrheit, Sicherheits-/Wirksamkeitsnachweis, Zulassungsreife oder DURC-Freigabe.

---

**KaVa-14.10.26**
