# Synthetischer Repository-Pilot — Strategie

**Wasserzeichen:** KaVa-14.10.26  
**Status:** Plan; keine externe Instanz wurde kontaktiert.

## Ziel

Apophis als Evidence-Governance-Schicht testen, nicht als neues Repository. Der Pilot soll zeigen, ob ein synthetisches Evidence Bundle in einem Repository-Record abgelegt, wieder ausgelesen, versionsgebunden referenziert und als ersetzt/widerrufen markiert werden kann, ohne fremde Freigaben oder Evidenz stillschweigend aufzuwerten.

## Plattformwahl

Zuerst die Plattform wählen, für die ein institutionell verwalteter, isolierter Testmandant und verantwortliche technische Kontaktperson vorhanden sind. Falls beide Optionen gleich gut verfügbar sind, einen kurzen Proof-of-Contract je Plattform anhand derselben synthetischen Fixtures durchführen und den Adapter mit geringerem Rechteumfang und besserem Read-back/Versionierungsverhalten auswählen. Keine Produktionsinstanz und keine persönlichen Tokens im Repository verwenden.

## Minimaler Pilotumfang

- Ein künstlicher Datensatz, zwei Fake-Actors und keine realen Personen-, Gesundheits- oder Forschungsdaten.
- Separater Testmandant; kurzlebige, dedizierte Zugangsdaten mit minimalen Rechten, außerhalb des Repos und ZIPs gespeichert.
- Apophis exportiert ein Manifest mit Bundle-Hash, Schema-Version, Status, Quellreferenzen und Approval-Receipt; Repository-Datei bleibt die unveränderte Evidence-Payload.
- Read-back prüft Bytes und SHA-256 gegen den Export. Repository-Record-ID, Version und URL werden als Provenienz referenziert, nicht als Beweis wissenschaftlicher Wahrheit.
- Versionswechsel erzeugt eine neue Referenz mit `supersedes`; Widerruf markiert alten Record sichtbar und löscht nicht stillschweigend die Provenienz.

## Contract-Testfälle

1. Health-/Metadaten-Lesetest mit synthetischem Record.
2. Draft-Create und Datei-Upload; Abbruch-/Retry-Verhalten ohne doppelte Records.
3. Read-back mit Byte-/Hashvergleich; veränderte Datei muss fail-closed abgewiesen werden.
4. Neue Version und `supersedes`-Kette; alte Version bleibt nachvollziehbar.
5. Revoke/withdraw und fehlende Berechtigung; Fehler wird sichtbar und erzeugt keine lokale `ready`-Freigabe.
6. Netzwerkabbruch, Rate-Limit, ungültige Antwort und große Antwort; keine Geheimnisse in Logs oder Audit-Pack.

## Freigabekriterien

Alle Contract-Tests bestehen; Export/Read-back-Hashes stimmen; keine Geheimnisse oder personenbezogenen Daten im ZIP; minimale Rechte sind dokumentiert; Fehler und Revoke sind fail-closed; unabhängige Verantwortliche prüfen Datenschutz, Rollen, Schlüssel und Betrieb. Ein bestandener synthetischer Pilot ist kein Produktions- oder Datenschutzsiegel.

## Nicht im ersten Pilot

OIDC/SSO, institutionelle Rollenübernahme, automatische Claim-Aufwertung, News-Inbox, öffentliche Freigabe, mehrere Mandanten, Produktionsdaten und automatische Veröffentlichungen. Diese Funktionen benötigen eigene Risiko- und Freigabeschritte.
