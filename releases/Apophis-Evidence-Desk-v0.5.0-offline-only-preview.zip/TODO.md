# TODO / v0.3–v0.4

- [x] Stabile Ed25519-Identität mit Rotation-Log
- [x] Echte SHA-256-Referenzhashes über normalisierten Text + Abrufdatum
- [x] Offline-Verifier für Bundle und Approval-Chain
- [x] 2-Augen-Regel mit verschiedenen Actors und Rollen Author/Reviewer/Biosecurity
- [x] Sechs Claims mit Gegenclaim, Unsicherheit, Status und Evidenzbezug
- [x] Coverage-Matrix Plattform × Fragestellung
- [x] LLM-freier Scanner für Sequenz-, Protokoll- und Dosierungsdetailklassen
- [x] Audit-Pack ZIP-Export
- [x] Manueller Link-Rot-Check
- [ ] Geschützte Organisationsidentität statt selbst deklarierter Actor-Namen
- [x] Community-Capability-Profil, WebFinger-Discovery und did:web-Stub ohne Auto-Trust
- [x] Privates Projektmodell mit Retention, Mitgliedsrollen und opt-in External-Sync-Grenze
- [x] Lokale actor-scoped Datenschutz-Export-/Löschpfade als Readiness-Baustein
- [x] DNS-Rebinding-resistente Allowlist-/Resolve-/Pin-Connection-Schicht mit Redirect-Block
- [x] Interoperabilitätsprofil für OSF, Zenodo, Dataverse, InvenioRDM, C2PA/VC, Matrix und ActivityPub
- [x] Challenge-Response-Peer-Identifikation und record-only Gruppenkanal mit Replay-/Idempotency-Schutz
- [x] Maschinenlesbare Self-Description mit PID-/Metadata-Mapping und Trust-State-Modell
- [x] Zweckgebundene Trust-Registry mit Ablauf-/Widerrufsfeldern
- [x] Strukturierte Access-Requests mit Scope, Zweck, Datenklasse, Dauer und Export-Default false
- [x] Conformance-Selbsttest für europäische Anschlussbausteine
- [ ] Signaturen aus getrenntem Key-Store/HSM statt lokaler Datei
- [ ] Signierte, versionierte Volltext-Snapshots mit Provenienz
- [ ] Opt-in-Newsadapter mit Allowlist, Roh-Hash, Triage und sichtbarer Quellen-Grenze
- [x] PDF-Ausgabe als klar markierter Audit-Report
- [x] EU-Anwendbarkeitsprofil für DSGVO, AI Act, NIS2, CRA, eIDAS und EHDS
- [x] Fail-closed Trust-Registry-Invarianten im Conformance-Test
- [x] Disclosure-/Betriebsgrenze für mögliche CRA-/NIS2-Pilotierung
- [x] SHA-256 Release-Evidence-Manifest für Audit-Artefakte
- [x] Keyless Sigstore/Cosign-Signierung und Workflow-Identitätsverifikation für `main`
- [x] KRITIS-/High-Assurance-Reifeplan mit expliziten Nicht-Nachweisen
- [x] Content-addressed append-only WORM-like Evidence-Snapshots
- [x] Tenant-ID-Migration und serverseitige Cross-Tenant-Filter
- [x] HTTP-Test für fehlenden und fremden Tenant-Kontext

---

**KaVa-14.10.26**
