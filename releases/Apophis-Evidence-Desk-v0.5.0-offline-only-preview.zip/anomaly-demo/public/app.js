'use strict';
const $ = (id) => document.getElementById(id);
const status = $('status');
let parsedRows = [];
let originalHash = null;
function parseCsv(text) {
  const firstLine = text.split(/\r?\n/, 1)[0] || '';
  const delimiter = (firstLine.match(/;/g) || []).length > (firstLine.match(/,/g) || []).length ? ';' : ',';
  const rows = []; let row = []; let cell = ''; let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const c = text[i];
    if (quoted && c === '"' && text[i + 1] === '"') { cell += '"'; i += 1; }
    else if (c === '"') quoted = !quoted;
    else if (!quoted && c === delimiter) { row.push(cell); cell = ''; }
    else if (!quoted && (c === '\n' || c === '\r')) { if (c === '\r' && text[i + 1] === '\n') i += 1; row.push(cell); if (row.some((v) => v.trim())) rows.push(row); row = []; cell = ''; }
    else cell += c;
  }
  row.push(cell); if (row.some((v) => v.trim())) rows.push(row);
  if (rows.length < 2) throw new Error('CSV enthält keine Datenzeilen.');
  const headers = rows.shift().map((value) => value.replace(/^\uFEFF/, '').trim());
  return { headers, rows: rows.map((values) => Object.fromEntries(headers.map((header, index) => [header, values[index] || '']))) };
}
function populateSelect(select, headers) { select.replaceChildren(...headers.map((header) => { const option = document.createElement('option'); option.value = header; option.textContent = header; return option; })); }
$('file').addEventListener('change', async () => {
  status.textContent = ''; const file = $('file').files[0]; if (!file) return;
  try {
    const text = await file.text(); const parsed = parseCsv(text); parsedRows = parsed.rows;
    populateSelect($('timecol'), parsed.headers); populateSelect($('valuecol'), parsed.headers);
    populateSelect($('timeextra'), parsed.headers); const none = document.createElement('option'); none.value = ''; none.textContent = 'Keine'; $('timeextra').prepend(none); $('timeextra').value = '';
    const timeGuess = parsed.headers.find((h) => /time|datum|date|timestamp|uhrzeit/i.test(h));
    const valGuess = parsed.headers.find((h) => /wert|value|netzlast|verbrauch|traffic|bytes|leistung/i.test(h));
    const timeOnlyGuess = parsed.headers.find((h) => /^uhrzeit$/i.test(h));
    const dateOnlyGuess = parsed.headers.find((h) => /^datum$/i.test(h));
    if (timeGuess) $('timecol').value = timeGuess; if (valGuess) $('valuecol').value = valGuess;
    if (timeOnlyGuess && dateOnlyGuess) { $('timecol').value = dateOnlyGuess; $('timeextra').value = timeOnlyGuess; }
    originalHash = await crypto.subtle.digest('SHA-256', await file.arrayBuffer()).then((hash) => [...new Uint8Array(hash)].map((b) => b.toString(16).padStart(2, '0')).join(''));
    $('import').disabled = false; status.textContent = `${parsed.rows.length} Datenzeilen geladen. Datei bleibt lokal.`;
  } catch (error) { status.textContent = error.message; }
});
function parseNumber(value) { const normalized = String(value).trim().replace(/\s/g, '').replace(/\.(?=\d{3}(?:\D|$))/g, '').replace(',', '.'); const n = Number(normalized); return Number.isFinite(n) ? n : NaN; }
function parseTimestamp(row, timeColumn, extraColumn = '') {
  const raw = [row[timeColumn], extraColumn ? row[extraColumn] : ''].filter(Boolean).join(' ').trim();
  let date = new Date(raw);
  if (!Number.isFinite(date.getTime())) {
    const match = raw.match(/^(\d{1,2})[./](\d{1,2})[./](\d{2,4})(?:\s+(\d{1,2}):(\d{2}))?$/);
    if (match) date = new Date(Number(match[3].length === 2 ? `20${match[3]}` : match[3]), Number(match[2]) - 1, Number(match[1]), Number(match[4] || 0), Number(match[5] || 0));
  }
  return Number.isFinite(date.getTime()) ? date.toISOString() : null;
}
async function postJson(url, body, method = 'POST') {
  const response = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), cache: 'no-store' });
  const data = await response.json(); if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`); return data;
}
$('import').addEventListener('click', async () => {
  try {
    const timeCol = $('timecol').value, timeExtra = $('timeextra').value, valueCol = $('valuecol').value;
    const points = parsedRows.map((row) => ({ timestamp: parseTimestamp(row, timeCol, timeExtra), value: parseNumber(row[valueCol]) })).filter((p) => p.timestamp && Number.isFinite(p.value));
    const result = await postJson('/api/series', { series_id: $('seriesid').value, metric: $('metric').value, unit: $('unit').value, source: $('source').value, source_url: $('sourceurl').value, original_file_sha256: originalHash, points });
    status.textContent = `${result.points_count} Messpunkte importiert. ${result.analysis.alerts.length} Prüfhinweis(e). Quelle wurde nicht unabhängig verifiziert.`; await refresh();
  } catch (error) { status.textContent = error.message; }
});
$('savepolicy').addEventListener('click', async () => {
  try {
    const policy = { window_size: Number($('window').value), min_history: Number($('history').value), mad_multiplier: Number($('mad').value), absolute_tolerance: Number($('absolute').value), relative_tolerance_percent: Number($('relative').value), min_consecutive: Number($('consecutive').value) };
    await postJson('/api/policy', policy, 'PUT'); status.textContent = 'Toleranzparameter lokal übernommen.'; await refresh();
  } catch (error) { status.textContent = error.message; }
});
$('synthetic').addEventListener('click', async () => {
  const now = Date.now(); const points = [];
  for (let i = 0; i < 96; i += 1) { const daily = 180 + 22 * Math.sin((i % 24) / 24 * Math.PI * 2); const noise = ((i * 37) % 11 - 5) * 1.4; const spike = i >= 76 && i <= 78 ? 115 : 0; points.push({ timestamp: new Date(now - (95 - i) * 3600000).toISOString(), value: Math.round((daily + noise + spike) * 100) / 100 }); }
  try { const result = await postJson('/api/series', { series_id: 'synthetic-demo', metric: 'Beispiel-Netzwerkdurchsatz', unit: 'Mbit/s', source: 'Synthetisches Demo-Beispiel', source_url: '', points }); status.textContent = `Synthetische Daten geladen: ${result.points_count} Punkte. Diese Werte sind erfunden und kein realer Angriff.`; await refresh(); } catch (error) { status.textContent = error.message; }
});
function renderSeries(series) {
  const root = $('results'); root.replaceChildren();
  if (!series.length) { root.textContent = 'Noch keine Zeitreihe importiert. Für reale öffentliche Stromdaten CSV bei SMARD laden; für reale Netzwerkdaten einen freigegebenen aggregierten Export lokal importieren.'; return; }
  for (const item of series) {
    const article = document.createElement('article'); article.className = item.analysis.alerts.length ? 'alert' : 'clear';
    const h = document.createElement('h3'); h.textContent = `${item.metric} · ${item.series_id}`; article.append(h);
    const meta = document.createElement('p'); meta.textContent = `${item.points_count} Messpunkte · ${item.unit} · Quelle: ${item.source} · Import ${item.imported_at}`; article.append(meta);
    const provenance = document.createElement('p'); provenance.className = 'muted'; provenance.textContent = `Quellhinweis: ${item.provenance_note} · Dateihash: ${item.source_file_sha256 || 'nicht vorhanden'}`; article.append(provenance);
    const label = document.createElement('p'); label.className = item.analysis.alerts.length ? 'warning' : ''; label.textContent = item.analysis.alerts.length ? `${item.analysis.alerts.length} Prüfhinweis(e) — mögliche Abweichung, kein Angriffsnachweis.` : 'Keine Abweichung nach aktueller Toleranz erkannt. Das beweist nicht, dass kein Vorfall vorliegt.'; article.append(label);
    for (const alert of item.analysis.alerts) { const p = document.createElement('p'); p.textContent = `${alert.started_at} bis ${alert.ended_at}: ${alert.samples} aufeinanderfolgende Punkte ${alert.direction === 'above' ? 'über' : 'unter'} der Baseline, max. ${alert.max_deviation_ratio.toFixed(2)}× Toleranz.`; article.append(p); }
    const table = document.createElement('table'); const head = document.createElement('tr'); for (const name of ['Zeit', 'Messwert', 'Median-Baseline', 'Toleranz', 'Abweichung']) { const th = document.createElement('th'); th.textContent = name; head.append(th); } table.append(head);
    for (const point of item.analysis.samples.slice(-12).reverse()) { const tr = document.createElement('tr'); for (const value of [point.timestamp, point.value, point.baseline_median.toFixed(3), point.tolerance.toFixed(3), point.deviation.toFixed(3)]) { const td = document.createElement('td'); td.textContent = String(value); tr.append(td); } table.append(tr); }
    article.append(table);
    const remove = document.createElement('button'); remove.textContent = 'Zeitreihe lokal löschen'; remove.addEventListener('click', async () => { await fetch(`/api/series/${encodeURIComponent(item.series_id)}`, { method: 'DELETE' }); await refresh(); }); article.append(remove);
    root.append(article);
  }
}
async function refresh() {
  try { const [seriesResponse, policyResponse] = await Promise.all([fetch('/api/series', { cache: 'no-store' }), fetch('/api/policy', { cache: 'no-store' })]); const series = await seriesResponse.json(); const { policy } = await policyResponse.json(); $('window').value = policy.window_size; $('history').value = policy.min_history; $('mad').value = policy.mad_multiplier; $('absolute').value = policy.absolute_tolerance; $('relative').value = policy.relative_tolerance_percent; $('consecutive').value = policy.min_consecutive; renderSeries(series.series || []); } catch (error) { status.textContent = `Lokaler Analysedienst nicht erreichbar: ${error.message}`; }
}
refresh();
