// KaVa-14.10.26 — review watermark
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { scan } = require('./scripts/biosecurity');
const { assertLoopbackHost } = require('./scripts/network-policy');
const { tenantContext, tenantMatches, validTenantId } = require('./scripts/tenant-policy');
const { appendSnapshot, verifyNamespace } = require('./scripts/worm-evidence-store');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '127.0.0.1';
try { assertLoopbackHost(HOST, 'apophis'); } catch (error) { console.error(error.message); process.exit(1); }
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const APPROVALS = path.join(ROOT, 'data', 'approvals.json');
const BUNDLE = path.join(ROOT, 'data', 'evidence-bundle.json');
const COMMUNITY = path.join(ROOT, 'data', 'community.json');
const PROJECTS = path.join(ROOT, 'data', 'projects.json');
const PRIVACY = path.join(ROOT, 'data', 'privacy-policy.json');
const GROUPS = path.join(ROOT, 'data', 'groups.json');
const GROUP_EXCHANGES = path.join(ROOT, 'data', 'group-exchanges.json');
const TRUST = path.join(ROOT, 'data', 'trust-registry.json');
const ACCESS_REQUESTS = path.join(ROOT, 'data', 'access-requests.json');
const SELF_DESCRIPTION = path.join(ROOT, 'data', 'self-description.json');
const WORM_ROOT = path.join(ROOT, 'data', 'worm-evidence');
const EMERGENCY_LOCK = path.join(ROOT, 'data', 'emergency-control', 'lock.json');
const HANDSHAKES = new Map();
const ZERO_HASH = '0'.repeat(64);
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml' };

function canonicalDeep(value) {
  if (Array.isArray(value)) return `[${value.map(canonicalDeep).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalDeep(value[key])}`).join(',')}}`;
  return JSON.stringify(value);
}
function digest(value) { return crypto.createHash('sha256').update(canonicalDeep(value)).digest('hex'); }
function readJson(file, fallback) {
  let text;
  try { text = fs.readFileSync(file, 'utf8'); }
  catch (error) { if (error.code === 'ENOENT') return fallback; throw error; }
  try { return JSON.parse(text); }
  catch (_) { const error = new Error('stored_json_invalid'); error.code = 'stored_json_invalid'; throw error; }
}
function writeJsonAtomic(file, value) {
  const temp = `${file}.tmp-${process.pid}`;
  fs.writeFileSync(temp, JSON.stringify(value, null, 2) + '\n', { mode: 0o600 });
  fs.renameSync(temp, file);
}
function requestTenant(req) { return tenantContext(req); }
function tenantError(error) { return ['invalid_tenant_context', 'tenant_context_required', 'tenant_context_untrusted'].includes(error.message); }
function writeWormSnapshot(namespace, payload, metadata) { return appendSnapshot(WORM_ROOT, namespace, payload, metadata); }
function publicOrigin(req) { return (process.env.APOPHIS_PUBLIC_ORIGIN || `http://${req.headers.host || '127.0.0.1:3000'}`).replace(/\/$/, ''); }
function communityDocument(req) {
  const origin = publicOrigin(req); const community = readJson(COMMUNITY, {});
  return { ...community, origin, discovery: `${origin}/api/capabilities`, manifest: `${origin}/.well-known/apophis-community.json`, generated_for: 'this-origin' };
}
function capabilities(req) {
  const origin = publicOrigin(req);
  return { schema: 'apophis/capabilities/v1', service: 'apophis-evidence-desk', origin, system_identity: publicSystemIdentity(req), self_description: `${origin}/.well-known/apophis-self-description.json`, community: `${origin}/.well-known/apophis-community.json`, webfinger: `${origin}/.well-known/webfinger`, did: process.env.APOPHIS_PUBLIC_ORIGIN?.startsWith('https://') ? `${origin}/.well-known/did.json` : null, protocols: { discovery: ['webfinger', 'well-known'], exchange: ['apophis-evidence/v1', 'json'], federation: ['activitypub-compatible-discovery', 'matrix-compatible-discovery'], group_handshake: ['challenge-response-ed25519/v1'], group_exchange: ['structured-record-only/v1'], metadata: ['apophis-metadata/v1', 'DataCite', 'DCAT', 'Schema.org', 'OpenAIRE'] }, adapters: ['osf', 'zenodo', 'dataverse', 'invenio-rdm', 'c2pa-compatible-provenance'], project_api: ['/api/projects', '/api/projects/:id'], group_api: ['/api/groups', '/api/federation/challenge', '/api/federation/hello', '/api/groups/:id/exchanges'], trust_api: ['/api/trust/registry'], access_api: ['/api/access-requests', '/api/access-requests/:id/decision'], metadata_api: ['/api/metadata/record/:id'], privacy_api: ['/api/privacy/export', '/api/privacy/erase'], policy: { import: 'record-only-no-auto-approval', external_sync: 'opt-in', delivery: 'disabled-by-default', identified_is_not_trusted: true, access_export_default: false } };
}
function actorFilter(value) { return typeof value === 'string' && value.trim() && value.length <= 120 ? value.trim() : null; }
function rebuildApprovalChain(records) {
  const previousByTenant = new Map();
  const rebuilt = records.map((record) => {
    if (!validTenantId(record.tenant_id)) throw new Error('approval_tenant_missing_or_invalid');
    const previous = previousByTenant.get(record.tenant_id) || ZERO_HASH;
    const unsigned = { ...record, prev_hash: previous }; delete unsigned.record_hash;
    const next = { ...unsigned, record_hash: digest(unsigned) };
    previousByTenant.set(record.tenant_id, next.record_hash);
    return next;
  });
  return { schema: 'apophis/approval-log/v1', records: rebuilt, chain_head: rebuilt.at(-1)?.record_hash || ZERO_HASH };
}
function isAcceptablePeerOrigin(value) {
  try { const url = new URL(value); return url.protocol === 'https:' || (url.protocol === 'http:' && ['localhost', '127.0.0.1', '::1'].includes(url.hostname)); } catch (_) { return false; }
}
function publicSystemIdentity(req) {
  const origin = publicOrigin(req); const bundle = readJson(BUNDLE, {});
  return { system_id: 'apophis-local-demo', origin, community_id: readJson(COMMUNITY, {}).community_id, identity_fingerprint: bundle.identity?.active_fingerprint || null, verification: 'signature-required-for-peer-identification' };
}
function selfDescription(req) { const origin = publicOrigin(req); return { ...readJson(SELF_DESCRIPTION, {}), service_id: 'apophis-local-demo', origin, capabilities_url: `${origin}/api/capabilities`, community_url: `${origin}/.well-known/apophis-community.json`, identity: publicSystemIdentity(req) }; }
function validIsoDate(value) { return typeof value === 'string' && Number.isFinite(Date.parse(value)); }
function send(res, status, body, type = 'application/json; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; base-uri 'self'; form-action 'self'" });
  if (Buffer.isBuffer(body) || typeof body === 'string') return res.end(body);
  return res.end(JSON.stringify(body));
}
function unsignedBundle(bundle) { const copy = { ...bundle }; delete copy.receipt; delete copy.signature; return copy; }
function verifyBundle(bundle) {
  try {
    const unsigned = unsignedBundle(bundle);
    const receiptOk = bundle.receipt?.algorithm === 'SHA-256' && bundle.receipt.bundle_hash === digest(unsigned);
    const publicKey = crypto.createPublicKey({ key: Buffer.from(bundle.signature.public_key_spki_der_base64, 'base64'), type: 'spki', format: 'der' });
    const signatureOk = bundle.signature.algorithm === 'Ed25519' && crypto.verify(null, Buffer.from(canonicalDeep(unsigned)), publicKey, Buffer.from(bundle.signature.value_base64, 'base64'));
    const fingerprint = crypto.createHash('sha256').update(Buffer.from(bundle.signature.public_key_spki_der_base64, 'base64')).digest('hex');
    const identityOk = !bundle.identity?.active_fingerprint || bundle.identity.active_fingerprint === fingerprint;
    return { valid: receiptOk && signatureOk && identityOk, receipt_ok: receiptOk, signature_ok: signatureOk, identity_ok: identityOk, bundle_hash: bundle.receipt?.bundle_hash || null };
  } catch (_) { return { valid: false, receipt_ok: false, signature_ok: false, bundle_hash: null }; }
}
function verifyApprovals(log, expectedBundleHash = null) {
  if (!log || !Array.isArray(log.records)) return false;
  const previousByTenant = new Map();
  for (const record of log.records || []) {
    if (!validTenantId(record.tenant_id)) return false;
    const previous = previousByTenant.get(record.tenant_id) || ZERO_HASH;
    const unsigned = { ...record }; delete unsigned.record_hash;
    if (!record.record_id || !record.created_at || !record.actor || !['author', 'reviewer', 'biosecurity'].includes(record.role) || !['approve', 'reject', 'escalate'].includes(record.decision) || !record.rationale || record.scope !== 'bundle-hcmv-demo-001' || (expectedBundleHash && record.bundle_hash !== expectedBundleHash) || record.prev_hash !== previous || record.record_hash !== digest(unsigned)) return false;
    previousByTenant.set(record.tenant_id, record.record_hash);
  }
  return (log.records.at(-1)?.record_hash || ZERO_HASH) === (log.chain_head || ZERO_HASH);
}
function approvalStatus(log, expectedBundleHash, tenantId) {
  const visibleRecords = (log.records || []).filter((record) => record.tenant_id === tenantId);
  const approvals = visibleRecords.filter((r) => r.decision === 'approve');
  const actors = new Set(approvals.map((r) => r.actor));
  const roles = new Set(approvals.map((r) => r.role));
  const required = ['author', 'reviewer', 'biosecurity'];
  const chainOk = verifyApprovals(log, expectedBundleHash);
  const blockingRecords = visibleRecords.filter((r) => ['reject', 'escalate'].includes(r.decision));
  const blockingDecisions = [...new Set(blockingRecords.map((r) => r.decision))];
  return { valid_chain: chainOk, approval_count: approvals.length, distinct_actors: actors.size, roles: [...roles], required_roles: required, two_person_rule: approvals.length >= 2 && actors.size >= 2, role_separation: required.every((role) => roles.has(role)), blocking_decision_count: blockingRecords.length, blocking_decisions: blockingDecisions, ready: chainOk && approvals.length >= 2 && actors.size >= 2 && required.every((role) => roles.has(role)) && blockingRecords.length === 0 };
}
function readBody(req) { return new Promise((resolve, reject) => { let total = 0; const chunks = []; req.on('data', (chunk) => { total += chunk.length; if (total > 30000) { reject(new Error('body_too_large')); req.destroy(); return; } chunks.push(chunk); }); req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8'))); req.on('error', reject); }); }
function appendApproval(payload) {
  const log = readJson(APPROVALS, { schema: 'apophis/approval-log/v1', records: [], chain_head: ZERO_HASH });
  if (!verifyApprovals(log)) throw new Error('approval_log_integrity_failed');
  const actor = typeof payload.actor === 'string' ? payload.actor.trim() : '';
  const role = typeof payload.role === 'string' ? payload.role : '';
  const decision = typeof payload.decision === 'string' ? payload.decision : '';
  const rationale = typeof payload.rationale === 'string' ? payload.rationale.trim() : '';
  if (!actor || actor.length > 120 || !['author', 'reviewer', 'biosecurity'].includes(role) || !['approve', 'reject', 'escalate'].includes(decision) || !rationale || rationale.length > 2000) throw new Error('invalid_approval');
  const tenantId = payload.tenant_id;
  if (!validTenantId(tenantId)) throw new Error('invalid_tenant_context');
  if (decision === 'approve' && (log.records || []).some((r) => r.tenant_id === tenantId && r.decision === 'approve' && r.actor === actor)) throw new Error('independent_actor_required');
  const previous = [...(log.records || [])].reverse().find((record) => record.tenant_id === tenantId)?.record_hash || ZERO_HASH;
  const record = { record_id: `approval-${crypto.randomBytes(8).toString('hex')}`, tenant_id: tenantId, created_at: new Date().toISOString(), actor, role, decision, rationale, scope: 'bundle-hcmv-demo-001', bundle_hash: readJson(BUNDLE, {}).receipt?.bundle_hash || null, prev_hash: previous };
  record.record_hash = digest(record);
  log.records.push(record); log.chain_head = record.record_hash;
  writeWormSnapshot('approvals', record, { source: 'appendApproval', tenant_id: tenantId });
  const temp = `${APPROVALS}.tmp-${process.pid}`; fs.writeFileSync(temp, JSON.stringify(log, null, 2) + '\n', { mode: 0o600 }); fs.renameSync(temp, APPROVALS);
  return record;
}
async function serve(req, res) {
  const requested = decodeURIComponent((req.url || '/').split('?')[0]);
  const query = new URL(req.url || '/', 'http://localhost').searchParams;
  // Application-only fail-closed lock. It does not stop the host, network, or OT equipment.
  if (fs.existsSync(EMERGENCY_LOCK)) return send(res, 503, { error: 'emergency_lock_active', service_scope: 'apophis_application_only', release: 'two_person_authorization_required' });
  if (requested === '/health' && req.method === 'GET') return send(res, 200, { ok: true, service: 'apophis-evidence-desk', mode: 'localhost-only', bundle: verifyBundle(readJson(BUNDLE, {})).valid });
  if (requested === '/api/capabilities' && req.method === 'GET') return send(res, 200, capabilities(req));
  if (requested === '/.well-known/apophis-self-description.json' && req.method === 'GET') return send(res, 200, selfDescription(req));
  if (requested === '/api/trust/registry' && req.method === 'GET') return send(res, 200, readJson(TRUST, { schema: 'apophis/trust-registry/v1', entries: [] }));
  if (requested === '/api/trust/registry' && req.method === 'POST') {
    try {
      const body = JSON.parse(await readBody(req)); const states = new Set(['discovered', 'cryptographically-identified', 'organisation-verified', 'community-member', 'project-authorised', 'trusted-for-specific-purpose', 'revoked']); const peerId = typeof body.peer_id === 'string' ? body.peer_id.trim() : ''; const communityId = typeof body.community_id === 'string' ? body.community_id.trim() : ''; const purpose = typeof body.purpose === 'string' ? body.purpose.trim() : '';
      if (!peerId || peerId.length > 160 || !communityId || !states.has(body.state) || !validIsoDate(body.expires_at) || body.state === 'trusted-for-specific-purpose' && !purpose) return send(res, 400, { error: 'invalid_trust_entry' });
      const store = readJson(TRUST, { schema: 'apophis/trust-registry/v1', entries: [] }); const entry = { peer_id: peerId, community_id: communityId, state: body.state, purpose: purpose || null, purposes: Array.isArray(body.purposes) ? body.purposes.slice(0, 20) : (purpose ? [purpose] : []), expires_at: body.expires_at, evidence_refs: Array.isArray(body.evidence_refs) ? body.evidence_refs.slice(0, 20) : [], revoked: body.state === 'revoked', updated_at: new Date().toISOString() };
      store.entries = (store.entries || []).filter((item) => item.peer_id !== peerId); store.entries.push(entry); writeJsonAtomic(TRUST, store); return send(res, 201, { entry, policy: 'purpose-bound-explicit-membership' });
    } catch (error) { return send(res, 400, { error: error.message === 'body_too_large' ? error.message : 'invalid_trust_request' }); }
  }
  if (requested === '/api/federation/challenge' && req.method === 'POST') {
    const now = Date.now(); const challenge = { challenge_id: `challenge-${crypto.randomBytes(12).toString('hex')}`, challenge: crypto.randomBytes(32).toString('base64url'), audience: publicOrigin(req), issued_at: new Date(now).toISOString(), expires_at: new Date(now + 120000).toISOString(), protocol: 'challenge-response-ed25519/v1' };
    HANDSHAKES.set(challenge.challenge_id, { ...challenge, used: false });
    if (HANDSHAKES.size > 128) HANDSHAKES.delete(HANDSHAKES.keys().next().value);
    return send(res, 201, { ...challenge, system: publicSystemIdentity(req), trust_state: 'challenge-issued' });
  }
  if (requested === '/api/federation/hello' && req.method === 'POST') {
    try {
      const hello = JSON.parse(await readBody(req)); const challenge = HANDSHAKES.get(hello.challenge_id);
      if (!challenge || challenge.used || challenge.challenge !== hello.challenge || challenge.audience !== hello.audience || Date.parse(challenge.expires_at) < Date.now() || !hello.community_id || !hello.system_id || !isAcceptablePeerOrigin(hello.origin) || typeof hello.public_key_spki_der_base64 !== 'string' || typeof hello.signature_base64 !== 'string') return send(res, 401, { error: 'peer_identification_failed', trust_state: 'unidentified' });
      const unsigned = { ...hello }; delete unsigned.signature_base64;
      const publicKey = crypto.createPublicKey({ key: Buffer.from(hello.public_key_spki_der_base64, 'base64'), type: 'spki', format: 'der' });
      const signatureOk = crypto.verify(null, Buffer.from(canonicalDeep(unsigned)), publicKey, Buffer.from(hello.signature_base64, 'base64'));
      if (!signatureOk) return send(res, 401, { error: 'peer_signature_invalid', trust_state: 'unidentified' });
      challenge.used = true; const fingerprint = crypto.createHash('sha256').update(Buffer.from(hello.public_key_spki_der_base64, 'base64')).digest('hex');
      return send(res, 200, { handshake_id: challenge.challenge_id, peer: { system_id: hello.system_id, community_id: hello.community_id, origin: hello.origin, fingerprint }, trust_state: 'identified-not-trusted', next: 'explicit-membership-and-project-policy-required' });
    } catch (error) { return send(res, 400, { error: error.message === 'body_too_large' ? error.message : 'invalid_peer_hello', trust_state: 'unidentified' }); }
  }
  if (requested === '/.well-known/apophis-community.json' && req.method === 'GET') return send(res, 200, communityDocument(req));
  if (requested === '/.well-known/webfinger' && req.method === 'GET') {
    const resource = query.get('resource') || '';
    const origin = publicOrigin(req); const subject = `acct:community@${new URL(origin).hostname}`;
    if (resource !== subject && resource !== `${origin}/.well-known/apophis-community.json`) return send(res, 404, { error: 'resource_not_found' });
    return send(res, 200, { subject, aliases: [`${origin}/.well-known/apophis-community.json`], links: [{ rel: 'self', type: 'application/json', href: `${origin}/.well-known/apophis-community.json` }, { rel: 'http://spec.apophis.dev/rel/community', type: 'application/json', href: `${origin}/api/capabilities` }] });
  }
  if (requested === '/.well-known/did.json' && req.method === 'GET') {
    const origin = publicOrigin(req); if (!origin.startsWith('https://')) return send(res, 404, { error: 'public_https_origin_required' });
    const did = `did:web:${new URL(origin).hostname}`;
    return send(res, 200, { '@context': ['https://www.w3.org/ns/did/v1'], id: did, verificationMethod: [], authentication: [], assertionMethod: [], service: [{ id: `${did}#community`, type: 'ApophisCommunityDiscovery', serviceEndpoint: `${origin}/.well-known/apophis-community.json` }], note: 'Discovery key material must be configured before production use.' });
  }
  if (requested === '/api/privacy/policy' && req.method === 'GET') return send(res, 200, readJson(PRIVACY, {}));
  if (requested === '/api/projects' && req.method === 'GET') {
    try { const context = requestTenant(req); const store = readJson(PROJECTS, { schema: 'apophis/projects/v1', projects: [] }); return send(res, 200, { ...store, projects: (store.projects || []).filter((project) => tenantMatches(project, context)) }); }
    catch (error) { return send(res, tenantError(error) ? 401 : 500, { error: tenantError(error) ? error.message : 'project_store_unavailable' }); }
  }
  if (requested === '/api/groups' && req.method === 'GET') {
    try { const context = requestTenant(req); const store = readJson(GROUPS, { schema: 'apophis/groups/v1', groups: [] }); return send(res, 200, { ...store, groups: (store.groups || []).filter((group) => tenantMatches(group, context)) }); }
    catch (error) { return send(res, tenantError(error) ? 401 : 500, { error: tenantError(error) ? error.message : 'group_store_unavailable' }); }
  }
  if (requested.startsWith('/api/groups/') && requested.endsWith('/exchanges') && req.method === 'POST') {
    try {
      const context = requestTenant(req); const groupId = requested.slice('/api/groups/'.length, -'/exchanges'.length); const body = JSON.parse(await readBody(req)); const groups = readJson(GROUPS, { groups: [] }); const group = (groups.groups || []).find((item) => item.id === groupId && tenantMatches(item, context));
      const kind = body.kind; const allowedKinds = new Set(['evidence_bundle_ref', 'project_update', 'review_request']); const peerId = typeof body.peer_id === 'string' ? body.peer_id.trim() : ''; const handshakeId = typeof body.handshake_id === 'string' ? body.handshake_id.trim() : ''; const key = typeof body.idempotency_key === 'string' ? body.idempotency_key.trim() : '';
      if (!group || !allowedKinds.has(kind) || !peerId || peerId.length > 160 || !handshakeId || !HANDSHAKES.has(handshakeId) || !body.payload || typeof body.payload !== 'object' || Array.isArray(body.payload) || JSON.stringify(body.payload).length > 12000) return send(res, 400, { error: 'invalid_group_exchange', status: 'not-recorded' });
      const store = readJson(GROUP_EXCHANGES, { schema: 'apophis/group-exchanges/v1', records: [] });
      if (key && (store.records || []).some((record) => record.tenant_id === context.tenant_id && record.group_id === groupId && record.idempotency_key === key)) return send(res, 200, { duplicate: true, record: store.records.find((record) => record.tenant_id === context.tenant_id && record.group_id === groupId && record.idempotency_key === key) });
      const record = { id: `exchange-${crypto.randomBytes(8).toString('hex')}`, tenant_id: context.tenant_id, group_id: groupId, peer_id: peerId, handshake_id: handshakeId, idempotency_key: key || null, kind, payload: body.payload, received_at: new Date().toISOString(), status: 'received-needs-review' };
      store.records.push(record); writeWormSnapshot('group-exchanges', record, { tenant_id: context.tenant_id, source: 'api/groups/exchanges' }); writeJsonAtomic(GROUP_EXCHANGES, store); return send(res, 201, { record, policy: 'record-only-no-auto-approval' });
    } catch (error) { return send(res, tenantError(error) ? 401 : 400, { error: tenantError(error) ? error.message : (error.message === 'body_too_large' ? error.message : 'invalid_group_exchange_request') }); }
  }
  if (requested === '/api/projects' && req.method === 'POST') {
    try {
      const context = requestTenant(req); const body = JSON.parse(await readBody(req)); const name = typeof body.name === 'string' ? body.name.trim() : ''; const purpose = typeof body.purpose === 'string' ? body.purpose.trim() : '';
      const retention = Number(body.retention_days || 90);
      if (!name || name.length > 160 || !purpose || purpose.length > 1000 || !Number.isInteger(retention) || retention < 1 || retention > 3650) return send(res, 400, { error: 'invalid_project' });
      const store = readJson(PROJECTS, { schema: 'apophis/projects/v1', projects: [] });
      const project = { id: `project-${crypto.randomBytes(8).toString('hex')}`, tenant_id: context.tenant_id, name, purpose, created_at: new Date().toISOString(), visibility: 'private', retention_days: retention, members: [], bundle_ids: [], external_links: [], status: 'review-required' };
      store.projects.push(project); writeWormSnapshot('projects', project, { tenant_id: context.tenant_id, source: 'api/projects' }); writeJsonAtomic(PROJECTS, store); return send(res, 201, { project, policy: 'private-by-default; external-sync-opt-in' });
    } catch (error) { return send(res, tenantError(error) ? 401 : 400, { error: tenantError(error) ? error.message : (error.message === 'body_too_large' ? error.message : 'invalid_project_request') }); }
  }
  if (requested.startsWith('/api/projects/') && req.method === 'GET') {
    try { const context = requestTenant(req); const id = requested.slice('/api/projects/'.length); const store = readJson(PROJECTS, { projects: [] }); const project = (store.projects || []).find((item) => item.id === id && tenantMatches(item, context)); return project ? send(res, 200, project) : send(res, 404, { error: 'project_not_found' }); }
    catch (error) { return send(res, tenantError(error) ? 401 : 500, { error: tenantError(error) ? error.message : 'project_store_unavailable' }); }
  }
  if (requested === '/api/access-requests' && req.method === 'GET') {
    try { const context = requestTenant(req); const store = readJson(ACCESS_REQUESTS, { schema: 'apophis/access-requests/v1', requests: [] }); return send(res, 200, { ...store, requests: (store.requests || []).filter((request) => tenantMatches(request, context)) }); }
    catch (error) { return send(res, tenantError(error) ? 401 : 500, { error: tenantError(error) ? error.message : 'access_store_unavailable' }); }
  }
  if (requested === '/api/access-requests' && req.method === 'POST') {
    try {
      const context = requestTenant(req); const body = JSON.parse(await readBody(req)); const requester = actorFilter(body.requester); const organization = typeof body.organization === 'string' ? body.organization.trim() : ''; const purpose = typeof body.purpose === 'string' ? body.purpose.trim() : ''; const dataClass = typeof body.data_class === 'string' ? body.data_class.trim() : ''; const legalNote = typeof body.legal_basis_or_review_note === 'string' ? body.legal_basis_or_review_note.trim() : '';
      if (!requester || !organization || organization.length > 200 || !purpose || purpose.length > 2000 || !dataClass || !legalNote || !validIsoDate(body.requested_until) || !body.scope || typeof body.scope !== 'object' || Array.isArray(body.scope)) return send(res, 400, { error: 'invalid_access_request' });
      const store = readJson(ACCESS_REQUESTS, { schema: 'apophis/access-requests/v1', requests: [] }); const request = { id: `access-${crypto.randomBytes(8).toString('hex')}`, tenant_id: context.tenant_id, requester, organization, purpose, scope: body.scope, data_class: dataClass, legal_basis_or_review_note: legalNote, requested_until: body.requested_until, export_allowed: body.export_allowed === true, status: 'submitted', decisions: [], created_at: new Date().toISOString() };
      store.requests.push(request); writeWormSnapshot('access-requests', request, { tenant_id: context.tenant_id, source: 'api/access-requests' }); writeJsonAtomic(ACCESS_REQUESTS, store); return send(res, 201, { request, policy: 'purpose-bound-human-review-required' });
    } catch (error) { return send(res, tenantError(error) ? 401 : 400, { error: tenantError(error) ? error.message : (error.message === 'body_too_large' ? error.message : 'invalid_access_request_payload') }); }
  }
  if (requested.startsWith('/api/access-requests/') && requested.endsWith('/decision') && req.method === 'POST') {
    try {
      const context = requestTenant(req); const id = requested.slice('/api/access-requests/'.length, -'/decision'.length); const body = JSON.parse(await readBody(req)); const reviewer = actorFilter(body.reviewer); const allowed = new Set(['approved', 'rejected', 'requires-more-info', 'revoked']);
      if (!reviewer || !allowed.has(body.decision) || typeof body.rationale !== 'string' || !body.rationale.trim()) return send(res, 400, { error: 'invalid_access_decision' });
      const store = readJson(ACCESS_REQUESTS, { schema: 'apophis/access-requests/v1', requests: [] }); const request = (store.requests || []).find((item) => item.id === id && tenantMatches(item, context)); if (!request) return send(res, 404, { error: 'access_request_not_found' });
      request.status = body.decision; request.decisions.push({ reviewer, decision: body.decision, rationale: body.rationale.trim().slice(0, 2000), decided_at: new Date().toISOString() }); writeWormSnapshot('access-requests', request, { tenant_id: context.tenant_id, source: 'api/access-requests/decision' }); writeJsonAtomic(ACCESS_REQUESTS, store); return send(res, 200, { request, policy: 'decision-is-purpose-bound-not-general-approval' });
    } catch (error) { return send(res, tenantError(error) ? 401 : 400, { error: tenantError(error) ? error.message : (error.message === 'body_too_large' ? error.message : 'invalid_access_decision_payload') }); }
  }
  if (requested.startsWith('/api/metadata/record/') && req.method === 'GET') {
    const id = requested.slice('/api/metadata/record/'.length); const bundle = readJson(BUNDLE, {}); if (id !== bundle.bundle_id) return send(res, 404, { error: 'record_not_found' });
    return send(res, 200, { schema: 'apophis/record/v1', record_id: bundle.bundle_id, version: bundle.profile_version, created_at: bundle.created_at, status: 'review-required', project_id: 'project-hcmv-demo-001', organization_id: 'unconfigured', access_class: 'private-synthetic', purpose: 'evidence-governance-demo', retention: { days: 90, review_before_expiry: true }, pids: { doi: null, orcid: [], ror: null, handle: null, grant_id: null }, mappings: { datacite: true, dcat: true, schema_org: true, openaire: true }, external_publication_status: null, external_status_policy: 'never-implies-apophis-review' });
  }
  if (requested === '/api/privacy/export' && req.method === 'GET') {
    try { const context = requestTenant(req); const actor = actorFilter(query.get('actor')); if (!actor) return send(res, 400, { error: 'actor_required' });
      const log = readJson(APPROVALS, { records: [] }); const projects = readJson(PROJECTS, { projects: [] });
      return send(res, 200, { schema: 'apophis/privacy-export/v1', tenant_id: context.tenant_id, actor, approvals: (log.records || []).filter((record) => tenantMatches(record, context) && record.actor === actor), projects: (projects.projects || []).filter((project) => tenantMatches(project, context) && (project.members || []).some((member) => member.actor === actor)), generated_at: new Date().toISOString() });
    } catch (error) { return send(res, tenantError(error) ? 401 : 500, { error: tenantError(error) ? error.message : 'privacy_export_unavailable' }); }
  }
  if (requested === '/api/privacy/erase' && req.method === 'POST') {
    try {
      const context = requestTenant(req); const body = JSON.parse(await readBody(req)); const actor = actorFilter(body.actor); if (!actor) return send(res, 400, { error: 'actor_required' });
      const log = readJson(APPROVALS, { schema: 'apophis/approval-log/v1', records: [], chain_head: ZERO_HASH }); const projects = readJson(PROJECTS, { schema: 'apophis/projects/v1', projects: [] });
      const approvalRecords = (log.records || []).filter((record) => !(tenantMatches(record, context) && record.actor === actor)); const removedApprovals = log.records.length - approvalRecords.length;
      const nextProjects = (projects.projects || []).map((project) => tenantMatches(project, context) ? { ...project, members: (project.members || []).filter((member) => member.actor !== actor) } : project);
      const removedMemberships = (projects.projects || []).reduce((count, project, index) => count + ((project.members || []).length - (nextProjects[index].members || []).length), 0);
      for (let index = 0; index < nextProjects.length; index += 1) {
        if (JSON.stringify(nextProjects[index]) !== JSON.stringify(projects.projects[index])) writeWormSnapshot('projects', nextProjects[index], { tenant_id: context.tenant_id, source: 'api/privacy/erase' });
      }
      writeWormSnapshot('approvals', { event: 'privacy-erasure', tenant_id: context.tenant_id, removed_approval_records: removedApprovals, removed_project_memberships: removedMemberships, occurred_at: new Date().toISOString() }, { tenant_id: context.tenant_id, source: 'api/privacy/erase' });
      if (removedApprovals) writeJsonAtomic(APPROVALS, rebuildApprovalChain(approvalRecords));
      writeJsonAtomic(PROJECTS, { ...projects, projects: nextProjects });
      return send(res, 200, { schema: 'apophis/privacy-erasure/v1', tenant_id: context.tenant_id, actor, removed_approval_records: removedApprovals, project_membership_removed: removedMemberships, integrity_artifact_retained: true, note: 'Earlier append-only snapshots may retain the erased content; signed bundle hashes are not rewritten. This prototype does not prove deletion from all retained storage.' });
    } catch (error) { return send(res, tenantError(error) ? 401 : 400, { error: tenantError(error) ? error.message : (error.message === 'body_too_large' ? error.message : 'invalid_erasure_request') }); }
  }
  if (requested === '/api/bundle' && req.method === 'GET') { const bundle = readJson(BUNDLE, {}); return send(res, 200, { bundle, verification: verifyBundle(bundle) }); }
  if (requested === '/api/bundle.json' && req.method === 'GET') return send(res, 200, fs.readFileSync(BUNDLE, 'utf8'));
  if (requested === '/api/approvals' && req.method === 'GET') { try { const context = requestTenant(req); const bundle = readJson(BUNDLE, {}); const log = readJson(APPROVALS, { schema: 'apophis/approval-log/v1', records: [], chain_head: ZERO_HASH }); return send(res, 200, { ...log, records: (log.records || []).filter((record) => tenantMatches(record, context)), verified: verifyApprovals(log, bundle.receipt?.bundle_hash || null) }); } catch (error) { return send(res, tenantError(error) ? 401 : 500, { error: tenantError(error) ? error.message : 'approval_store_unavailable' }); } }
  if (requested === '/api/approvals/status' && req.method === 'GET') { try { const context = requestTenant(req); const bundle = readJson(BUNDLE, {}); const log = readJson(APPROVALS, { schema: 'apophis/approval-log/v1', records: [], chain_head: ZERO_HASH }); return send(res, 200, approvalStatus(log, bundle.receipt?.bundle_hash || null, context.tenant_id)); } catch (error) { return send(res, tenantError(error) ? 401 : 500, { error: tenantError(error) ? error.message : 'approval_status_unavailable' }); } }
  if (requested === '/api/audit/verify' && req.method === 'GET') { try { const context = requestTenant(req); const bundle = readJson(BUNDLE, {}); const log = readJson(APPROVALS, { records: [], chain_head: ZERO_HASH }); return send(res, 200, { bundle: verifyBundle(bundle), approvals: { valid: verifyApprovals(log, bundle.receipt?.bundle_hash || null), tenant_id: context.tenant_id, record_count: (log.records || []).filter((record) => tenantMatches(record, context)).length } }); } catch (error) { return send(res, tenantError(error) ? 401 : 500, { error: tenantError(error) ? error.message : 'audit_verification_unavailable' }); } }
  if (requested === '/api/audit/worm/verify' && req.method === 'GET') { try { const context = requestTenant(req); const namespaces = ['approvals', 'projects', 'access-requests', 'group-exchanges'].map((namespace) => { const result = verifyNamespace(WORM_ROOT, namespace, context.tenant_id); return { namespace: result.namespace, files: result.files, valid: result.valid, failure_count: result.failures.length }; }); return send(res, 200, { schema: 'apophis/worm-verification/v1', tenant_id: context.tenant_id, namespaces, storage_mode: 'append-only-content-addressed-local-prototype', physical_worm_guarantee: false }); } catch (error) { return send(res, tenantError(error) ? 401 : 500, { error: tenantError(error) ? error.message : 'worm_verification_unavailable' }); } }
  if (requested === '/api/approvals' && req.method === 'POST') { try { const context = requestTenant(req); const payload = JSON.parse(await readBody(req)); payload.tenant_id = context.tenant_id; const record = appendApproval(payload); return send(res, 201, { record, verified: true }); } catch (error) { return send(res, tenantError(error) ? 401 : (error.message === 'body_too_large' ? 413 : 400), { error: error.message }); } }
  if (requested === '/api/biosecurity/scan' && req.method === 'POST') { try { const body = JSON.parse(await readBody(req)); return send(res, 200, scan(body.text)); } catch (_) { return send(res, 400, { error: 'invalid_scan_request' }); } }
  if (requested === '/api/references/check' && req.method === 'POST') return send(res, 403, { error: 'external_network_disabled', policy: 'offline-only' });
  if (requested === '/api/references' && req.method === 'GET') return send(res, 200, fs.readFileSync(path.join(ROOT, 'data', 'public-references.json'), 'utf8'));
  if (requested === '/api/news' && req.method === 'GET') return send(res, 200, fs.readFileSync(path.join(ROOT, 'data', 'news-inbox.json'), 'utf8'));
  if (requested === '/api/interoperability' && req.method === 'GET') return send(res, 200, fs.readFileSync(path.join(ROOT, 'data', 'interoperability-package.json'), 'utf8'));
  if (req.method !== 'GET') return send(res, 405, { error: 'method_not_allowed' });
  const relative = requested === '/' ? 'index.html' : requested.replace(/^\/+/, '');
  if (relative.includes('..') || relative.includes('\\')) return send(res, 400, 'bad path', 'text/plain; charset=utf-8');
  const file = path.join(PUBLIC, relative);
  if (!file.startsWith(PUBLIC + path.sep)) return send(res, 400, 'bad path', 'text/plain; charset=utf-8');
  fs.stat(file, (error, stat) => { if (error || !stat.isFile()) return send(res, 404, 'not found', 'text/plain; charset=utf-8'); send(res, 200, fs.readFileSync(file), MIME[path.extname(file).toLowerCase()] || 'application/octet-stream'); });
}
http.createServer((req, res) => { serve(req, res).catch((error) => { console.error('request_failed', error); send(res, 500, { error: 'internal_error' }); }); }).listen(PORT, HOST, () => console.log(`Apophis Evidence Desk listening on ${HOST}:${PORT}`));
